export const environment = {
  production: false,
  envName: "LocalDev",
  assetsRoot: "",
  defaultLanguage: "en",
  apiRoot: "",
  tokenExpiration: 120
};
