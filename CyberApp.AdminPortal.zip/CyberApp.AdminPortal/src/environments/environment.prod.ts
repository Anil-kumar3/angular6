export const environment = {
  production: true,
  envName: 'Prod',
  assetsRoot: "",
  defaultLanguage: "en",
  apiRoot: "",
  tokenExpiration: 120
};
