export const environment = {
    production: false,
    envName: "AngularCli",
    assetsRoot: "",
    defaultLanguage: "en",
    apiRoot: "",
    tokenExpiration: 120
  };
  