import { Routes, RouterModule } from '@angular/router';

import { LoadingComponent } from './loading/loading.component';


export var  pageLoadingRoutes: Routes = [
  {
    path: 'pageloading',
    component: LoadingComponent    
  }
];
