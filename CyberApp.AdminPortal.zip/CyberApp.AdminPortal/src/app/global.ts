import { Injectable,Input } from '@angular/core';

@Injectable()
export class Globals{
    @Input()
	public loginUserRole : string = "";
	
	@Input()
	public loginUserID : string="";
	
	@Input()
	public cedentStatus : string="";
	
	@Input()
	public cedentCreateStatus : string="";
	
	@Input()
	public loginStatus : string="";
}