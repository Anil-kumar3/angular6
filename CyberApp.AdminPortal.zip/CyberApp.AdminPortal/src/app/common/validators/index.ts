import { EmailValidator } from "./validate-email.directive";
export { EmailValidator } from "./validate-email.directive";

export var validators = [
    EmailValidator
];