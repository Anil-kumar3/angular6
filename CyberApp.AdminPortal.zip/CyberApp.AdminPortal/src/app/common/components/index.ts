import { DependFromAnswerComponent } from './depend-from-answer/depend-from-answer.component';
import { PagedIconAutocompleteComponent } from './pagediconautocomplete/paged.icon.autocomplete.component';
import { PagedAutocompleteComponent } from './pagedautocomplete/paged.autocomplete.component';
import { LoadingComponent } from './loading/loading.component';

export { DependFromAnswerComponent } from './depend-from-answer/depend-from-answer.component';
export { LoadingComponent } from './loading/loading.component';

export var commonComponents = [
    DependFromAnswerComponent,
    PagedIconAutocompleteComponent,
    PagedAutocompleteComponent,
	LoadingComponent	
];