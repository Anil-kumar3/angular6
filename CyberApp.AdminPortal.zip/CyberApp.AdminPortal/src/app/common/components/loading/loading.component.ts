import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'page-loading',
  templateUrl: './loading.component.html',
  styleUrls: ['./loading.component.scss']
})
export class LoadingComponent {

  constructor(
  ) { }

  ngOnInit() {
	// console.log("Loading Page");
  }

}
