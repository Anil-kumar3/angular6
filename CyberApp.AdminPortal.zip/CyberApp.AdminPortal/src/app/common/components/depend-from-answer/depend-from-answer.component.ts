import { Component, OnInit, OnChanges, SimpleChanges, Input, ViewChildren, QueryList } from '@angular/core';
import { MdCheckboxChange, MdCheckbox } from '@angular/material';

import { BehaviorSubject, Subscription, Observable } from 'rxjs/Rx';

import { remove } from 'lodash-es';

import { IQuestionnaireItem, IQuestionnaireAnswer } from '../../../common/models/contracts/models.contracts';

type DependQuestion = { id: string, title: string, IsMultipleChoice: boolean, answers: IQuestionnaireAnswer[] };

@Component({
  selector: 'depend-from-answer',
  styleUrls: ['./depend-from-answer.component.scss'],
  templateUrl: './depend-from-answer.component.html'
})
export class DependFromAnswerComponent implements OnInit, OnChanges {

  @Input('answer-ids') answerIds: string[];
  @Input('questions') questions: IQuestionnaireItem[];

  @Input('showRelation') showRelation: boolean = false;

  @ViewChildren('answercheckbox') answerCheckBoxes: QueryList<MdCheckbox>;

  public dependQuestions: DependQuestion[]= [];
  public selectedDependQuestion: IQuestionnaireItem;
  public addButtonDisabled: boolean = true;

  ngOnInit() {
    this.refreshAnswers();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.refreshAnswers();
  }



  public addAnswersClick() {
    var answerIds = this.getAnswerIds();
    this.addDependAnswer(answerIds);
    this.addButtonDisabled = true;
  }

  private getAnswerIds() {
    var answerIds = this.answerCheckBoxes.toArray().filter(i => i.checked).map(i => i.value);
    return answerIds;
  }


  public addDependAnswer(answerIds: string[]) {

    // if(!this.cedentEntity.DependencyIds) {
    //   this.cedentEntity.DependencyIds = [];
    // }

    for (let answerId of answerIds) {
      if (this.answerIds.indexOf(answerId) === -1) {
        this.answerIds.push(answerId);
      }
    }

    this.refreshAnswers();
    this.selectedDependQuestion = undefined;
  }

  public selectChanged() {
    setTimeout(() => this.refreshAddButton(), 50);

  }

  public checkBoxChanged() {
    this.refreshAddButton();
  }

  private refreshAddButton() {
    this.addButtonDisabled = this.getAnswerIds().length === 0;
  }

  public removeAnswer(answer: IQuestionnaireAnswer) {

    remove(this.answerIds, id => id === answer.UniqueId);
    this.refreshAnswers();
  }

  private refreshAnswers() {
    if (!this.questions) {
      return;
    }

    this.dependQuestions.length = 0;

    for (let answerId of this.answerIds) {
      let question = this.getQuestionByAnswerId(answerId);
      if (question) {

        var dependQuestion = this.dependQuestions.find(dq => dq.id === question.id);

        if(!dependQuestion){

          dependQuestion = {
            id: question.id,
            title: question.Title,
            IsMultipleChoice: question.IsMultipleChoice,
            answers: []
          },

          this.dependQuestions.push(dependQuestion);
        }

        var answer = question.Answers.find(a => a.UniqueId === answerId);

        if(answer && answer !== null){
          dependQuestion.answers.push(answer);
        }

      }
    }
  }

  private getQuestionByAnswerId(answerId: string): IQuestionnaireItem {
    if (!this.questions) {
      return undefined;
    }

    for (let question of this.questions) {
      let answer = question.Answers.find(a => a.UniqueId === answerId);
      if (answer) {
        return question;
      }
    }

    return undefined;
  }
}
