import { TemplateRef, OnInit, OnDestroy, ViewChild, ElementRef, Injector } from '@angular/core';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';

import { Observable, Subscription } from 'rxjs/Rx';

import { TranslateService } from '@ngx-translate/core';

import { ICedentEntity } from '../models/contracts/models.contracts';
import { CedentEntityDataSource } from '../models/cedent.entity.datasource';

import { AuthenticatedHttpService } from '../services/authenticated.http.service';
import { BaseCedentEntityService } from '../services/cedent.entity.service';
import { HttpServiceFactory } from '../services/http.service';

import { AlertDialog } from '../../common';

export abstract class CedentEntityListComponent<T extends ICedentEntity> implements OnInit, OnDestroy {

  //injected services
  protected dialog: MdDialog;
  protected _translateService: TranslateService;
  protected snackBar: MdSnackBar;
  protected route: ActivatedRoute;
  protected router: Router;
  protected _authService: AuthenticatedHttpService;
  protected _httpServiceFactory: HttpServiceFactory;
  
  @ViewChild('filter') filter: ElementRef;
  
  public dataSource: CedentEntityDataSource<T>;

  abstract getMessageDelete(item: T): string;
  abstract get messageDeleteSuccess(): string;
  abstract get messageDeleteError(): string;

  private subscription: Subscription;

  constructor(injector: Injector, protected entityService: BaseCedentEntityService<T>){


    this.dialog = injector.get(MdDialog);
    this._translateService =  injector.get(TranslateService);
    this.snackBar = injector.get(MdSnackBar);
    this.route = injector.get(ActivatedRoute);
    this.router = injector.get(Router);
    this._authService = injector.get(AuthenticatedHttpService);
    this._httpServiceFactory = injector.get(HttpServiceFactory)
  } 

  ngOnInit() {

    this.subscription = this._authService.loggedIn.subscribe(isLogged => {
      if(isLogged) {
        this.entityService.getEntities(true);
      }
    });

    this.dataSource = this.createDataSource();

    Observable.fromEvent(this.filter.nativeElement, 'keyup')
      .debounceTime(150)
      .distinctUntilChanged()
      .subscribe(() => {
        if (!this.dataSource) {return;}
        this.dataSource.filter = this.filter.nativeElement.value;
      })
  }

  ngOnDestroy() {
    if(this.subscription){
      this.subscription.unsubscribe();
      this.subscription = undefined;
    }
  }

  protected abstract createDataSource(): CedentEntityDataSource<T>;

  protected delete(cedentEntity: T): void {

    var dialogRef = this.dialog.open(AlertDialog , { disableClose: true });
    dialogRef.componentInstance.text = this.getMessageDelete(cedentEntity);

    dialogRef.afterClosed().subscribe((result: boolean) => {
      if (result){
        this.entityService.delete(cedentEntity.id).then(() => {
          this.snackBar.open(this.messageDeleteSuccess, null, {duration: 3000});
        },
        error => {
          this.snackBar.open(this.messageDeleteError, null, {duration: 3000});
        })
      }
    })
  }

  getTranslation(key: string | Array<string>, interpolateParams?: Object): any {
    return this._translateService.instant(key, interpolateParams);
  }

  goToCreatePage(): void {
    this.router.navigate(['create'], { relativeTo: this.route })
  }

  goToDetail(item: ICedentEntity): void {
    this.router.navigate([item.id], { relativeTo: this.route });
  }
}