import { OnInit, Injector } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute, Params } from '@angular/router';
import { Subject } from 'rxjs/Rx';
import { Observable } from 'rxjs/Rx';

import { ICedentEntity } from '../models/contracts/models.contracts';
import { BaseCedentEntityService } from '../services/cedent.entity.service';
import { getCedentId } from '../utils/cedent.utils';
import { LocalStorageService } from '../../localstorage/services/localstorage.service';


export abstract class CedentEntityDetailComponent<T extends ICedentEntity>
  implements OnInit {

	public isExistEntity: boolean = false;
	public cedentEntity: T;
	public viewRecord : string[];
	public approverejectFile : string[];
	public localStorage = new LocalStorageService;

  //services
  protected router: Router;
  protected route: ActivatedRoute;

  protected entityLoaded: Subject<T>;

  protected get cedentId(): string {
    //return getCedentId();
	var rootcedentId = getCedentId();
	if (rootcedentId == null || rootcedentId == "" || rootcedentId == undefined) {
	  rootcedentId = this.localStorage.get("superAdminID");
	}
	return rootcedentId;
  }
 
  
  constructor(injector: Injector, protected _entityService: BaseCedentEntityService<T>) {
    this.router = injector.get(Router);
    this.route = injector.get(ActivatedRoute);
    this.entityLoaded = new Subject<T>();
  }

  ngOnInit() {

    var entityId = this.route.snapshot.params['id']; 
    if(entityId && entityId !== 'create') {
      this.isExistEntity = true;
    }

    this.route.params.subscribe(params => {

      let id = params['id'];

      if (id && id !== null && this.isGuid(id)) {
        this._entityService.getEntity(id).subscribe(
          (entity: T) => {
            this.cedentEntity = entity;
            this.entityLoaded.next(entity);
            this.onEntityLoaded();
          });
      }
      else {
        this.cedentEntity = this.createNewObject();
      }
    });
  }

  private isGuid(id: string){
    var re = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    return re.test(id);
  }

  protected onEntityLoaded(){

  }

  protected onEntityCreated() {

  }

  protected abstract createNewObject(): T;

  protected onError(error: any): void {
    console.error(error);
  }

  public goBack(): void {
    this.router.navigate(['..'], { relativeTo: this.route });
  }

  public save(): void {
    if (this.cedentEntity.id === null || this.cedentEntity.id === undefined) {
      this.createEntity();
    } else {
      this.updateEntity();
    }
  }
 
	public downloadFile(Filename,search_Method,searchProcess,searchData,dataSearchFlex1,dataSearchFlex2) : Observable<any> {
		return this._entityService.downloadFile(Filename,search_Method,searchProcess,searchData,dataSearchFlex1,dataSearchFlex2)
		  .map(response => response)
		  .catch(error => Observable.throw(error));
	}
  
	public searchRecord(methodName,dataSearch,dataSearchCode,dataSearchFlex1,dataSearchFlex2) : Observable<any> {
		return this._entityService.viewRecord(methodName,dataSearch,dataSearchCode,dataSearchFlex1,dataSearchFlex2)
		  .map(response => response)
		  .catch(error => Observable.throw(error));
	}
	
	public quoteProcess(methodName,dataSearch,dataSearchHeader,dataSearchCode,dataSearchFlex1,dataSearchFlex2) : Observable<any> {
		return this._entityService.getRecord(methodName,dataSearch,dataSearchHeader,dataSearchCode,dataSearchFlex1,dataSearchFlex2)
		  .map(response => response)
		  .catch(error => Observable.throw(error));
	}
	
	
	public ApproveViewUW(methodName,dataSearch,searchMethod,dataSearchId,dataSearchFlex1,dataSearchFlex2,dataSearchFlex3) : Observable<any> {
		return this._entityService.approverejectFile(methodName,dataSearch,searchMethod,dataSearchId,dataSearchFlex1,dataSearchFlex2,dataSearchFlex3)
		  .map(response => response)
		  .catch(error => Observable.throw(error));
	}
	  

  private updateEntity() {
    this._entityService.update(this.cedentEntity)
      .then(() => {
        this.goBack();
      }, (error) => {
        this.onError(error);
      });
  }

  private createEntity() {
    this._entityService.create(this.cedentEntity).then(() => {
      this.onEntityCreated();
      this.goBack();
    }, (error) => {
      this.onError(error);
    });
  }
  
}
