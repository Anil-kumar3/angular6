import { Component, Input, OnInit, ElementRef, ViewChild, forwardRef } from '@angular/core';
import { FormControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

import { IoniconDataService } from '../../services/ionicon.provider';
import { PagerService } from '../../services/pager.service';
import { IIonicon } from '../../models/contracts/models.contracts';
import { Ionicon } from '../../models/ionicon';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

export const CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR: any = {
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => PagedIconAutocompleteComponent),
    multi: true
};
const noop = () => {};

@Component({
  selector: 'ca-icon-autocomplete',
  moduleId: module.id,
  templateUrl: './paged.icon.autocomplete.component.html',
  styleUrls: ['./paged.icon.autocomplete.component.scss'],
  providers: [CUSTOM_INPUT_CONTROL_VALUE_ACCESSOR]
})
export class PagedIconAutocompleteComponent
  implements OnInit, ControlValueAccessor {

    @Input() placeholder: string;
    public filteredIonicons: BehaviorSubject<Array<IIonicon>>;
    public iconCtrl: FormControl;
    
    protected allIonicons: IIonicon[];
    protected pagedIonicons: IIonicon[];

  private _selectedIcon: IIonicon;
  private onTouchedCallback: () => void = noop;
  private onChangeCallback: (_: any) => void = noop;

  pager: any = {};

  @ViewChild('iconInput') iconInput: ElementRef;

  constructor(
    private _ioniconDataService: IoniconDataService,
    private _pagerService: PagerService
  ){
    this.iconCtrl = new FormControl();
    this.filteredIonicons = new BehaviorSubject<Array<IIonicon>>([]);

    this.iconCtrl.valueChanges.startWith(null).subscribe((val) => {
      this.filterIonicons(val).subscribe((values) => {
        this.allIonicons = values;
        this.setPage(1, true);
        //OPTIONAL
        // let exactNameMatch = values.filter((s) => {
        //   return s.Name.toLowerCase() === val.toLowerCase();
        // });
        // //TODO: emit this exact name
      });
    });
  }

  ngOnInit(){
    
  }

  //From ControlValueAccessor interface
  writeValue(value: IIonicon) {
    if (value !== this._selectedIcon) {
        this._selectedIcon = value;
    }
  }

  get value(): IIonicon {
    return this._selectedIcon;
  };

  set value(v: IIonicon) {
    if (v !== this._selectedIcon) {
      this._selectedIcon = v;
      this.onChangeCallback(v);
    }
  }

  //From ControlValueAccessor interface
  registerOnChange(fn: any) {
    this.onChangeCallback = fn;
  }

  //From ControlValueAccessor interface
  registerOnTouched(fn: any) {
    this.onTouchedCallback = fn;
  }

  public setPage(page: number, forceSet: boolean = false) {
    if (page < 1 || page > this.pager.totalPages) {
      if (forceSet == false) {
        return;
      }
    }
  
    // get pager object from service
    this.pager = this._pagerService.getPager(this.allIonicons.length, page);

    // get current page of items
    this.pagedIonicons = this.allIonicons.slice(this.pager.startIndex, this.pager.endIndex + 1);

    // set paged and filtered items to show on the UI
    this.filteredIonicons.next(this.pagedIonicons);
  }

  private filterIonicons(val: string): Observable<Array<IIonicon>> {
    let observable: Observable<Array<IIonicon>> = Observable.create((observable) => {
      this._ioniconDataService.getIonicons().subscribe((values) => {
        observable.next(
          val ? values.filter((s) => {
            return s.Name.toLowerCase().indexOf(val.toLowerCase()) === 0
          }) : values
        )
      });
    });
    return observable;
  }
}