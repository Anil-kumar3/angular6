import { Component, ElementRef, Input, OnInit, ViewEncapsulation, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';

import { MdAutocomplete } from '@angular/material';

import { PagerService } from '../../services/pager.service';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'ca-paged-autocomplete',
  templateUrl: './paged.autocomplete.component.html',
  styleUrls: ['./paged.autocomplete.component.scss'],
  exportAs: 'mdAutocomplete',
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  host: {
    'class': 'mat-autocomplete'
  }
})
export class PagedAutocompleteComponent
  extends MdAutocomplete
  implements OnInit {

  private _items: Array<any>;

  protected displayedOptions: Array<any>;

  protected pager: any = {};
  protected pagedItems: Array<any>;

  private _changeDetectorRefReference: ChangeDetectorRef;

  constructor(
    _changeDetectorRef: ChangeDetectorRef,
    private _pagerService: PagerService
  ){
    super(_changeDetectorRef);
    this._changeDetectorRefReference = _changeDetectorRef;
    this.displayedOptions = new Array<any>();
  }

  ngOnInit(){

  }

  @Input() set items(items: Array<any>){
    this._items = items;
    this.setPage(1, true);
  }

  get items() {
    return this._items;
  }

  private setPage(page: number, forceSet: boolean = false){
    
    this.pager = this._pagerService.getPager(this.items.length, page); 
    
    this.displayedOptions = (this.items.filter((value: any, index: number, array: Array<any>)=> {
      return index >= this.pager.startIndex && index < this.pager.endIndex;
    }));   
  }

  /** Panel should hide itself when the option list is empty. */
  _setVisibility() {
    Promise.resolve().then(() => {
      this.showPanel = !!this.displayedOptions.length;
      this._changeDetectorRefReference.markForCheck();
    });
  }

  select(value: any): void {
    console.log(value);
    console.log(this.options.length);
  }

}