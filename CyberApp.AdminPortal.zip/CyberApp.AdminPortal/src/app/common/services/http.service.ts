﻿import { Injectable } from '@angular/core';
import { Observable, ReplaySubject, Subject, Subscription } from 'rxjs/Rx';

import { IEntity, ISuperAdminID } from '../models/contracts/models.contracts';

import { AuthenticatedHttpService } from './authenticated.http.service';
import { environment } from '../../../environments/environment';
import { LocalStorageService } from '../../localstorage/services/localstorage.service';

import { getCedentId } from '../../common/utils/cedent.utils';
import { Request, XHRBackend, RequestOptions, Response, Http, RequestOptionsArgs, Headers, ResponseContentType } from '@angular/http'; 
import * as FileSaver from 'file-saver';

@Injectable()
export class HttpServiceFactory {
  constructor(private http: AuthenticatedHttpService) { }

  public getInstance<T extends IEntity>(url: string): HttpService<T> {
    return new HttpService<T>(this.http, url);
  }
}

export class HttpService<T extends IEntity> {
  private _itemsReplaySubject = new ReplaySubject<T[]>(1);
  private _items: T[];
  private superAdminID: ISuperAdminID;
  private localStorageService = new LocalStorageService
  //public searchoutput: ISearchOutput;  

  constructor(protected http: AuthenticatedHttpService, private serviceName: string) {
	  this.superAdminID=this.localStorageService.get("superAdminID");
  }

  private setItems(items: T[]){
    this._items = items;
    this._itemsReplaySubject.next(items);
  }

  private deleteFromItems(id: string){

    if(!this._items){
      return;
    }

    var idx = this._items.findIndex((c) => c.id === id);
    var values = this._items;
    values.splice(idx, 1);
    this.setItems(values);
  }

  private addToItems(item: T){
    if(!this._items){
      return;
    }

    var values = this._items;
    values.push(item);
    this.setItems(values);
  }

  private updateItemInItems(item: T){

    if(!this._items){
      return;
    }

    var idx = this._items.findIndex((c) => c.id === item.id);
    var values = this._items;
    values.splice(idx, 1, item);
    this.setItems(values);
  }


  private get url(): string{
    //   api/${cedentId}/${controller}
    var cedentId = getCedentId();
	this.superAdminID=this.localStorageService.get("superAdminID");
    if(cedentId) {
      return environment.apiRoot + 'api/' + cedentId + '/' + this.serviceName;
    }else{
		return environment.apiRoot + 'api/' + this.superAdminID + '/' + this.serviceName;
		// return environment.apiRoot + 'api/' + this.serviceName;
	}
  }
  
  private get urlSearch(): string{
    //   api/${cedentId}/${controller}
    var cedentId = getCedentId();
	this.superAdminID=this.localStorageService.get("superAdminID");
    if(cedentId) {
		return environment.apiRoot + 'api/' + cedentId ;
    }else{
		return environment.apiRoot + 'api/' + this.superAdminID;
	}
  }

  getData(forceRefresh?: boolean): Observable<T[]> {

    forceRefresh = forceRefresh || !this._items;

    
    if (forceRefresh) {
      this.http.get(this.url)
        .map(response => response.json())
        .subscribe(data => {
          this.setItems(data);
        },
        error => {
          this.handleError(error);
        });
    }

    return this._itemsReplaySubject.asObservable();
  }

  public executePostAction(action: string, data: any): Observable<any> {
    return this.http.post(this.url + '/' + action, data)
               .map(response => response.json());
  }

  public getItem(id?: string, forceRefresh?: boolean): Observable<T> {
      return this.http.get(id ? this.url + '/' + id : this.url)
        .map(response => response.json());
  }

  public getItemsByIds(ids: string[]): Observable<T[]> {
    return this.executePostAction('getItemsByIds', ids)
  }
  
  public viewRecord(methodname : string,searchMethod : string,searchData : string,dataSearchFlex1 : string,dataSearchFlex2 : string): Observable<T>{
      return this.http.get(this.urlSearch + '/' + methodname,{
      params: {
        searchMethod: searchMethod,
		searchData: searchData,
		SearchFlex1: dataSearchFlex1,
		SearchFlex2: dataSearchFlex2
      }})
        .map(response => response.json())
		.catch(error =>  Observable.throw(error));
  }
  
  public getRecord(methodname : string,searchMethod : string,searchHeader : string,searchData : string,dataSearchFlex1 : string,dataSearchFlex2 : string): Observable<T>{
      return this.http.get(this.urlSearch + '/' + methodname,{
      params: {
		searchHeader:searchHeader,
        searchMethod: searchMethod,
		searchData: searchData,
		SearchFlex1: dataSearchFlex1,
		SearchFlex2: dataSearchFlex2
      }})
        .map(response => response.json())
		.catch(error =>  Observable.throw(error));
  }
  
  /** Download the file in excel format **/
  
  public downloadFile(Filename: string,search_Method: string,searchProcess: string,searchData:string,dataSearchFlex1:string,dataSearchFlex2:string): Observable<any> {
		console.log("Filename:"+Filename);
		let url: string =this.urlSearch + '/' + search_Method+'?searchMethod='+searchProcess+'&searchData='+searchData+'&SearchFlex1='+dataSearchFlex1+'&SearchFlex2='+dataSearchFlex2 ;
		let options = new RequestOptions({responseType: ResponseContentType.Blob});
		return this.http.get(url,options)
		.map(res => this.saveAsBlob(res,Filename))
		.catch(error => this.handleError(error));
  }
  
  private saveAsBlob(data: any,Filename) {
		const blob = new Blob([data._body]);
		FileSaver.saveAs(blob,Filename);
	}
	
	public uploadFile (formData,Service): Promise<T>
	{
		return new Promise<T>((resolve, reject) => {
		const URL = this.urlSearch + '/'+Service;
		return this.http.post(URL, formData, "")
			.map(res => res)
			.catch(error => Observable.throw(error))
			.subscribe(
				data => {
					console.log('success')
					resolve();
				},
				error => {
					reject(this.handleError(error));
				}
			);
		})
	}
	
	/******* End **********/
  
  public approverejectFile(methodname: string,search_Method: string,searchProcess: string,searchData:string,dataSearchFlex1:string,dataSearchFlex2:string,dataSearchFlex3:string): Observable<T>{
		console.log(this.urlSearch + '/' + search_Method+'?searchMethod='+searchProcess+'&searchData='+searchData+'&SearchFlex1='+dataSearchFlex1+'&SearchFlex2='+dataSearchFlex2+'&SearchFlex3='+dataSearchFlex3);
      return this.http.get(this.urlSearch + '/' + search_Method,{
      params: {
        searchMethod: searchProcess,
		searchData: searchData,
		SearchFlex1: dataSearchFlex1,
		SearchFlex2: dataSearchFlex2,
		SearchFlex3: dataSearchFlex3
      }})
        .map(response => response.json())
		.catch(error =>  Observable.throw(error));
  }
  
  public delete(id: string): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      this.http.delete(this.url + '/' + id)
        .subscribe(
        response => {
          this.deleteFromItems(id);
          resolve();
        },
        error => {
          reject(this.handleError(error));
        }
        );
    });
  }

  public create(cedent: T): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.http.post(this.url, cedent)
        .map(response => response.json())
        .subscribe(
        newValue => {
          this.addToItems(newValue);
          resolve(newValue);
        },
        error => {
          reject(this.handleError(error));
        }
        );
    });
  }

  public update(updCedent: T): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.http.put(this.url + '/' + updCedent.id, updCedent)
        .subscribe(
        response => {
          var newValue = response.json();
          this.updateItemInItems(newValue);
          resolve(newValue);
        },
        error => {
          reject(this.handleError(error));
        }
        );
    });
  }

  //TODO PP refactor create separate class
  public resetPasswort(policyHolder: T): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      this.http.post(this.serviceName, policyHolder)
        .subscribe(
        response => {
          resolve(response.json());
        },
        error => {
          reject(this.handleError(error));
        }
        );
    });
  }

  private handleError(error): any {
    var response;
    try {
      response = error.json();
    } catch (jsonError) {
      response = {
        message: "A server error occured."
      };
    }
    return response;
  }
}
