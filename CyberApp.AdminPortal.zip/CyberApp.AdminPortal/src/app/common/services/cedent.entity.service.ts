import { Injectable } from '@angular/core';

import { ICedentEntity } from '../../common/models/contracts/models.contracts';
import { ICedentEntityService } from '../../common/services/contracts/common.services.contracts';
import { HttpService, HttpServiceFactory } from '../../common/services/http.service';

import { Observable } from 'rxjs/Observable';

export class BaseCedentEntityService<T extends ICedentEntity>
  implements ICedentEntityService<T> {

  protected _entityHttpService: HttpService<T>;

  constructor(httpServiceFactory: HttpServiceFactory, controller: string) {
    this._entityHttpService = httpServiceFactory.getInstance<T>(controller)
  }

  public getEntities(force?: boolean): Observable<Array<T>>{
    return this._entityHttpService.getData(force);
  }

  public getEntity(id: string): Observable<T>{
    return this._entityHttpService.getItem(id, true);
  }

  public getEntitiesByIds(ids: string[]): Observable<T[]>{
    return this._entityHttpService.getItemsByIds(ids);
  }
  
  public viewRecord(methodname:string,dataSearch: string,dataSearchCode:string,dataSearchFlex1:string,dataSearchFlex2:string): Observable<T> {
    return this._entityHttpService.viewRecord(methodname,dataSearch,dataSearchCode,dataSearchFlex1,dataSearchFlex2);
  }
  
  public getRecord(methodname:string,dataSearch: string,dataSearchHeader: string,dataSearchCode:string,dataSearchFlex1:string,dataSearchFlex2:string): Observable<T> {
    return this._entityHttpService.getRecord(methodname,dataSearch,dataSearchHeader,dataSearchCode,dataSearchFlex1,dataSearchFlex2);
  }
  
  public approverejectFile(methodname:string,dataSearch: string,searchMethod: string,dataSearchCode:string,dataSearchFlex1:string,dataSearchFlex2:string,dataSearchFlex3:string): Observable<T> {
    return this._entityHttpService.approverejectFile(methodname,dataSearch,searchMethod,dataSearchCode,dataSearchFlex1,dataSearchFlex2,dataSearchFlex3);
  }
  
  public downloadFile(Filename: string,search_Method: string,searchProcess: string,searchData:string,dataSearchFlex1:string,dataSearchFlex2:string): Observable<any> {
    return this._entityHttpService.downloadFile(Filename,search_Method,searchProcess,searchData,dataSearchFlex1,dataSearchFlex2);
  }
  
  public delete(id: string): Promise<void> {
    return this._entityHttpService.delete(id);
  }

  public create(entity: T): Promise<T> {
    return this._entityHttpService.create(entity);
  }

  public update(entity: T): Promise<T> {
    return this._entityHttpService.update(entity);
  }
  
  
}