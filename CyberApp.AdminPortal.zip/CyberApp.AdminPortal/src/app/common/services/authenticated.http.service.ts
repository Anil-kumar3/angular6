import { Injectable } from '@angular/core'; 
import { Request, XHRBackend, RequestOptions, Response, Http, RequestOptionsArgs, Headers } from '@angular/http'; 
import { Observable, Subject, BehaviorSubject } from 'rxjs/Rx'; 

import 'rxjs/add/operator/catch'; 
import 'rxjs/add/observable/throw'; 
import 'rxjs/add/operator/retry'; 

import { LocalStorageService } from '../../localstorage/services/localstorage.service';
import { ExpiredUnit } from '../../localstorage/utils/localstorage.util';

import { ConfigurationService } from '../../configuration/services/configuration.service';
import { Globals } from '../../global';

type TokenResponse = { access_token: string, expires_in: number, refresh_token: string, token_type: string };
 
@Injectable() 
export class AuthenticatedHttpService extends Http { 
  private _accessToken: string; 
  private _accessDenied: Subject<boolean>; 
  public loggedIn: BehaviorSubject<boolean>; 
  private _lastRequest: Observable<Response>; 

  private tokenResponse: TokenResponse;

  private refreshTimer;

  constructor(
    backend: XHRBackend, 
    defaultOptions: RequestOptions,
	public globals: Globals,
    private localStorageService: LocalStorageService,
    private configurationService: ConfigurationService
  ) {
    super(backend, defaultOptions); 
 
    this._accessDenied = new Subject<boolean>(); 

    this.initAccestoken();
  } 

  private initAccestoken() {
    this.tokenResponse = this.localStorageService.get("authtoken");

    if(this.tokenResponse){
      this.refrehToken();
      this._accessToken = `Bearer ${this.tokenResponse.access_token}`;
    }

    this.loggedIn = new BehaviorSubject(this._accessToken !== '');
  }
 
  login(username: string, password: string,scope:string): Observable<{}> { 

	console.log("scope:"+scope);
    super.post('/token', `username=${username}&password=${password}&scope=${scope}&grant_type=password`) /** For Local URL: '/token'; For Serevr URL: '/Cyruss/token' **/
    .map(res => res.json())
    .subscribe(
      (tokenResponse: TokenResponse) => {

        this.setToken(tokenResponse);
        this.loggedIn.next(true);
        this.startRefrehTimer();

      },
      (error: any) => {
        this._accessDenied.next(true);
      } 
    );

    return this.loggedIn.asObservable(); 
  } 

  private startRefrehTimer(){

    this.clearRefreshTimer();

    var refreshTime = this.tokenResponse.expires_in * 0.8;
    console.log("token will be refreshed in xx seconds: " + refreshTime);
    this.refreshTimer = setTimeout( ()=> this.refrehToken(), refreshTime * 1000);
  }

  private clearRefreshTimer(){
    if(this.refreshTimer){
      clearTimeout(this.refreshTimer);
      this.refreshTimer = undefined;
    }
  }

  private async refrehToken(){
    if(!this.tokenResponse || !this.tokenResponse.refresh_token){
      return;
    }

    try {
      let response =  await super.post('/token', `grant_type=refresh_token&refresh_token=${this.tokenResponse.refresh_token}`) /** For Local URL: '/token'; For Serevr URL: '/Cyruss/token' **/
      .first()
      .toPromise();
  
      this.tokenResponse = response.json();
      this.setToken(this.tokenResponse);
      console.log('new refreh token: ' + this.tokenResponse.refresh_token);
  
      this.startRefrehTimer();
    }catch(err) {
      this.logout();
    }

    
  }

  private setToken(token: TokenResponse){
    this.tokenResponse = token;
    this._accessToken = `Bearer ${token.access_token}`;
    this.localStorageService.set("authtoken", token, this.configurationService.getTokenExpiration() , ExpiredUnit.MINUTES);
  }

  logout(): Observable<any> {

    this.localStorageService.remove('authtoken');
    this._accessToken = "";
    this.clearRefreshTimer();

    this.loggedIn.next(false);

    let observable = Observable.create(observer => {
      observer.complete();
    });
    return observable;
  }
 
  get accessDenied(): Observable<boolean> { 
    return this._accessDenied; 
  } 
 
  request(url: string | Request, options?: RequestOptionsArgs): Observable<Response> { 
    let opt = options || { headers: new Headers() }; 
    if (this._accessToken) { 
      var headers: Headers; 
      if (url instanceof Request) { 
        headers = url.headers; 
      } else { 
        headers = opt.headers || new Headers(); 
      } 
      headers.append('Authorization', this._accessToken); 
    } 
    this._lastRequest = super.request(url, opt).catch((error: Response) => { 
      if (error.status === 401) { 
        this._accessDenied.next(null); 
      } 
      if (error.status === 403) { 
        this._accessDenied.next(null); 
      } 
	  if (error.status === 400) { 
        this.globals.loginStatus=error.json().error;
      } 
	  
      return Observable.throw(error); 
    }); 
 
    return this._lastRequest; 
  } 
}