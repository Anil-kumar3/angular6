import { Injectable } from '@angular/core';
import { Router, CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { Observable } from 'rxjs/Rx';

import { ProfileService } from '../../profile/services/profile.service';
import { RoleNames } from '../models/contracts/models.contracts';
import { getCedentId } from '../utils/cedent.utils';



@Injectable()
export class IsCedentRoleGuard implements CanActivate, CanActivateChild {

  constructor(private _profileService: ProfileService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot, roles: string[] = undefined) {

    if(!roles){
      roles = this.getRoles(route.data);
    }

    if(!roles){
      roles = this.getRoles(route.firstChild);
    }

    if (!roles) {
      roles = [];
    }

    if (roles.indexOf(RoleNames.CEDENT_ADMIN) === -1 && roles.indexOf(RoleNames.CEDENT_MANAGER) === -1) {
      roles.push(RoleNames.CEDENT_ADMIN);
    }

    return this._profileService.hasRole(roles, getCedentId(state.url));
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {

    let roles = this.getRoles(route.data);

    if(!roles){
      roles = this.getRoles(route.parent);
    }

    return this.canActivate(route, state, roles);
  }

  private getRoles(container: any) {
    if (container && container.data && container.data !== null && container.data['roles']) {
      return container.data["roles"] as string[];
    }
    return undefined;
  }


}