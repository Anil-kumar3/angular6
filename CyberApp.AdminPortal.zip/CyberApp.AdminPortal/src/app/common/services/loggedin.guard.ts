import { Injectable } from '@angular/core';
import { Router, CanActivate, CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticatedHttpService } from './authenticated.http.service';

@Injectable()
export class LoggedInGuard 
  implements CanActivate, CanActivateChild {

  constructor(
    private _authService: AuthenticatedHttpService,
    private router: Router
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {

    if(!this._authService.loggedIn.value){
      this.router.navigate(['login']);
    }

    return this._authService.loggedIn.value;
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    return this.canActivate(route, state);
  }
}