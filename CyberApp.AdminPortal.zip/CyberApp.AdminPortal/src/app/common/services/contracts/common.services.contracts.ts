import { ICedentEntity, IEntity, IIonicon } from '../../../common/models/contracts/models.contracts';

import { Observable } from 'rxjs/Observable';

export interface ICedentEntityService<T extends ICedentEntity>
  extends IEntityService<T> {

  getEntities(force?: boolean): Observable<Array<T>>;
  getEntity(id: string): Observable<T>;
}

export interface IEntityService<T extends IEntity>{

  delete(id: string): Promise<void>;
  create(entity: T): Promise<T>;
  update(entity: T): Promise<T>;
}

export interface IIoniconDataService {
  getIonicons(): Observable<Array<IIonicon>>;
}