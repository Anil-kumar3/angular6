import { Subscription } from 'rxjs/Rx';

import { ICedentEntity } from './contracts/models.contracts';
import { EntityDataSource } from './entity.datasource';

import { BaseCedentEntityService } from '../services/cedent.entity.service';

export abstract class CedentEntityDataSource<T extends ICedentEntity> 
  extends EntityDataSource<T> {

  private subscription: Subscription;

  constructor(private _cedentEntityService: BaseCedentEntityService<T>){
    super();
    this.subscription = this._cedentEntityService.getEntities().subscribe((values) => {
      this._entities.next(values);
    });
  }

  disconnect(){
    super.disconnect()

    if(this.subscription){
      this.subscription.unsubscribe();
      this.subscription = undefined;
    }
  }
}