export interface IEntity {
  id: string;
  Readonly: boolean;
}


/*export const searchRecord : searchData[] = [
	{methodName: 'ggs',dataSearch: 'sdgsg',dataSearchCode: 'sdgsg',dataSearchFlex1: 'sdgsdg',dataSearchFlex2: 'sdgsg'}
];*/

/*export interface IsearchRecord extends ICedentEntity {
  methodName: string;
  dataSearch: string;
  dataSearchCode: string;
  dataSearchFlex1: string;
  dataSearchFlex2: string;
}*/


/*export interface searchRecord extends ICedentEntity {
  methodName: string;
  dataSearch: string;
  dataSearchCode: string;
  dataSearchFlex1: string;
  dataSearchFlex2: string;
}*/

export interface ICedentEntity
  extends IEntity {
  CedentId: string;
}

export interface IUser extends ICedentEntity {
  Roles: Array<IRole>;
  Identifier: string;
  Prefix: string;
  Password: string;
  PasswordHash: string;
  UserCountry: string;
  UserCountryCode: string;
  UserCedentID: string;
  UserCedentName: string;
  UserName: string;
  UserLoginID: string;
  UserStatus: string;
  UserEmailID: string;
  UserMobileNo: string;
  
}

export interface IPolicyHolder extends IUser {
  EMail: string;
  AnsweredQuestions: IAnsweredQuestion[];
  MessageTasks: IMessageTask[];
  PolicyNumber: string;
  Id : string;
}

export interface IAnsweredQuestion {
  QuestionId: string;
  GivenAnswers: string[];
}


export interface IMessage extends ICedentEntity {
  Title: string;
  SubTitle: string;
  Description: string;
  Date: Date;
  AnswerIds: string[];
  IsDefault: boolean;
}

export interface IMessageTask extends IMessage {
  IsTask: boolean;
  IsServer: boolean;
  Done: boolean;
  Due: Date;
  AnswerIds: string[];
  PolicyHolderIds: string[];
  RecurrencyIntervalDays: number;
  TaskValue: number;
  TaskSeverity: number;
  CreatedFromQuestionaireAnswerId: string;
}

export interface ITip extends ICedentEntity {
  Icon: string;
  Title: string;
  SubTitle: string;
  Description: string;
}

export interface ICedentCreation extends ICedentEntity {
  Country: string;
  CountryCode: string;
  CountryRegion: string;
  CedentLoginID: string;
  CedentName: string;
  PricingTemplate: string;
  PricingTemplateCode: string;
  UserStatus: string;
  FinancialStartMonth: string;
  FinancialEndMonth: string;
}

export interface ICedentUserCreation extends ICedentEntity {
	Roles: Array<IRole>;
	UserCountry: string;
	UserCountryCode: string;
	UserCedentID: string;
	UserCedentName: string;
	UserName: string;
	UserLoginID: string;
	UserStatus: string;
	UserEmailID: string;
	UserMobileNo: string;
	Password:string;
}

export interface IParametersetting extends ICedentEntity {
     
     Country:string;
	 CountryCode:string;
     ParameterCedentId:string;
     CedentName:string;
     ParameterKey:string;
     Value:string;
     EffectiveDate:Date;
	 GMTTimeZone:any;
	 UnderwriterID : string;
}

export interface IQuotedashboard extends ICedentEntity {
	
	DashboardCedentId:string;
	QuoteNumber:string;
	RecordID:string;
	reason:string;
}

export interface IThreshold extends ICedentEntity {
  ThresholdKey: string;
  Value: string;
  EffectiveDate: Date;
  Country: string;
  CountryCode: string;
  ThresholdCedentId: string;
  CedentName: string;
  ThresholdSection: string;
  PricingTemplateCode: string;
  GMTTimeZone:any;
  UnderwriterID : string;
}

export interface ITemplate extends ICedentEntity {
  Country: string;
  CountryCode: string;
  TemplateCedentId: string;
  CedentName: string;
  Cedentid: string;
  TemplateType:string;
  EffectiveDate: Date;
  Status:string;
  TemplateDocument: string;
  FileUpload:string;
  Filename:string;
  WordingFileUpload:string;
  RejectReason:string;
}


export interface ITemplateApproval extends ICedentEntity {
  Country: string;
  CountryCode: string;
  TemplateCedentId: string;
  CedentName: string;
  TemplateType:string;
  EffectiveDate: Date;
  Status:string;
  TemplateDocument: string;
  RejectReason:string;
  UserTemplateName:string;
  FileUpload:string;
  UnderwriterID : string;
}

export interface IUTF extends ICedentEntity {
  
  SNo:number;
  CountryRegion: string;
  isReinsurer: boolean;
  isCedent: boolean;
  UserGroup: string;
  UserType: string;
  Functionalities: Array<IUTFMap>;
}

export interface IPolicyUpdate extends ICedentEntity {
  QuoteNum: string;
  PolicyNum: string;
  StartDate: Date;
  EndDate: Date;
}

export interface IUserType extends ICedentEntity {
  
  SNo:number;
  CountryRegion: string;
  isReinsurer: boolean;
  isCedent: boolean;
  UserGroup: string;
  UserType: string;
  Functionalities: Array<IUTFMap>;
}

export interface IUTFMap extends ICedentEntity {
  Title: string;
  Description: string;
  FnType: string;
  Type: string;
}

export interface ICedent extends ICedentEntity {
  Name: string;
  Prefix: string;  
  SupportPhoneNumber?: string;
  SupportEMailAddress?: string;
  SalesPhoneNumber?: string;
  SalesEMailAddress?: string;
  Language: string;
  HomePage?: string;  
  //Country: string;  
  Country: string;
  CountryCode?: string;
  CountryRegion?: string;
  CedentLoginID?: string;
  CedentName?: string;
  PricingTemplate : string;
  ProductType: string;
  PricingTemplateCode?: string;
  UserStatus: string;
  FinancialStartMonth: string;
  FinancialEndMonth: string;
  
  roles?: string[];
  routerLink?: string;
  translateIdentifier?: string;
  icon?: string;
}

export interface ICedentWithStats extends ICedent {
  ActivatedNoAnswerUsers: number;
  ActivatedUsers: number;
  NewUsers: number;
  RegisteredUsers: number;
  RegistragtionExpiredUsers: number;
}

export interface IRole extends ICedentEntity {
  Name: string;
}

export interface ICountry extends ICedentEntity {
	CountryName: string;
	CountryCode: string;
	CountryRegion: string;
}

export interface IPricingTemplate extends ICedentEntity {
  TemplateName: string;
  TemplateCode: string;
}

export interface IThresholdParam extends ICedentEntity {
  Name: string;
  Description: string;
  IsCoveragesOpted: boolean;
  ThresholdSections: string;
}

export interface IIonicon {
  Name: string;
}

export interface IsearchData extends ICedentEntity {
  CountryCode: string;
  CountrySeqNo: string;
  CountryName: string;
  CountrySeqLength: string;
  CountryRegion: string;
  CedentLoginID: string;
  CedentName: string;
  PricingTemplate: string;
  PricingTemplateCode: string;
}

export interface IQuestionnaireItem extends ICedentEntity {
  Title: string;
  Description: string;
  Weight: number;
  IsExposure: boolean;
  IsMultipleChoice: boolean;
  Answers: Array<IQuestionnaireAnswer>;
  DependencyIds?: string[];
}

export interface IQuestionnaireAnswer extends ICedentEntity {
  Title: string;
  Value: number;
  Severity: number;
  CompulsoryMessageTask: IMessageTask; 
  UniqueId?: string;
}

export interface IFirstAidCategory extends ICedentEntity {
  Title: string;
  Icon: string; 
  Items: Array<IFirstAidItem>;
}

export interface IFirstAidItem extends ICedentEntity {
  Title: string;
  Tips: Array<ITip>;
}

export interface IQuestionDeatil extends ICedentEntity {
	labeId: string;
	labelName: string;
}

export interface ISearchquotes {
  Converted:string;
  Lost:string;
  //Quotedata:Array<IQuotedata>;
  Quotedata:string;
  Quoted:string;
  RejectUW:string;
}

//export interface IQuotedata extends ICedentEntity {
//    
//    Premium:string;
//    QuoteName:string;
//    QuoteNo:string;
//    QuoteStatus:string;
//}

export var RoleNames = {
    CEDENT_MANAGER: "CedentManager",
	CEDENT_ADMIN: "CedentAdmin",
	CEDENT_USER:  "CedentUser",
	CEDENT_READER: "CedentReader",
	CEDENT_SALES_SUPPORT: "CedentSalesAndSupport",
	CEDENT_CONTENT_MANAGER: "CedentContentManager",
	
	CE_PLATFORMMANAGER: "Cedent - Platform Manager",
	CE_PLATFORMSUPPORT: "Cedent - Platform Support",
	CE_T1_INCIDENTMANAGER: "Cedent - T1 Incident Manager",
	CE_T2_INCIDENTMANAGER: "Cedent - T2 Incident Manager",
	CE_T3_INCIDENTMANAGER: "Cedent - T3 Incident Manager",
	CE_INCIDENTHANDLER: "Cedent - Incident Handler",
	CE_UNDERWRITER: "Cedent - Underwriter",
	CE_CONTENTMANAGER: "Cedent - Content Manager",
	CE_AUDITOR: "Cedent - Auditor",
	CE_SALESUPPORT: "Cedent - Sale/Support",
	CE_POLICYHOLDER: "Cedent - Policy Holder",
	CE_GUEST: "Cedent - Guest",
	CE_CONTENTPROVIDER: "Cedent - Content Provider",
	CE_UW_MANAGER: "Cedent - Underwriting Manager",
	MR_PLATFORMMANAGER: "MR - Platform Manager",
	MR_UNDERWRITER: "MR - Underwriter",
	MR_DATAUSER: "MR - Data User",
	MR_PLATFORMSUPPORT: "MR - Platform Support"	
}

export interface RecurrenceTaskIntervall {
  label: string;
  value: number;
}

export var SearchOutput1:string = "" ;

/*export interface ISearchOutput extends IEntity{
  SearchOutput : string ;
}*/


export var recurrenceTaskIntervalls : RecurrenceTaskIntervall[] = [
  { label: 'None', value: 0 },
  { label: '30', value: 30 },
  { label: '60', value: 60 },
  { label: '90', value: 90 },
  { label: '365', value: 365 }
];

export interface ActiveStatus{
  label: string;
  activeyn: string;
}

export var activestatus :  ActiveStatus[] = [
	{label : 'Active', activeyn : 'Yes'},
	{label : 'InActive', activeyn : 'Yes'}
]

export interface FinancialMonth{
  label: string;
  activeyn: string;
}

export var financialMonth :  FinancialMonth[] = [
	{label : 'January', activeyn : 'Yes'},
	{label : 'February', activeyn : 'Yes'},
	{label : 'March', activeyn : 'Yes'},
	{label : 'April', activeyn : 'Yes'},
	{label : 'May', activeyn : 'Yes'},
	{label : 'June', activeyn : 'Yes'},
	{label : 'July', activeyn : 'Yes'},
	{label : 'August', activeyn : 'Yes'},
	{label : 'September', activeyn : 'Yes'},
	{label : 'October', activeyn : 'Yes'},
	{label : 'November', activeyn : 'Yes'},
	{label : 'December', activeyn : 'Yes'}
]


export interface ISuperAdminID extends ICedentEntity {
  expired: string;
  SuperAdminID: string; 
}

export interface IMenuItem extends ICedentEntity {
    roles?: string[];
    routerLink: string;
    translateIdentifier: string;
    icon: string;
}