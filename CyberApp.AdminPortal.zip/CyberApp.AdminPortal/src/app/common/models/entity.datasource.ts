import { DataSource } from '@angular/cdk/table';

import { IEntity } from '../models/contracts/models.contracts';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

export abstract class EntityDataSource<T extends IEntity>
  extends DataSource<any> {

  _filterChange = new BehaviorSubject("");
  _entities = new BehaviorSubject<Array<T>>(new Array<T>());

  get filter(): string { return this._filterChange.value;}
  set filter(filter: string) { this._filterChange.next(filter);}

  constructor(){
    super();
  }

  abstract buildSearchString(item: T): string;

  connect(): Observable<Array<T>>{
    const displayDataChanges = [
      this._entities,
      this._filterChange
    ];

    return Observable.merge(...displayDataChanges).map(() => {
      return this._entities.value.slice().filter((item: T) => {
        let searchStr = this.buildSearchString(item);
        return searchStr.indexOf(this.filter.toLocaleLowerCase()) != -1;
      });
    });
  }

  disconnect(){}
}
