import { ICedentEntity } from './contracts/models.contracts';
import { Entity } from './entity';

export abstract class CedentEntity
  extends Entity
  implements ICedentEntity {
  public CedentId: string;

  constructor(cedentId: string){
    super();
    if (cedentId !== null && cedentId !== undefined){
      this.CedentId = cedentId;
    }
  }
}