﻿import { IIonicon } from './contracts/models.contracts';

export class Ionicon
  implements IIonicon {

  public Name: string;

  constructor(name: string) {
    this.Name = name;
  }
}