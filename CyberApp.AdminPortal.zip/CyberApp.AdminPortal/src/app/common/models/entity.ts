import { IEntity } from './contracts/models.contracts';

export abstract class Entity
  implements IEntity {

  id: string;
  Readonly: boolean;

  constructor(){
    
  }
}