import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MdAutocompleteModule, MdButtonModule, MdIconModule, MdInputModule, MdDialogModule, MdCheckboxModule, MdSelectModule } from '@angular/material';
var materialModules = [
  MdAutocompleteModule, MdButtonModule, MdIconModule, MdInputModule, MdDialogModule, MdCheckboxModule, MdSelectModule
];

import { FlexLayoutModule } from '@angular/flex-layout';
import { BrowserModule } from '@angular/platform-browser';
import { Http } from '@angular/http';

import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}


import { DynamicDatePipe } from './pipes/dynamic.date.pipe';
import { RecurrenceTaskPipe } from './pipes/recurrence.task.pipe';
import { SeverityTaskPipe } from './pipes/severity.task.pipe';
import { CommonDirectives } from './directive';
import { validators } from './validators';
import { commonComponents  } from './components';
import { AlertDialog } from './dialog/alert.dialog';
import { UUIDProvider } from "app/common/utils/uuid-provider";

@NgModule({
  imports: [
    ...materialModules,
    BrowserModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  exports: [
    DynamicDatePipe,
    RecurrenceTaskPipe,
    SeverityTaskPipe,
    ...CommonDirectives,
    ...validators,
    ...commonComponents,
    AlertDialog
  ],
  declarations: [
    DynamicDatePipe,
    RecurrenceTaskPipe,
    SeverityTaskPipe,
    ...CommonDirectives,
    ...validators,
    ...commonComponents,
    AlertDialog
  ],
  entryComponents: [
    AlertDialog
  ],
  providers: [
    UUIDProvider
  ]
})
export class CommonModule { }
