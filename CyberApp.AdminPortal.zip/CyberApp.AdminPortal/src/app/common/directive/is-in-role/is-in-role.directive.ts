import { Directive, Input, TemplateRef, ViewContainerRef } from '@angular/core';

import { ProfileService } from '../../../profile/services/profile.service';
import { getCedentId } from '../../utils/cedent.utils';

import { getNormalisedRoles } from '../../utils/role.utils';


@Directive({
    selector: '[isInRole]'
})
export class IsInRoleDirective {

    constructor(
        private templateRef: TemplateRef<any>,
        private viewContainer: ViewContainerRef,
        private profileService: ProfileService
    ) { }

    @Input('isInRole') set roles(roleNames: string | string[]) {

        var roles = getNormalisedRoles(roleNames);

        if(!roles){
            this.viewContainer.clear();
            return;
        }

        var cedentId = getCedentId();

        this.profileService.hasRole(roles, cedentId).then(hasRole => {
            if (hasRole) {
                // If condition is true add template to DOM
                this.viewContainer.createEmbeddedView(this.templateRef);
            } else {
                this.viewContainer.clear();
            }
        });
    }
}