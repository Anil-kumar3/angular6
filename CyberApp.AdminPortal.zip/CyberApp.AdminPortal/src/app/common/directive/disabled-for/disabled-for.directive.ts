import { Directive, Input, OnInit, ElementRef, Renderer2 } from '@angular/core';

import { ProfileService } from '../../../profile/services/profile.service';
import { getCedentId } from '../../utils/cedent.utils';
import { getNormalisedRoles } from '../../utils/role.utils';


@Directive({
  selector: '[disabledFor]'
})
export class DisabledForDirective implements OnInit {

    @Input('disabledFor') roleNames: string | string[];

    constructor(
        private elementRef: ElementRef, 
        private renderer: Renderer2,
        private profileService: ProfileService
     ){ }

    async ngOnInit() {

        var roles = getNormalisedRoles(this.roleNames, false);
        if(!roles){
            return;
        }

        var cedentId = getCedentId();

        var hasAnyRole = await this.profileService.hasRole(roles, cedentId);

        if(hasAnyRole){
            this.setDisabled();
        }
    }

    private setDisabled(){

        this.renderer.setAttribute(this.elementRef.nativeElement, 'disabled', 'disabled');
        var inputElement = this.elementRef.nativeElement.querySelector('input');
        if(inputElement){
            this.renderer.setAttribute(inputElement, 'disabled', 'disabled');
        }
    }

    

}