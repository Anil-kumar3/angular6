import { DisabledExceptDirective } from './disabled-except/disabled-except.directive';
import { DisabledForDirective } from './disabled-for/disabled-for.directive';
import { IsInRoleDirective } from './is-in-role/is-in-role.directive';

export { DisabledExceptDirective } from './disabled-except/disabled-except.directive';
export { IsInRoleDirective } from './is-in-role/is-in-role.directive';
export { DisabledForDirective } from './disabled-for/disabled-for.directive';

export var CommonDirectives = [
    DisabledExceptDirective,
    IsInRoleDirective,
    DisabledForDirective
];