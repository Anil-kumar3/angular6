import { Directive, Input, OnInit, ElementRef, Renderer2 } from '@angular/core';

import { ProfileService } from '../../../profile/services/profile.service';
import { getCedentId } from '../../utils/cedent.utils';
import { getNormalisedRoles } from '../../utils/role.utils';


@Directive({
  selector: '[disabledExcept]'
})
export class DisabledExceptDirective implements OnInit {

    @Input('disabledExcept') roleNames: string | string[];

    constructor(
        private elementRef: ElementRef, 
        private renderer: Renderer2,
        private profileService: ProfileService
     ){ }

    async ngOnInit() {

        var roles = getNormalisedRoles(this.roleNames);
        if(!roles){
            return;
        }

        var cedentId = getCedentId();

        var hasAnyRole =  await this.profileService.hasRole(roles, cedentId);

        if(!hasAnyRole){
            this.setDisabled();
        }
    }

    private setDisabled(){
        this.renderer.setAttribute(this.elementRef.nativeElement, 'disabled', 'disabled');
    }
}
