import { Pipe, PipeTransform } from '@angular/core';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Pipe({
  name: 'dynamicDate'
})
export class DynamicDatePipe 
  implements PipeTransform {

  transform(dateString: string, lang: string): string {
    let date = new Date(dateString);

    switch (lang){
      case "de":
      return date.toLocaleDateString('de-DE');
    case "en": 
      return date.toLocaleDateString('en-GB');
    default:
      return date.toLocaleDateString();
    }
  }
}