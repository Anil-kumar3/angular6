import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'recurrenceTask'
})
export class RecurrenceTaskPipe
  implements PipeTransform {

  transform(value: number): string {
    switch (value) {
      case 0:
        return "None";
      default:
        return value.toString();
    }
  }
}
