import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class QuotedashboardFilterPipe implements PipeTransform {

  transform(value: any, arg: any): any {
    
   /*  return value.filter(function(val){
      //return val.QuoteNo.toLowerCase().includes(arg.toLowerCase()) | val.Premium.toLowerCase().includes(arg.toLowerCase());
	  //return 1;
    }); */
  }

}
