import { Pipe, PipeTransform } from '@angular/core';

import { TranslateService } from '@ngx-translate/core';

@Pipe({
  name: 'severityTask'
})
export class SeverityTaskPipe
  implements PipeTransform {

  constructor(private _translate: TranslateService) {
  }

  transform(value: number): string {
    switch (value) {
      case 1: return this._translate.instant("questionnaire.severityLow");
      case 2: return this._translate.instant("questionnaire.severityMedium");
      case 3: return this._translate.instant("questionnaire.severityHigh");
      default: return "?";
    }
  }
}
