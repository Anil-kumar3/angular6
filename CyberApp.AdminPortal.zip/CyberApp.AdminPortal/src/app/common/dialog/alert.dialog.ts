import { Component, OnInit, Inject } from '@angular/core';

import { MdDialogRef, MdDialogConfig } from '@angular/material';


@Component({
    selector: 'alert-dialog',
    templateUrl: './alert.dialog.html',
})
export class AlertDialog {

    public text: string;

    constructor(private dialogRef: MdDialogRef<AlertDialog>) { }

    public cancel() {
        this.dialogRef.close(false);
    }

    public confirm() {
        this.dialogRef.close(true);
    }
}