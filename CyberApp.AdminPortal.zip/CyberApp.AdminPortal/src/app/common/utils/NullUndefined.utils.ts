
//Change Undefined or Null to Empty
export function NullUndefined(Data){
	if(Data==null || Data==undefined || Data=="null"){
		return Data="";
	}else{
		return Data;
	}
}