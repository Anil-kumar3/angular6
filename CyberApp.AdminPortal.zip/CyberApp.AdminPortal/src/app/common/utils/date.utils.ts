
//convert effective date to string
export function ConvertEffectiveDate(effDate) {
	if(effDate!="")
	{
		var efDate = effDate.getUTCDate();
		var efMonth = effDate.getUTCMonth() + 1;
		var efYear = effDate.getUTCFullYear();
		var efHour = effDate.getUTCHours();
		var efMinute = effDate.getUTCMinutes();
		var covEffDate = efYear + "-" + efMonth + "-" + efDate + "T" + efHour + ":" + efMinute + ":00Z";
		return covEffDate;
	}
}