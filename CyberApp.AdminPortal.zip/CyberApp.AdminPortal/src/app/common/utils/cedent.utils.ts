export function getCedentId(href: string = undefined) {

        if(!href) {
                href = window.location.href;
        }

        href = href + '/'; // +'/' for reg ex compatibility

        var re = /cedent\/(.+?)\//;
        var match = re.exec(href);

        if(match && match !== null && match.length >= 2) {
                return match[1];
        }

        return undefined;
}