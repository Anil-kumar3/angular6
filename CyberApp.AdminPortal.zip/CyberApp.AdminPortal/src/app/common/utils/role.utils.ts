import { RoleNames } from '../models/contracts/models.contracts';


export function getNormalisedRoles(roleNames: string | string[], addAdmin = true): string[] {

    if (!roleNames || roleNames.length === 0) {
        return [RoleNames.CEDENT_ADMIN];
    }

    var roles: string[];

    if (roleNames.constructor !== Array) {

        if (roleNames.indexOf(',') > -1) {
            roles = (<string>roleNames).split(',');
        } else {
            roles = [<string>roleNames];
        }
    } else {
        roles = <string[]>roleNames;
    }

    if(addAdmin && 
        roles.indexOf(RoleNames.CEDENT_ADMIN) === -1 && 
        roleNames.indexOf(RoleNames.CEDENT_MANAGER) === -1){
        roles.push(RoleNames.CEDENT_ADMIN);
    }

    return roles;
}