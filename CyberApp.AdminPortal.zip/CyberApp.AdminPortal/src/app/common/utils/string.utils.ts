export class StringUtils {

    public static isNullUndefinedOrEmpty(value: string){
        return value === null
            || value === undefined
            || value.trim() === "";
    }
}