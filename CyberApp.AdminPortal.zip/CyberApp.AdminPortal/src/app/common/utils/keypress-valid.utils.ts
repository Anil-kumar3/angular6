export class keyPressvalidUtils {
	public static mobileValidation(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		if(FieldValue == ''){
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 49 || charCode > 57)) {
				return false;
			}
			return true;
		}else{
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 47 || charCode > 57)) {
				return false;
			}
			return true;
		}	
	}
	
	/*public static mobileValidationFormControl(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		console.log("FieldValue._value:"+FieldValue._value);
		if(FieldValue._value == ''){
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 49 || charCode > 57)) {
				return false;
			}
			return true;
		}else{
			var charCode = (evt.which) ? evt.which : evt.keyCode;
			if (charCode > 31 && (charCode < 47 || charCode > 57)) {
				return false;
			}
			return true;
		}	
	}*/
	
	public static mobileValidationInput(evt,FieldValue): string {
		var cnt=0;
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		for(let index=0;index<FieldValue.length;index++)
		{
			if(FieldValue[index]==0)
				cnt++;
			else if(FieldValue[index] != 0)
				break;
		}
		if((charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105) || (charCode >=37 && charCode <= 40))
		{
			if(FieldValue[0]==0)
			{
				FieldValue = FieldValue.substring(cnt, FieldValue.length);
				return FieldValue;
			}else {
				return FieldValue;
			}
		}else{
			FieldValue =  FieldValue.replace(evt.key,'');
			return FieldValue;
		}
	}
	
	
	public static mobileValidationInputFormControl(evt,FieldValue): string {
		var cnt=0;
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		for(let index=0;index<FieldValue.length;index++)
		{
			if(FieldValue[index]==0)
				cnt++;
			else if(FieldValue[index] != 0)
				break;
		}
		if((charCode >= 48 && charCode <= 57) || (charCode >= 96 && charCode <= 105) || (charCode >=37 && charCode <= 40))
		{
			if(FieldValue[0]==0)
			{
				FieldValue = FieldValue.substring(cnt, FieldValue.length);
				return FieldValue;
			}else {
				return FieldValue;
			}
		}else{
			FieldValue =  FieldValue.replace(evt.key,'');
			return FieldValue;
		}
	}

	public static onlyAlphaDotApo(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode==39 || charCode==46 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)) {
			return true;
		}
		return false;
	}


	public static onlyAlphaSpace(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode==32 || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)) {
			return true;
		}
		return false;
	}


	public static alphaNumericSpace(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode==32 || (charCode >= 49 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)) {
			return true;
		}
		return false;
	}


	public static alphaNumeric(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ((charCode >= 49 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122)) {
			return true;
		}
		return false;
	}


	public static emailFormat(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if ((charCode >= 49 && charCode <= 57) || (charCode >= 65 && charCode <= 90) || (charCode >= 97 && charCode <= 122) || charCode==46 || charCode==64 || charCode==45 || charCode==95) {
			return true;
		}
		return false;
	}


	public static onlyNumeric(evt,FieldValue) {
		evt = (evt) ? evt : window.event;
		var charCode = (evt.which) ? evt.which : evt.keyCode;
		if (charCode >= 48 && charCode <= 57) {
			return true;
		}
		return false;
	}
	
	public static passwordValidation(FieldValue){
		if(FieldValue != ""){
			var re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*+=|_-]).*$/;
			return re.test(FieldValue);
		}
	}
}