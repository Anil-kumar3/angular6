
//convert effective date to string
export function EmailValidate(email) {
	if(email != ""){
		var re = /\S+@\S+\.\S+/;
		return re.test(email);
	}
}