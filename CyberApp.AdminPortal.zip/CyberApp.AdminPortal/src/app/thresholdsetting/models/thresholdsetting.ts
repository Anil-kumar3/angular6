import { IUser, IRole, IThreshold } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Thresholdsetting
  extends CedentEntity
  implements IThreshold {

  public id: string;
  public Readonly: boolean;
 
  public ThresholdKey: string;
  public Value: string;
  public EffectiveDate: Date;
  public Country: string;
  public CountryCode: string;
  public ThresholdCedentId: string;
  public CedentName: string;
  public ThresholdSection: string;
  public PricingTemplateCode: string;
  public GMTTimeZone: any;
  public UnderwriterID: string;
  
  

  constructor(identifier: string, ThresholdCedentId: string){
    super(ThresholdCedentId);

    this.Country = identifier;
  }
}