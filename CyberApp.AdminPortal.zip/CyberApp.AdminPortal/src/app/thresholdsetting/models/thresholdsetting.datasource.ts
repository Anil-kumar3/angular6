import { ThresholdsettingService } from '../services/thresholdsetting.service';

import { IThreshold } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class ThresholdsettingDataSource 
  extends CedentEntityDataSource<IThreshold>{

  constructor(thresholdService: ThresholdsettingService){
    super(thresholdService);
  }

  buildSearchString(item: IThreshold): string {
    return (item.ThresholdCedentId).toLowerCase();
  }
}