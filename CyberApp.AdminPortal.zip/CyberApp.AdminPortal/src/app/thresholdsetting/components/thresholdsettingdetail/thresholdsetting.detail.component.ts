import { Component, OnInit, Injector, ViewChild, ElementRef, Inject } from '@angular/core';
import {FormControl} from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { ThresholdsettingService } from '../../services/thresholdsetting.service';
import { CountryService } from '../../../cedent/services';
import { Thresholdsetting } from '../../models/thresholdsetting';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { IThreshold, ICountry, IsearchData, IThresholdParam } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { Observable, Subscription } from 'rxjs/Rx';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { AlertDialog } from '../../../common';
import { CedentAddComponent } from '../../../cedent/components/cedentadd/cedent.add.component';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { getCedentId } from '../../../common/utils/cedent.utils';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { Globals } from '../../../global';

@Component({
  selector: 'thresholdsetting-detail',
  templateUrl: './thresholdsetting.detail.component.html',
  styleUrls: ['./thresholdsetting.detail.component.scss']
})
export class ThresholdsettingDetailComponent extends CedentEntityDetailComponent < IThreshold > implements OnInit {

	private validationErrors: Array < string > ;
	private _threshold: IThreshold;
	public country: ICountry[];
	KeyArr = [];
	public ThresholdArr : IThresholdParam[];
	coverageOpted = []
	error: string;
	search: string;
	minDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
	maxDate = new Date(new Date().getFullYear(), new Date().getMonth() + (12 - new Date().getMonth()), 0);
	countrycode: string;
	public ThresholdId: IsearchData[];
	public ThresholdIdDup: IsearchData[];
	public covOpt = false;
	protected snackBar: MdSnackBar;
	private isLoading = false;
	private localStorageService = new LocalStorageService;
	loadingFlag : string;

	/**
		Calling the Country list and ThresholdKey list from web service to get the list once we come from edit case.
	**/
	public set cedentEntity(entity: IThreshold) {
		entity.EffectiveDate = new Date(entity.EffectiveDate);
		if (NullUndefined(entity.Country) != "") {
			this.fetchRecord(entity.Country, entity.CountryCode);
		}
		if (NullUndefined(entity.ThresholdKey) != "") {
			this.fetchThreshold();
			 if(NullUndefined(entity.ThresholdKey) == "Coverages opted"){
				 this.covOpt = true;
			 }else{
				 this.covOpt = false;
			 }
		}
		this._threshold = entity;
	}

	/**
		Getting the Country list and ThresholdKey list from web service and assigning it to object once we come from edit case.
	**/
	public get cedentEntity() {
		return this._threshold;
	}

	constructor(
		injector: Injector,
		private thresholdService: ThresholdsettingService,
		private countryService: CountryService,
		private _translate: TranslateService,
		public globals: Globals
	) {
		super(injector, thresholdService);
		this.validationErrors = new Array < string > ();
		this.snackBar = injector.get(MdSnackBar);
	}

	/** 
		Function Calling on page load
	**/
	async ngOnInit() {
		this.loadingFlag="Loading...";
		super.ngOnInit();
		var _countryPromise = [];
		
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0){
					this.country = result;
				}else{
					this.snackBar.open("Unable to fetch country details. Please try after some time.", null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		
		this.fetchThreshold();
		
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);		
	}

	/**
		Function called whenever country drop down is changed.
		It internally calls fetch record for cedent id created for the country selected.
	**/
	public changeCountry() {
		this.loadingFlag="Loading...";
		this.cedentEntity.CedentName = "";
		if (this.country.length) {
			for (let cnt = 0; cnt < this.country.length; cnt++) {
				if (this.cedentEntity.Country == this.country[cnt].CountryName) {
					this.countrycode = this.country[cnt].CountryCode;
					this.cedentEntity.CountryCode = this.countrycode;
					break;
				}
			}
			this.fetchRecord(this.cedentEntity.Country, this.countrycode);
		}
	}

	/**
		Fetching CedentID & CedentName as per Country Selected.
		country: Country name will pass
		countrycode: Country code name will pass
	**/
	private async fetchRecord(country, countrycode) {
		this.loadingFlag="Loading...";
		var rootcedentId = getCedentId();
		if (NullUndefined(rootcedentId) == "")
		{ 
			rootcedentId = this.localStorageService.get("superAdminID"); 
		}
		
		var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(country), NullUndefined(countrycode), NullUndefined(rootcedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0){
					this.ThresholdId = result;
					this.ThresholdIdDup = result;
					this.snackBar.dismiss();
				}else{
					this.snackBar.open("Cedent details not available.", null, {duration: 3500})
					this.cedentEntity.ThresholdCedentId="";
					this.ThresholdId=[];
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open("Unable to fetch detail", null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		
	}

	/** 
		Search CedentId w.r.t Cedent Name
	**/
	public filterListCareUnit(val) {
		this.ThresholdId = this.ThresholdIdDup;
		this.ThresholdId = this.ThresholdId.filter((unit) => unit.CedentName.indexOf(val) > -1);
	}

	/** 
		Clear Cedent Search Field 
	**/
	public clearSearch() {
		this.search = ""
		this.ThresholdId = this.ThresholdIdDup;
	}

	/**
		Fetching Cedent Name as per CedentID Selected
	**/
	public changeThresholdcedentID() {
		this.cedentEntity.CedentName = "";
		for (let cnt = 0; cnt < this.ThresholdId.length; cnt++) {
			if (this.cedentEntity.ThresholdCedentId == this.ThresholdId[cnt].CedentLoginID) {
				this.cedentEntity.CedentName = this.ThresholdId[cnt].CedentName;
				this.cedentEntity.ThresholdCedentId = this.ThresholdId[cnt].CedentLoginID;
				break;
			}
		}
	}

	/** 
		Web service calling for Threshold Key Details
	**/
	private async fetchThreshold() {
		this.loadingFlag="Loading...";
		
		var seqnoPromise = this.searchRecord('Threshold', "", "", "", "")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0){
					this.ThresholdArr = result;
					this.changeCover();
				}else{
					this.snackBar.open("Unable to fetch Threshold details. Please try after some time.", null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open("Unable to connect Threshold web service", null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}

	/**
		Web service call for Covers onchange of ThresholdKey 
	**/
	public changeCover() {
		if (this.cedentEntity.ThresholdKey == "Coverages opted") {
			this.coverageOpted = [];
			this.covOpt = true;
			for (let cnt = 0; cnt < this.ThresholdArr.length; cnt++) {
				if ((this.cedentEntity.ThresholdKey == this.ThresholdArr[cnt].Name) && this.ThresholdArr[cnt].IsCoveragesOpted) {
					for (let i = 0; i < this.ThresholdArr[cnt].ThresholdSections.length; i++) {
						this.coverageOpted.push(this.ThresholdArr[cnt].ThresholdSections[i])
					}
					break;
				}
			}
		} else {
			this.coverageOpted = [];
			this.cedentEntity.ThresholdSection = "";
			this.covOpt = false;
		}
	}

	/**
		Calling for Field validations and upload data into server.
	**/
	public save(): void {
		if (NullUndefined(this.cedentEntity.Country) == '') {
			this.error = 'selectCountry';
			return;
		} else if (NullUndefined(this.cedentEntity.ThresholdCedentId) == '') {
			this.error = 'selectThresholdCedentID';
			return;
		} else if (NullUndefined(this.cedentEntity.ThresholdKey) == '') {
			this.error = 'selectThreshold';
			return;
		} else if ((NullUndefined(this.cedentEntity.ThresholdKey) == 'Coverages opted') && (NullUndefined(this.cedentEntity.ThresholdSection) == '')) {
			this.error = 'selectSublimit';
			return;
		} else if (NullUndefined(this.cedentEntity.Value) != '' && !Number(this.cedentEntity.Value)) {
			this.error = 'validValueformat';
			return;
		} else if (NullUndefined(this.cedentEntity.Value) != '' && (this.cedentEntity.Value.length < 5)) {
			this.error = 'validThresholdvalue';
			return;
		} else if (NullUndefined(this.cedentEntity.EffectiveDate) == "") {
			this.error = 'selectEffectiveDate';
			return;
		} else {
			this.error = '';
			//this.isLoading=true;
			this.cedentEntity.UnderwriterID = NullUndefined(this.globals.loginUserID);
			this.cedentEntity.GMTTimeZone=new Date().toString().match(/\(([A-Za-z\s].*)\)/)[1];
			this.loadingFlag = "Saving data...";
			super.save();
		}
	}

	/** 
		Clear the Field when click on Reset Button
	**/
	public resetData(): void {
		this.cedentEntity.Country = '';
		this.cedentEntity.ThresholdCedentId = '';
		this.cedentEntity.CedentName = '';
		this.cedentEntity.ThresholdKey = '';
		this.cedentEntity.ThresholdSection = '';
		this.cedentEntity.Value = '';
		this.cedentEntity.EffectiveDate = undefined;
		this.error = '';
		this.cedentEntity.ThresholdSection = "";
		this.covOpt = false;
	}
	
	/**
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	**/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "MobileNo"){
			return keyPressvalidUtils.onlyNumeric(evt,NullUndefined(FieldValue));
		}
	}

	/**
		Creating Object for Thresholdsetting
	**/
	protected createNewObject(): IThreshold {
		return new Thresholdsetting("", this.cedentId);
	}

	/**
		Web service Error validation
	**/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}
}