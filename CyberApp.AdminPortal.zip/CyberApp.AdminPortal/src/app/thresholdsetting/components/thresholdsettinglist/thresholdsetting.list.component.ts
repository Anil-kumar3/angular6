import { Component, Injector } from '@angular/core';
import { ThresholdsettingService } from '../../services/thresholdsetting.service';
import { Thresholdsetting, ThresholdsettingDataSource } from '../../models';
import { IThreshold } from '../../../common/models/contracts/models.contracts';
import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './thresholdsetting.list.component.html',
  styleUrls: ['./thresholdsetting.list.component.scss']
})
export class ThresholdsettingListComponent extends CedentEntityListComponent<IThreshold> {

  displayedColumns = ['id', 'cedentID', 'cedentName', 'thresholdParameter', 'thresholdSection', 'value', 'effectiveDate', 'delete'];
  dataSource: ThresholdsettingDataSource | null;

  get messageDeleteSuccess(): string {
    return this.getTranslation("threshold.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("threshold.deleteerror");
  }

  constructor(
    injector: Injector,
    private thresholdService: ThresholdsettingService
  ){
    super(injector, thresholdService);
  }

  protected createDataSource(): ThresholdsettingDataSource {
    return new ThresholdsettingDataSource(this.entityService);
  }

  getMessageDelete(threshold: IThreshold) {
    var options = { threshold: threshold.ThresholdKey, userid: threshold.ThresholdCedentId };
	console.log(threshold);
    return this.getTranslation('threshold.reallydelete', options);
  }
}