import { Component } from '@angular/core';


@Component({
  selector: 'thresholdsetting',
  template: '<router-outlet></router-outlet>'
})
export class ThresholdsettingComponent {

  constructor(  ) {}
}