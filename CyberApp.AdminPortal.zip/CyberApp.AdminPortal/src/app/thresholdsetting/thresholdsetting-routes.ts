import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { ThresholdsettingComponent } from './components/thresholdsetting.component';
import { ThresholdsettingListComponent } from './components/thresholdsettinglist/thresholdsetting.list.component';
import { ThresholdsettingDetailComponent } from './components/thresholdsettingdetail/thresholdsetting.detail.component';


export var  ThresholdsettingRoutes: Routes = [
  {
    path: 'thresholdsetting',
    component: ThresholdsettingComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    data: { roles: [RoleNames.CE_PLATFORMMANAGER, RoleNames.CE_UW_MANAGER, RoleNames.MR_PLATFORMMANAGER]},
    children: [
      {
        path: '',
        component: ThresholdsettingListComponent,
      },
      {
        path: ':id',
        component: ThresholdsettingDetailComponent,
      },
      {
        path: 'create',
        component: ThresholdsettingDetailComponent,
      }
    ]
  }
];
