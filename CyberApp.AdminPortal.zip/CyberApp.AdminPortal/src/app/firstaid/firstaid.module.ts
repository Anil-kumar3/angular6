import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CdkTableModule } from '@angular/cdk/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdAutocompleteModule, MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdSnackBarModule, MdTableModule } from '@angular/material';
import { BrowserModule } from '@angular/platform-browser';

import { CommonModule } from '../common/common.module';
import { TipsModule } from '../tips/tips.module';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

//Components
import { FirstAidComponent } from './components/firstaid.component';
import { FirstAidDetailComponent } from './components/firstaiddetail/firstaid.detail.component';
import { FirstAidListComponent } from './components/firstaidlist/firstaid.list.component';
import { FirstAidItemDetailComponent } from './components/firstaiditemdetail/firstaid.item.detail.component';

//services
import { FirstAidService } from './services/firstaid.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MdAutocompleteModule,
    MdButtonModule,
    MdCardModule,
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdSnackBarModule,
    MdTableModule,
    CdkTableModule,
    TipsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    FirstAidComponent,
    FirstAidDetailComponent,
    FirstAidListComponent,
    FirstAidItemDetailComponent
  ],
  providers: [
    FirstAidService
  ],
  entryComponents: [
    FirstAidItemDetailComponent
  ]
})
export class FirstAidModule { }