import { FirstAidService } from '../services/firstaid.service';

import { IFirstAidCategory } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';

export class FirstAidDataSource
  extends CedentEntityDataSource<IFirstAidCategory> {

  constructor(firstAidService: FirstAidService){
    super(firstAidService);
  }

  buildSearchString(item: IFirstAidCategory): string {
    return (item.Title).toLowerCase();
  }
}