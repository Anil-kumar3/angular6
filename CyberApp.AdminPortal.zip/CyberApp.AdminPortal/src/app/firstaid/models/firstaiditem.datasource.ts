import { DataSource } from '@angular/cdk/table';

import { IFirstAidItem } from '../../common/models/contracts/models.contracts';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

export class FirstAidItemDataSource extends DataSource<any>{

  constructor(private _firstAidItems: BehaviorSubject<Array<IFirstAidItem>>) {
    super();
  }

  connect(): Observable<Array<IFirstAidItem>> {
    const dataChanges = [
      this._firstAidItems
    ];

    return Observable.merge(...dataChanges).map(() => {
      return this._firstAidItems.value;
    });
  }

  disconnect(){}
}