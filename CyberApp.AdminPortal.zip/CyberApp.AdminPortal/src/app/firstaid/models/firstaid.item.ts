import { IFirstAidItem, ITip } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class FirstAidItem
  extends CedentEntity
  implements IFirstAidItem {
      
  public Title: string;
  public Tips: Array<ITip>;

  constructor(cedentId: string, title: string = ""){
    super(cedentId);
    
    this.Title = title;
    this.Tips = new Array<ITip>();
  }
}