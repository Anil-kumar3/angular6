import { IFirstAidCategory, IFirstAidItem } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class FirstAidCategory
  extends CedentEntity
  implements IFirstAidCategory {

  public Title: string;
  public Icon: string;
  public Items: Array<IFirstAidItem>;

  constructor(cedentId: string, title: string = ""){
    super(cedentId);
    
    this.Title = title;
    this.Items = new Array<IFirstAidItem>();
  }
      
}