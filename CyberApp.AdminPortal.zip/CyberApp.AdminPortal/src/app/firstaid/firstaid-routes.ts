﻿import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';


import { FirstAidComponent } from './components/firstaid.component';
import { FirstAidDetailComponent } from './components/firstaiddetail/firstaid.detail.component';
import { FirstAidListComponent } from './components/firstaidlist/firstaid.list.component';



export var  firstAidRoutes: Routes = [
  {
    path: 'firstaids',
    component: FirstAidComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    data: { roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER ] },
    children: [
      {
        path: '',
        component: FirstAidListComponent,
      },
      {
        path: ':id',
        component: FirstAidDetailComponent,
      },
      {
        path: 'create',
        component: FirstAidDetailComponent,
      }
    ]
  }
];
