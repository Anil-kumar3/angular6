import { Component, OnInit, Injector } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MdDialog, MdDialogRef } from '@angular/material';

import { FirstAidService } from '../../services/firstaid.service';
import { FirstAidItemDataSource } from '../../models/firstaiditem.datasource';
import { FirstAidCategory } from '../../models/firstaid.category';
import { FirstAidItem } from '../../models/firstaid.item';

import { FirstAidItemDetailComponent } from '../../components/firstaiditemdetail/firstaid.item.detail.component';

import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';

import { IFirstAidCategory, IFirstAidItem, IIonicon } from '../../../common/models/contracts/models.contracts';

import { StringUtils } from '../../../common/utils/string.utils';

import { BehaviorSubject } from 'rxjs/Rx';

@Component({
  selector: 'firstaid-detail',
  templateUrl: './firstaid.detail.component.html',
  styleUrls: ['./firstaid.detail.component.scss']
})
export class FirstAidDetailComponent
  extends CedentEntityDetailComponent<IFirstAidCategory> implements OnInit{

  displayedColumns = ['title', 'numoftips', 'delete'];

  protected firstAidItemsSource: FirstAidItemDataSource | null;
  protected firstAidItemsObservable: BehaviorSubject<IFirstAidItem[]> = new BehaviorSubject<IFirstAidItem[]>([]);


  constructor(
    injector: Injector,
    private _dialog: MdDialog,
    private firstAidService: FirstAidService,
  ) {
    super(injector, firstAidService);
  }

  ngOnInit(){
    super.ngOnInit();

    this.firstAidItemsSource = new FirstAidItemDataSource(this.firstAidItemsObservable);

    this.entityLoaded.subscribe(() => {
      this.firstAidItemsObservable.next(this.cedentEntity.Items);
    });
  }

  protected createNewObject(): IFirstAidCategory {
    return new FirstAidCategory(this.cedentId, "");
  }

  protected get isValid(): boolean {
    return !StringUtils.isNullUndefinedOrEmpty(this.cedentEntity.Title)
      && !StringUtils.isNullUndefinedOrEmpty(this.cedentEntity.Icon);
  }

  protected goToItem(item: IFirstAidItem): void {
    let dialog = this._dialog.open(FirstAidItemDetailComponent, {
      data: {
        entity: item
      }
    });
  }

  protected openAddFirstAidItemModal(){
    let dialog = this._dialog.open(FirstAidItemDetailComponent, {
      data: {
        entity: new FirstAidItem(this.cedentId, "")
      }
    });
    dialog.afterClosed().subscribe((result: IFirstAidItem) => {
      if (result !== null && result !== undefined){
        this.addFirstAidItem(result);
      }
    })
  }

  protected deleteItem(item: IFirstAidItem): void {
    let index = this.cedentEntity.Items.indexOf(item);
    if (index >= 0){
      this.cedentEntity.Items.splice(index, 1);
      this.firstAidItemsObservable.next(this.cedentEntity.Items);
    }
  }

  private addFirstAidItem(item: IFirstAidItem){
    this.cedentEntity.Items.push(item);
    this.firstAidItemsObservable.next(this.cedentEntity.Items);
  }
}
