import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstAidDetailComponent } from './firstaid.detail.component';

describe('FirstaidDetailComponent', () => {
  let component: FirstAidDetailComponent;
  let fixture: ComponentFixture<FirstAidDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FirstAidDetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstAidDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
