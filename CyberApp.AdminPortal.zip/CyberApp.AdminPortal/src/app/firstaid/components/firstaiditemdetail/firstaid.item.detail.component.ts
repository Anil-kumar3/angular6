import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MdDialogRef, MD_DIALOG_DATA } from '@angular/material';

import { ITipService } from '../../../tips/services/contracts/tip.services.contracts';
import { TipService } from '../../../tips/services/tip.service';

import { IFirstAidItem, ITip } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Component({
  moduleId: module.id,
  selector: 'firstaiditem-detail',
  templateUrl: './firstaid.item.detail.component.html',
  styleUrls: ['./firstaid.item.detail.component.scss']
})
export class FirstAidItemDetailComponent
  implements OnInit {

  cedentEntity: IFirstAidItem;
  tipCtrl: FormControl;
  filteredTips: BehaviorSubject<Array<ITip>>;

  private _dialogRef: MdDialogRef<FirstAidItemDetailComponent>;
  private _tipService: ITipService;
  private _tipsLoaded: Subject<void>;


  @ViewChild('tipInput') tipInput: ElementRef;

  constructor(
    dialogRef: MdDialogRef<FirstAidItemDetailComponent>,
    @Inject(MD_DIALOG_DATA) public data: any,
    tipService : TipService
  ){
    this._dialogRef = dialogRef;
    this.cedentEntity = data.entity;
    this._tipService = tipService;

    this.tipCtrl = new FormControl();
    this.filteredTips = new BehaviorSubject<Array<ITip>>([]);
    this._tipsLoaded = new Subject();
  }

  ngOnInit(): void {
    //Load tips once
    this._tipService.getEntities(true).subscribe((values: any) => {
      this._tipsLoaded.next();
    });
    //Only when tips available, listen to inputs
    this._tipsLoaded.subscribe(() => {
      this.tipCtrl.valueChanges.startWith(null).subscribe((val) => {
        this.filterTips(val).subscribe((result) => {
          this.filteredTips.next(result);
        });
      });
    });
  }

  get isValid(): boolean {
    return !StringUtils.isNullUndefinedOrEmpty(this.cedentEntity.Title);
  }

  addTip() {
    let newTip = this.tipInput.nativeElement.value;

    if(!StringUtils.isNullUndefinedOrEmpty(newTip)){
      this._tipService.getEntities().subscribe((availableTips) => {
        let index = availableTips.findIndex((value) => {
          return value.Title === newTip;
        });
        let alreadyExists = this.cedentEntity.Tips.find((value) => {
          return value.Title === newTip;
        });
        if (index > -1 && !alreadyExists){
          this.cedentEntity.Tips.push(availableTips[index]);
          this.tipInput.nativeElement.value = "";
          this.filteredTips.next([]);
        }
      })
    }
  }

  removeTip(tip: ITip){
    let index = this.cedentEntity.Tips.findIndex((item) => {
      return item.id === tip.id;
    });
    if (index !== undefined){
      this.cedentEntity.Tips.splice(index, 1);
    }
  }

  private filterTips(val: string): Observable<Array<ITip>>{
    let observable: Observable<Array<ITip>> = Observable.create((observable) => {
      this._tipService.getEntities().subscribe((values) => {
        observable.next(
          val ? values.filter((s) => {
            return s.Title.toLowerCase().indexOf(val.toLowerCase()) === 0
          }) : values
        );
      });
    });
    return observable;
  }

  submit(): void {
    if (this.isValid){
      this._dialogRef.close(this.cedentEntity);
    }
  }

  goBack(): void {
    this._dialogRef.close(null);
  }

}