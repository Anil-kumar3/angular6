﻿import { Component} from '@angular/core';

@Component({
  selector: 'firstaid',
  template: '<router-outlet></router-outlet>'
})
export class FirstAidComponent {
}