import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstAidListComponent } from './firstaid.list.component';

describe('FirstaidListComponent', () => {
  let component: FirstAidListComponent;
  let fixture: ComponentFixture<FirstAidListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FirstAidListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstAidListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
