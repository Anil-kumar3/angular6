import { Component, Injector } from '@angular/core';

import { FirstAidService } from '../../services/firstaid.service';
import { FirstAidDataSource } from '../../models/firstaid.datasource';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';
import { IFirstAidCategory } from '../../../common/models/contracts/models.contracts';

@Component({
  selector: 'firstaid-list',
  templateUrl: './firstaid.list.component.html',
  styleUrls: ['./firstaid.list.component.scss']
})
export class FirstAidListComponent
  extends CedentEntityListComponent<IFirstAidCategory> {

  displayedColumns = ['title', 'icon', 'itemcount', 'delete'];

  get messageDeleteSuccess(): string {
    return this.getTranslation("firstaid.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("firstaid.deleteerror");
  }
  constructor(
    injector: Injector, 
    private firstAidService: FirstAidService
  ) {
    super(injector, firstAidService);
  }

  protected createDataSource(){
    return new FirstAidDataSource(this.entityService);
  }

  getMessageDelete(firstAidCategory: IFirstAidCategory) {
    var options = {firstAidCategory: firstAidCategory.Title} ;
    return this.getTranslation('firstaid.reallydelete', options);
  }
}
