import { Injectable } from '@angular/core';
import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';

import { IFirstAidCategory } from '../../common/models/contracts/models.contracts';

import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class FirstAidService
  extends BaseCedentEntityService<IFirstAidCategory> {

  constructor(httpServiceFactory: HttpServiceFactory){
    super(httpServiceFactory, 'firstaidcategory');
  }
}