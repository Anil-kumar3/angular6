import { Component, OnInit, HostListener ,Injector} from '@angular/core';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { Router } from '@angular/router';

import { Thresholdsetting } from '../thresholdsetting/models/thresholdsetting';
import { ThresholdsettingService } from '../thresholdsetting/services/thresholdsetting.service';
import { IThreshold } from '../common/models/contracts/models.contracts';
import { AuthenticatedHttpService } from '../common/services/authenticated.http.service';
import { LocalStorageService } from '../localstorage/services/localstorage.service';
import { CedentEntityDetailComponent } from '../common/components/cedent.entity.detail.component';
import { NullUndefined } from "../common/utils/NullUndefined.utils";

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'status-screen',
  templateUrl: './statusScreen.component.html',
  styleUrls: ['./statusScreen.component.scss']
})
export class StatusScreenComponent extends CedentEntityDetailComponent < IThreshold > implements OnInit{

  private webURL:string;
  private urlData:any;
  private param:any;
  private idSplit:any;
  private actionSplit:any;
  private id:string;
  private action:string;
  private acceptStatus:boolean;
  private rejectStatus:boolean;
  private refStatus:string;
  public rejectReason:string;
  public rejectUpdate:boolean;
  public displayMsg:string;
  protected snackBar: MdSnackBar;
  loadingFlag:string;
  
  
  constructor(
	injector: Injector,
	private thresholdService: ThresholdsettingService
  ) {
	  super(injector, thresholdService);
	  this.snackBar = injector.get(MdSnackBar);
	 }

  

	ngOnInit() {
		this.webURL = window.location.href;
		//console.log("URL:"+this.webURL);
		this.urlData = this.webURL.split("?");
		//console.log("URL:"+this.urlData[1]);
		this.param = this.urlData[1].split("&");
		//console.log("Split cnt:"+this.param[1]);
		this.idSplit=this.param[0].split("=");
		this.actionSplit=this.param[1].split("=");
		this.id=this.idSplit[1];
		this.action=this.actionSplit[1];
		this.rejectUpdate=false;
		if(this.action.toUpperCase() == "TRUE"){
			
			this.refStatus="Accepted";
		}else{
			this.acceptStatus=false
			this.rejectStatus=true;
			this.refStatus="Rejected";
		}
		//console.log("ID:"+this.id);
		//console.log("action:"+this.action);
		if(this.refStatus == "Accepted"){
			this.saveDetails(this.refStatus);
		}
	}
  
	private update():void{
		if (NullUndefined(this.rejectReason) == '') {
			this.snackBar.open("Provide reason of reject", null, {duration: 3500})
			return;
		}else{
			this.saveDetails(this.refStatus);
		}
	}
	
	protected createNewObject(): IThreshold {
		return new Thresholdsetting("", this.cedentId);
	}

	private saveDetails(statusFlag){
		this.loadingFlag = "Loading data...";
		if(statusFlag == "Accepted"){
			var countryPromise = this.quoteProcess('QuoteProcess/QuoteApprovalPH',this.refStatus,"phapproval",this.id,"","")
			.subscribe(
				  response => {
						this.loadingFlag = "";
						var result = response;
						if(result.Status == 0){
							this.acceptStatus=false;
							this.rejectStatus=false;
							this.displayMsg="Unable to process your request. Try after some time";
							this.rejectUpdate=true;
						}else{
							this.acceptStatus=true;
							this.rejectStatus=false;
						}
				  }, error => {
						this.loadingFlag = "";
						this.displayMsg="Unable to process your request. Try after some time";
						this.rejectUpdate=true;
				}
			);
		}else if(statusFlag == "Rejected"){
			var countryPromise = this.quoteProcess('QuoteProcess/QuoteApprovalPH',this.refStatus,"phapproval",this.id,NullUndefined(this.rejectReason),"")
			.subscribe(
				  response => {
					  var result = response;
					  this.loadingFlag = "";
					  if(result.Status == 0){
							this.acceptStatus=false;
							this.rejectStatus=false;
							this.displayMsg="Unable to process your request. Try after some time";
							this.rejectUpdate=true;
						}else{
							this.acceptStatus=false
							this.rejectStatus=false;
							this.displayMsg="You response has been updated.";
							this.rejectUpdate=true;
						}
						
				  }, error => {
						this.loadingFlag = "";
						this.displayMsg="Unable to process your request. Try after some time";
						this.rejectUpdate=true;
				}
			);
		}else{
			
		}
	}
}
