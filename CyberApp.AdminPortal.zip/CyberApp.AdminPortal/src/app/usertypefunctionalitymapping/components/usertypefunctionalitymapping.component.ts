import { Component } from '@angular/core';


@Component({
  selector: 'usertypefunctionalitymapping',
  template: '<router-outlet></router-outlet>'
})
export class UsertypefunctionalityMappingComponent {

  constructor(  ) {}
  
  public getResponseData (param) {
		console.log("param:"+param)
	}
}