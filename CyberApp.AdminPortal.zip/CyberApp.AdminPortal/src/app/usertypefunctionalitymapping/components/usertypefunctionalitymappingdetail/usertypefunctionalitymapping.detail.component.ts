import { Component, OnInit, Injector, ViewChild, ElementRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UsertypefunctionalityMappingService } from '../../services/usertypefunctionalitymapping.service';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { UsertypefunctionalityMapping, UsertypefunctionalityMappingDataSource } from '../../models';
import { IUTF, IUTFMap } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { Observable, Subscription } from 'rxjs/Rx';
import { AlertDialog } from '../../../common';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";

@Component({
  selector: 'usertypefunctionalitymapping-detail',
  templateUrl: './usertypefunctionalitymapping.detail.component.html',
  styleUrls: ['./usertypefunctionalitymapping.detail.component.scss']
})
export class UsertypefunctionalityMappingDetailComponent extends CedentEntityDetailComponent < IUTF > implements OnInit {
	
	error: string;
	public utfresult: IUTF[];
	public displayedColumns = [];
	private _tableFormat = false;

	dataSource: UsertypefunctionalityMappingDataSource | null;
	public keys = [];
	protected dialog: MdDialog;
	protected snackBar: MdSnackBar;
	loadingFlag : string;

	constructor(
		injector: Injector,
		private usertypefuncService: UsertypefunctionalityMappingService,
		private _translate: TranslateService
	) {
		super(injector, usertypefuncService);
		this.dialog = injector.get(MdDialog);
		this.snackBar = injector.get(MdSnackBar);
	}

	/** 
		Function Calling on page load
	**/
	async ngOnInit() {
		this.loadingFlag="Loading..";
		super.ngOnInit();
		this.loadingFlag="";
	}
	
	/** 
		Disable the View button if Cedent & Reinsurer are not selected.
	**/
	public get isValid(): boolean {
		return (this.cedentEntity.isReinsurer || this.cedentEntity.isCedent);
	}

	/** 
		Onclick of View Button 
	**/
	public view(): void {
		this.fetchRecord()
	}

	/** 
		Function Calling on Checkbox click 
	**/
	private clickOnCheck(): void {
		if (this._tableFormat == true)
			this._tableFormat = false;
	}

	/** 
		API call for User Functionality Details 
	**/
	private async fetchRecord() {
		this.loadingFlag="Loading...";
		
		if (this.cedentEntity.isReinsurer && this.cedentEntity.isCedent) {
			this.displayedColumns = ['SlNo', 'User Group', 'User Type', 'Functionality'];
			var seqnoPromise = this.searchRecord('UTFMapping', 'UTFMapping', 'REINSURER', 'CEDENT', '')
			.subscribe(
				  response => {
					this.fetchRecordData(response);
				  }, error => {
					this.fetchRecordError();	
				}
			);
		} else if (this.cedentEntity.isReinsurer) {
			this.displayedColumns = ['SlNo', 'User Type', 'Functionality'];
			var seqnoPromise = this.searchRecord('UTFMapping', 'UTFMapping', 'REINSURER', '', '')
			.subscribe(
				  response => {
					this.fetchRecordData(response);
				  }, error => {
					this.fetchRecordError();	
				}
			);
		} else if (this.cedentEntity.isCedent) {
			this.displayedColumns = ['SlNo', 'User Type', 'Functionality'];
			var seqnoPromise = this.searchRecord('UTFMapping', 'UTFMapping', 'CEDENT', '', '')
			.subscribe(
				  response => {
					this.fetchRecordData(response);
				  }, error => {
					this.fetchRecordError();	
				}
			);
		}
	}
	
	/**
		Getting User Type Functionality Response from API
	**/
	fetchRecordData(response){
		var result = response;
		this.utfresult=result;
		if(result.length>0 && result !="No Data Found"){
			this._tableFormat = true;
			this.insertData();
		}else{
			this._tableFormat = false;
			this.snackBar.open(this._translate.instant("commonMessage.quoteData"), null, {duration: 3500});
		}
		this.loadingFlag="";
	}
	
	/**
		Error function from API
	**/
	fetchRecordError(){
		this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
		this.loadingFlag="";
		return;
	}

	/**
		Inserting User Type Functionality details into an Array 
	**/
	private insertData() {
		this.keys = [];
		for (let cnt = 0; cnt < this.utfresult.length; cnt++) {
			this.keys.push(this.utfresult[cnt]);
		}
	}

	/**
		Creating Object for the User type functionality mapping
	**/
	protected createNewObject(): IUTF {
		return new UsertypefunctionalityMapping("", this.cedentId);
	}
}