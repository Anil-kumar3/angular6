import { Component, Injector } from '@angular/core';

import { UsertypefunctionalityMappingService } from '../../services/usertypefunctionalitymapping.service';

import { UsertypefunctionalityMapping, UsertypefunctionalityMappingDataSource } from '../../models';
import { IUTF } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './usertypefunctionalitymapping.list.component.html',
  styleUrls: ['./usertypefunctionalitymapping.list.component.scss']
})
export class UsertypefunctionalityMappingListComponent extends CedentEntityListComponent<IUTF> {

  // displayedColumns = ['id', 'CedentID', 'CedentName', 'contractNumber', 'value', 'effective', 'role', 'delete'];
  displayedColumns = [];
  dataSource: UsertypefunctionalityMappingDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("threshold.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("threshold.deleteerror");
  }

  constructor(
    injector: Injector,
    private usertypefuncService: UsertypefunctionalityMappingService
  ){
    super(injector, usertypefuncService);
  }

  protected createDataSource(): UsertypefunctionalityMappingDataSource {
    return new UsertypefunctionalityMappingDataSource(this.entityService);
  }
  
   getMessageDelete(threshold: IUTF) {
    var options = { threshold: threshold.CountryRegion };
    return this.getTranslation('threshold.reallydelete', options);
  }
}