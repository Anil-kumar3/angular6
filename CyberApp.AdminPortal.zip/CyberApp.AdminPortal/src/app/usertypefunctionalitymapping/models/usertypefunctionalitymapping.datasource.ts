import { UsertypefunctionalityMappingService } from '../services/usertypefunctionalitymapping.service';

import { IUTF } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class UsertypefunctionalityMappingDataSource 
  extends CedentEntityDataSource<IUTF>{

  constructor(usertypefuncService: UsertypefunctionalityMappingService){
    super(usertypefuncService);
  }

  buildSearchString(item: IUTF): string {
    return (item.CountryRegion).toLowerCase();
  }
}