import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { UsertypefunctionalityMappingComponent } from './components/usertypefunctionalitymapping.component';
import { UsertypefunctionalityMappingDetailComponent } from './components/usertypefunctionalitymappingdetail/usertypefunctionalitymapping.detail.component';


export var  UsertypefunctionalityMappingRoutes: Routes = [
  {
    path: 'usertypefunctionalitymapping',
    component: UsertypefunctionalityMappingComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    children: [
      {
        path: '',
        component: UsertypefunctionalityMappingDetailComponent,
      }
    ]
  }
];
