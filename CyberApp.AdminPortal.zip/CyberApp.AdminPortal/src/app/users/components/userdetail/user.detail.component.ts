import {Component,OnInit,Injector,ViewChild,ElementRef} from '@angular/core';
import {MdSnackBar} from '@angular/material';
import {TranslateService} from '@ngx-translate/core';

import {UserService} from '../../services/user.service';
import {RoleService} from '../../../cedent/services';
import {User} from '../../models/user';

import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';

import {IUser,IRole,ICountry, IPricingTemplate, IsearchData, activestatus, RoleNames} from '../../../common/models/contracts/models.contracts';
import {StringUtils} from '../../../common/utils/string.utils';
import {ConfigurationService} from '../../../configuration/services/configuration.service';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { getCedentId } from '../../../common/utils/cedent.utils';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { EmailValidate } from "../../../common/utils/emailvalidation.utils";
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import {Observable,	Subscription} from 'rxjs/Rx';
import { ProfileService } from '../../../profile/services/profile.service';
import { Globals } from '../../../global';
@Component({
	selector: 'user-detail',
	templateUrl: './user.detail.component.html',
	styleUrls: ['./user.detail.component.scss']
})
export class UserDetailComponent extends CedentEntityDetailComponent < IUser > implements OnInit {

	private _pw1: ElementRef;
	private _pw2: ElementRef;
	private validationErrors: Array < string > ;

	myObserver = null;
	public roles: IRole[];
	public roleSelected: IRole;
	protected snackBar: MdSnackBar;
	public country: ICountry[];
	public countrySelected: ICountry;
	public pricingTemplate: IPricingTemplate[];
	public pricingTempSelect: IPricingTemplate;
	public cedentID: IsearchData[];
	private _message: IUser;
	private localStorageService = new LocalStorageService;
	public userstatus ;
	public Selectstatus;
	existError: string;
	loadingFlag: string;
	countrycode : string;
	countryChoosen : string;
	error: string;	
	private displayFlag:String="";
	show:string;
	userRoles:string;

	get pw1(): ElementRef {
		return this._pw1;
	}

	get pw2(): ElementRef {
		return this._pw2;
	}

	get pwPlaceholder(): string {
		return (!this.pw1 || StringUtils.isNullUndefinedOrEmpty(this.pw1.nativeElement.value)) ?
			this._translate.instant("login.passwordunchanged") :
			this._translate.instant("login.password");
	}
	

	@ViewChild('pw1') set pw1(element: ElementRef) {
		this._pw1 = element;
	}
	@ViewChild('pw2') set pw2(element: ElementRef) {
		if (!element) {
			return;
		}
		this._pw2 = element;

		Observable.fromEvent(element.nativeElement, 'keyup')
			.debounceTime(150)
			.distinctUntilChanged()
			.subscribe(() => {

				this.validationErrors.length = 0;

				if (!this.passwordsAreEqual()) {
					this.error = 'passwordsdontmatch';
				} else {
					this.error = undefined;
				}
			});
	}
	
	/*
		Calling the cedent ID list and User type from web service to get the list once we come from edit case.
	*/
	public set cedentEntity(entity: IUser) {
		entity.UserCedentID = entity.UserCedentID;
		this.globals.cedentStatus="Create";
		if(NullUndefined(entity.Identifier)!=""){
			var rootcedentId = getCedentId();
			this.fetchRecord("CedentIDList","CedentCreation",NullUndefined(entity.UserCountry),NullUndefined(entity.UserCountryCode),NullUndefined(rootcedentId));
			let userRole = entity.Roles[0];
			//console.log(userRole);
			this.globals.cedentStatus="Update";
			// this.roleSelected = userRole.Name;
			this.callmethod(entity.Roles)
			
		}
		this._message = entity;
	}


	public get cedentEntity() {
		return this._message;
	}
	
	callmethod(role){
		if(NullUndefined(this.globals.loginUserRole)=="")
		{
			this.myObserver=this.profileService.getAuthenticatedProfile().subscribe(
				response => {
					var result = response;
					if(NullUndefined(result)!=""){
						this.globals.loginUserRole=result.Roles[0].Name;
						if (this.globals.loginUserRole == RoleNames.MR_PLATFORMMANAGER)
							this.show = "";
						else 
							this.show = "true";
						
						
						console.log("this.globals.loginUserRole "+ this.globals.loginUserRole)
						console.log("RoleNames.MR_PLATFORMMANAGER "+ RoleNames.MR_PLATFORMMANAGER)
						if (this.globals.loginUserRole == RoleNames.CE_PLATFORMMANAGER)
							this.userRoles = "CEDENT"
						else if (this.globals.loginUserRole == RoleNames.MR_PLATFORMMANAGER)
							this.userRoles = "REINSURER"
						else 
							this.userRoles = "CEDENT"
						this.fetchUserType(role);
					}
				}, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
				}
			);
		}else{
			if (this.globals.loginUserRole == RoleNames.MR_PLATFORMMANAGER)
				this.show = "";
			else 
				this.show = "true";
				if (this.globals.loginUserRole == RoleNames.CE_PLATFORMMANAGER)
					this.userRoles = "CEDENT"
				else if (this.globals.loginUserRole == RoleNames.MR_PLATFORMMANAGER)
					this.userRoles = "REINSURER"
				else 
					this.userRoles = "CEDENT"
				this.fetchUserType(role);
		}
	}

	constructor(
		injector: Injector,
		private userService: UserService,
		private roleService: RoleService,
		private configurationService: ConfigurationService,
		private _translate: TranslateService,
		private profileService: ProfileService,
		public globals: Globals
	) {
		super(injector, userService);
		this.validationErrors = new Array < string > ();
		this.snackBar = injector.get(MdSnackBar);
	}

	async ngOnInit() {
		this.loadingFlag = "loading...";
		super.ngOnInit();
		// this.fetchRole();
		// this.roles = this.configurationService.getRoles().map(r => {
		//   //let sel = user.Roles.find(ur => ur.Name === r) !== undefined;
		//   return <IRoleBindModel>{role: r, selected: false};
		// });
		this.callmethod('');
		/*console.log("Login Role "+this.globals.loginUserRole);
		if (this.globals.loginUserRole == RoleNames.MR_PLATFORMMANAGER)
			this.show = "";
		else 
			this.show = "true";*/
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
		
		this.fetchCountry();
		// this.fetchUserType("");
		//this.cedentEntity.UserStatus="Active";
		
		 this.userstatus = activestatus;
		 if(this.cedentEntity!=undefined)
		 this.cedentEntity.UserStatus = activestatus[0].label;
		 //this.Selectstatus =activestatus[0].label;		
	}
	

	private async fetchRole(){
		var promises = [];
		var rolePromise = this.roleService.getEntities().first().toPromise();
		promises.push(rolePromise);
		
		if (this.isExistEntity) {
			var userPromise = this.entityLoaded.first().toPromise();
			promises.push(userPromise);
		}

		var result = await Promise.all(promises);

		this.roles = result[0];

		//if (this.isExistEntity) {
			var user = result[1];

			if (user && user.Roles && user.Roles.length > 0) {
				let userRole = user.Roles[0];
				this.roleSelected = this.roles.find(r => r.Name == userRole.Name);
			}
		//}
	}

	private async fetchCountry() {
		var countryPromise = this.searchRecord('Country', 'Country', "", "", "")
			.subscribe(
				response => {
					var result = response;
					if (result.length > 0 && result != "No Data Found") {
                        this.country = result;                        
					} else {
						this.country = [];
						this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {
							duration: 3500
						})
					}
					this.loadingFlag = "";
				}, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {
						duration: 3500
					})
					this.loadingFlag = "";
					return;
				}
			);
		//this.fetchUserType("");
		this.userstatus = activestatus;
		this.loadingFlag = "";
	}

	/*
		Function called whenever country drop down is changed.
		It internally calls fetch record for cedent id created for the country selected.
	*/
	public changeCountry() {
		if (this.countryChoosen != "" && this.countryChoosen != this.cedentEntity.UserCountry) {
			this.loadingFlag = "Loading...";
			for (let cnt = 0; cnt < this.country.length; cnt++) {
				if (this.cedentEntity.UserCountry == this.country[cnt].CountryName) {
					this.countrycode = this.country[cnt].CountryCode;
					this.cedentEntity.UserCountryCode = this.countrycode;
					break;
				}
			}
			this.cedentEntity.UserCedentName = "";
			var rootcedentId = getCedentId();
			this.fetchRecord("CedentIDList", "CedentCreation", NullUndefined(this.cedentEntity.UserCountry), NullUndefined(this.cedentEntity.UserCountryCode), NullUndefined(rootcedentId));
			this.countryChoosen = this.cedentEntity.UserCountry;
			this.loadingFlag = "";
		}
	}
	
	/*
		Function fetch the details of parameter passed.
		webPage : Controller to be called.
		webmethod : Method name to be passed if any for any validation if required(For future use).
		webParam1 : Parameter1 on which search should happen.
		webParam2 : Parameter2 on which search should happen .
		cedentId : Cedent ID on which filter should happen.
	*/
	private async fetchRecord(webPage,webmethod,webParam1,webParam2,cedentId){
		this.loadingFlag="Loading...";
		var promises = [];
		if (NullUndefined(cedentId) == "")
		{ 
			cedentId = this.localStorageService.get("superAdminID"); 
		}
		/*var seqnoPromise = this.searchRecord(NullUndefined(webPage),NullUndefined(webmethod),NullUndefined(webParam1),NullUndefined(webParam2),NullUndefined(cedentId)).toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			return;
		});
		promises.push(seqnoPromise);
		if(this.isExistEntity) {
		  var userPromise = this.entityLoaded.first().toPromise();
		  promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		if(result[0].length>0){
			this.cedentID = result[0];
		}else{
			this.cedentID=[];
			this.cedentEntity.UserCedentID="";
			this.cedentEntity.UserName="";
		}*/
		
		var seqnoPromise =this.searchRecord(NullUndefined(webPage),NullUndefined(webmethod),NullUndefined(webParam1),NullUndefined(webParam2),NullUndefined(cedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.cedentID = result;
					this.snackBar.dismiss();
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.cedentDetails"), null, {duration: 3500})
					this.cedentID=[];
					this.cedentEntity.UserCedentID="";
					this.cedentEntity.UserName="";
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}
	
	/*
		Fetch the usert type list.
	*/
	private async fetchUserType(roleSelected) {
		this.loadingFlag="Loading...";
		console.log("roleSelected edit case:"+roleSelected);
        /*var usertypepromises = [];
		var pricingTemplatePromise = this.searchRecord('UserType','CEDENTROLEDDL',"CEDENT","REINSURER","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			return;
		});
		usertypepromises.push(pricingTemplatePromise);
		if(this.isExistEntity) {
		  var templatePromise = this.entityLoaded.first().toPromise();
		  usertypepromises.push(templatePromise);
		}
		var result = await Promise.all(usertypepromises);
		this.roles = result[0];
		
		if(this.isExistEntity){
			var user = result[1];
			if(user && user.Roles && user.Roles.length > 0){
				let userRole = user.Roles[0];
				this.roleSelected =  this.roles.find(r => r.id === userRole.id);
			}
		}*/		
		var userRole = this.userRoles;
		/*console.log("this.globals.loginUserRole "+ this.globals.loginUserRole)
		console.log("RoleNames.MR_PLATFORMMANAGER "+ RoleNames.MR_PLATFORMMANAGER)
		if (this.globals.loginUserRole == RoleNames.CE_PLATFORMMANAGER)
			userRole = "CEDENT"
		else if (this.globals.loginUserRole == RoleNames.MR_PLATFORMMANAGER)
			userRole = "REINSURER"
		else 
			userRole = "CEDENT"*/
		var pricingTemplatePromise =this.searchRecord('UserType','CEDENTROLEDDL',userRole,"","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.roles = result;
					//var user = result;
					console.log("roleSelected1:"+roleSelected);
					if(NullUndefined(roleSelected)==="" && this.displayFlag==""){
						//this.cedentEntity.UserStatus="Active";
						this.displayFlag="Y";
					}
					if(roleSelected && roleSelected[0].Name && roleSelected.length > 0){
						let userRole = roleSelected[0];
						this.roleSelected =  this.roles.find(r => r.Name == userRole.Name);
					}
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchUserType"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }
	
	
	/*
		To fetch cedent name whenever cedent Id is changed from drop down.
	*/
	public changeCedentID(){
		for(let cnt=0;cnt<this.cedentID.length;cnt++){
			if(this.cedentEntity.UserCedentID == this.cedentID[cnt].CedentLoginID){
                this.cedentEntity.UserCedentName = this.cedentID[cnt].CedentName;
				this.cedentEntity.UserCedentID=this.cedentID[cnt].CedentLoginID;
				break;
			}
		}
	}
	
	/*
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	*/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "MobileNo"){
			return this.cedentEntity.UserMobileNo = keyPressvalidUtils.mobileValidationInput(evt,NullUndefined(FieldValue));
			// return keyPressvalidUtils.mobileValidation(evt,NullUndefined(FieldValue));
		}else if (FieldName == "UserName"){
			return keyPressvalidUtils.onlyAlphaDotApo(evt,NullUndefined(FieldValue));
		}else if(FieldName == "UserID"){
			return keyPressvalidUtils.alphaNumeric(evt,NullUndefined(FieldValue));
		}else if(FieldName == "EmailID"){
			return keyPressvalidUtils.emailFormat(evt,NullUndefined(FieldValue));
		}else if(FieldName == "contractNumber"){
			return keyPressvalidUtils.alphaNumeric(evt,NullUndefined(FieldValue));
		}
	}
	
	public validNumber (FieldValue)
	{
		//console.log(this.cedentEntity.UserMobileNo);
		/* let cnt = 0
		for(let index=0;index<FieldValue.length;index++)
		{
			if(FieldValue[index]==0)
				cnt++;
			else if(FieldValue[index] != 0)
				break;
		}
		this.cedentEntity.UserMobileNo=FieldValue.substring(cnt, FieldValue.length); */
	}

	public save(): void {
		if(this._pw1.nativeElement.value !== ""){
			var pwdstatus=keyPressvalidUtils.passwordValidation(this._pw1.nativeElement.value);
			if(NullUndefined(this._pw1.nativeElement.value).length<8){
				this.error = 'validPasswordLength';
				return;
			}
			else if(pwdstatus == false){
				this.error = 'validPasswordFormat';
				return;
			}
		}
		
		if (!this.passwordsAreEqual()) {
			this.error = 'passwordsdontmatch';
			return;
		}
		if (NullUndefined(this.cedentEntity.Identifier) == ''){
			this.error = 'enterIdentifier';
			return;
		}

		if (!this.checkRoles()) {
			return;
		}

		if (this.pw1 && this.pw1.nativeElement.value !== "") {
			this.cedentEntity.Password = this.pw1.nativeElement.value;
		}
		
		
		if (NullUndefined(this.cedentEntity.UserCountry) == '' && this.show == "true"){
			this.error = 'selectCountry';
			return;
		}else if(NullUndefined(this.cedentEntity.UserCedentID) == '' && this.show == "true"){
			this.error = 'selectCedentID';
			return;
		}else if(NullUndefined(this.cedentEntity.UserName) == '' && this.show == "true"){
			this.error = 'enterUserName';
			return;
		}
		/* else if(NullUndefined(this.cedentEntity.UserLoginID) == ''){
			this.error = 'enterUserID';
			return;		
		}else if(NullUndefined(this.cedentEntity.UserLoginID).length < 6){
			this.error = 'validUserID';
			return;		
		} */
		else if(NullUndefined(this.cedentEntity.UserStatus) == ''){
			this.error = 'selectStatus';
			return;
		}else if(NullUndefined(this.cedentEntity.UserEmailID) == ''){
			this.error = 'enterEmailID';
			return;
		} else if(EmailValidate(NullUndefined(this.cedentEntity.UserEmailID)) == false){
			this.error = 'enterValidEmailID';
			return;
		} else if(NullUndefined(this.cedentEntity.UserMobileNo) == ''){
			this.error = 'enterMobileNo';
			return;
		} else if(NullUndefined(this.cedentEntity.UserMobileNo).length < 4){
			this.error = 'validMobileNo';
			return;
		} else{
			//this.cedentEntity.Password="Test123!";
			this.error = '';
			this.loadingFlag = "Saving data...";
			if(this.globals.cedentStatus=="Create"){
				this.globals.cedentCreateStatus="Save";
			}
			super.save();
		}
		// super.save();
	}
	
	
	public goBack(): void {
		this.globals.cedentStatus="";
		super.goBack();
	}
	
	
	/*
		To clear all the selected value when click on reset button. 
	*/
	public resetData() : void {
		this.cedentEntity.Identifier="";
		this.cedentEntity.UserCountry = undefined;
		this.cedentEntity.UserCedentID = undefined;
		this.cedentEntity.UserCedentName = "";
		this.cedentEntity.UserName = "";
		this.cedentEntity.UserLoginID = "";
		this.roleSelected=undefined;
		this.cedentEntity.UserStatus = "Active";
		this.cedentEntity.UserEmailID = "";
		this.cedentEntity.UserMobileNo = "";
		this.error = '';
	}

	private checkRoles(): boolean {

		if (!this.roleSelected) {
			this.error = 'pleaseselectrole';
			return false;
		}

		if (!this.cedentEntity.Roles) {
			this.cedentEntity.Roles = [];
		}

		if (this.cedentEntity.Roles.length > 1) {
			this.cedentEntity.Roles.length = 0;
		}

		this.cedentEntity.Roles[0] = this.roleSelected;

		return true;
	}

	protected createNewObject(): IUser {
		return new User("", this.cedentId);
	}

	protected onError(error: any): void {
		this.error='';
		this.existError='';
		this.loadingFlag="";
		if(error.Message.lastIndexOf("|") > -1)
		{
			var param = error.Message.split("|");
			this.existError=param[1];
		}else{
			this.error = error.Message;
			console.log(error.Message);
		}
		return;
	}

	private passwordsAreEqual(): boolean {
		let str1: string = this._pw1 ? this._pw1.nativeElement.value : "";
		let str2: string = this._pw2 ? this._pw2.nativeElement.value : "";

		return str1 === str2;
	}

}
