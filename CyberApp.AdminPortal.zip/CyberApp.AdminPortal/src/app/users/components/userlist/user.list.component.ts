import { Component, Injector } from '@angular/core';

import { UserService } from '../../services/user.service';

import { User, UserDataSource } from '../../models';
import { IUser } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';
import { Globals } from '../../../global';

@Component({ 
  templateUrl: './user.list.component.html',
  styleUrls: ['./user.list.component.scss']
})
export class UserListComponent extends CedentEntityListComponent<IUser> {

  displayedColumns = ['id','cedentid', 'contractNumber', 'role', 'delete'];
  dataSource: UserDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("user.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("user.deleteerror");
  }

  constructor(
    injector: Injector,
	public globals: Globals,
    private userService: UserService
  ){
    super(injector, userService);
	console.log("User globals:"+this.globals.cedentStatus);
	if(this.globals.cedentCreateStatus=="Save"){
		this.globals.cedentCreateStatus="";
		this.snackBar.open(this._translateService.instant("cedentusercreation.createsuccess"), null, {duration: 3000});
	}
  }

  
  protected createDataSource(): UserDataSource {
    return new UserDataSource(this.entityService);
  }

  getMessageDelete(user: IUser) {
    var options = { user: user.Identifier };
    return this.getTranslation('user.reallydelete', options);
  }
}