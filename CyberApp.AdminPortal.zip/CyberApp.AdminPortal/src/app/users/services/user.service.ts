import { Injectable } from '@angular/core';

import { IUser } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class UserService
  extends BaseCedentEntityService<IUser> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'user');
  }
}