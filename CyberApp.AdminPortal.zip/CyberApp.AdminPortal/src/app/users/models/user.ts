import { IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class User
  extends CedentEntity
  implements IUser {

  public id: string;
  public Readonly: boolean;

  public Roles: Array<IRole>;
  public Identifier: string;
  public Prefix: string;
  public Password: string;
  public PasswordHash: string;
  
  public UserCountry: string;
  public UserCountryCode: string;
  public UserCedentID: string;
  public UserCedentName: string;
  public UserName: string;
  public UserLoginID: string;
  public UserStatus: string;
  public UserEmailID: string;
  public UserMobileNo: string;

  constructor(identifier: string, cedentId: string){
    super(cedentId);

    this.Identifier = identifier;
  }
}