import { UserService } from '../services/user.service';

import { IUser } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class UserDataSource 
  extends CedentEntityDataSource<IUser>{

  constructor(userService: UserService){
    super(userService);
  }

  buildSearchString(item: IUser): string {
    return (item.Identifier).toLowerCase();
  }
}