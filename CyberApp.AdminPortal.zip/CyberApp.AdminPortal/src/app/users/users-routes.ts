import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { UsersComponent } from './components/users.component';
import { UserListComponent } from './components/userlist/user.list.component';
import { UserDetailComponent } from './components/userdetail/user.detail.component';


export var  usersRoutes: Routes = [
  {
    path: 'users',
    component: UsersComponent,
    canActivateChild: [ IsCedentRoleGuard ],
	data: { roles: [RoleNames.CE_PLATFORMMANAGER, RoleNames.MR_PLATFORMMANAGER]},
    children: [
      {
        path: '',
        component: UserListComponent,
      },
      {
        path: ':id',
        component: UserDetailComponent,
      },
      {
        path: 'create',
        component: UserDetailComponent,
      }
    ]
  }
];
