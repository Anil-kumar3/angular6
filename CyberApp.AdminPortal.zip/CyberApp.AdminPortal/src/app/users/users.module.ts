import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { UsersComponent } from './components/users.component';
import { UserListComponent } from './components/userlist/user.list.component';
import { UserDetailComponent } from './components/userdetail/user.detail.component';
import { CommonModule } from '../common/common.module';
import { UserService } from './services/user.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
	CommonModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdCheckboxModule,
    CdkTableModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    UsersComponent,
    UserListComponent,
    UserDetailComponent
  ], 
  providers: [
    UserService
  ],
  exports: [
    UserListComponent
  ]
})
export class UsersModule { }