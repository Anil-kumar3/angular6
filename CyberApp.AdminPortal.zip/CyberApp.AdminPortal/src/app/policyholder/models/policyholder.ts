import { IPolicyHolder, IRole, IAnsweredQuestion, IMessageTask } from '../../common/models/contracts/models.contracts';
import { User } from '../../users/models/user';

export class PolicyHolder 
  extends User
  implements IPolicyHolder {


  public EMail: string;
  public AnsweredQuestions: IAnsweredQuestion[];
  public MessageTasks: IMessageTask[];
  public PolicyNumber: string;
  public Id: string;

  constructor(policyNumber: string, identifier: string, cedentId: string){
    super(identifier, cedentId);
    this.PolicyNumber = policyNumber;
  }
}
