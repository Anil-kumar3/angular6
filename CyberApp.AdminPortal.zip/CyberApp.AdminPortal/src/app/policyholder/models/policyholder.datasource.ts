import { PolicyHolderService } from '../services/policyholder.service';
import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';


import { IPolicyHolder } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class PolicyHolderDataSource extends CedentEntityDataSource<IPolicyHolder>{

  constructor(policyHolderService: BaseCedentEntityService<IPolicyHolder>){
    super(policyHolderService);
  }

  buildSearchString(item: IPolicyHolder): string {
    return (item.Identifier).toLowerCase();
  }
}