import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CdkTableModule } from '@angular/cdk/table';
import { FormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { 
  MdButtonModule, MdCardModule, MdChipsModule, MdDialogModule, 
  MdIconModule, MdInputModule, MdSnackBarModule, MdTableModule,
  MdProgressBarModule, MdTabsModule
} from '@angular/material';

import { FlexLayoutModule } from "@angular/flex-layout";
import { BrowserModule } from '@angular/platform-browser';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";


import { CommonModule } from '../common/common.module';

//Components
import { policyComponents } from './components';

//services
import { PolicyHolderService, RegistrationService } from './services';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule,
    MdChipsModule,
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdSnackBarModule,
    MdTableModule,
    MdProgressBarModule,
    CdkTableModule,
    MdTabsModule,
    FlexLayoutModule,
    CommonModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    ...policyComponents
  ],
  exports: [],
  providers: [
    PolicyHolderService,
    RegistrationService
  ]
})
export class PolicyHolderModule { }