import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { 
  PolicyHolderComponent, 
  PolicyHolderListComponent, 
  PolicyHolderDetailComponent,
  PolicyImportComponent
} from './components';



export var  policyHolderRoutes: Routes = [
  {
    path: 'policyholders',
    component: PolicyHolderComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    data: {roles: [RoleNames.CEDENT_SALES_SUPPORT,RoleNames.CE_PLATFORMSUPPORT,RoleNames.CE_T1_INCIDENTMANAGER,RoleNames.CE_T2_INCIDENTMANAGER,RoleNames.CE_T3_INCIDENTMANAGER]},
    children: [
      {
        path: '',
        component: PolicyHolderListComponent,
      },
      {
        path: 'import',
        component: PolicyImportComponent
      },
      {
        path: 'create',
        component: PolicyHolderDetailComponent,
      },
      {
        path: ':id',
        component: PolicyHolderDetailComponent,
      }
    ]
  }
];
