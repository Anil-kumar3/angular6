import { Injectable } from '@angular/core';

import { IPolicyHolder } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class PolicyHolderService extends BaseCedentEntityService<IPolicyHolder> {

    constructor(httpServiceFactory: HttpServiceFactory) {
      super(httpServiceFactory, 'policyholder');
    }

    public search(searchString: string){
      return this._entityHttpService.executePostAction('search', { input: searchString, count: 5 });
    }
  }