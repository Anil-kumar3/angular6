﻿import { Injectable } from '@angular/core';

import { IRegistrationService } from './contracts/registration.services.contracts';

import { IPolicyHolder } from '../../common/models/contracts/models.contracts';
import { HttpService, HttpServiceFactory } from '../../common/services/http.service';

import { getCedentId } from '../../common/utils/cedent.utils';

@Injectable()
export class RegistrationService
  implements IRegistrationService {

  private _registrationHttpService: HttpService<IPolicyHolder>;

  constructor(httpServiceFactory: HttpServiceFactory) {
    this._registrationHttpService = httpServiceFactory.getInstance<IPolicyHolder>(getCedentId() + '/registration/resetpasswordadmin');
  }

  public reregister(user: IPolicyHolder): Promise<IPolicyHolder> {
    return this._registrationHttpService.resetPasswort(user);
  }
}