﻿import { IPolicyHolder } from '../../../common/models/contracts/models.contracts';

export interface IRegistrationService {
  reregister(user: IPolicyHolder): Promise<IPolicyHolder>;
}