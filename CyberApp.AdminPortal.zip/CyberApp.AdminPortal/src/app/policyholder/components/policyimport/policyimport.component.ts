import { Component, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { Http } from '@angular/http';
import { Subscription } from 'rxjs/Rx';

// use Fine Uploader core (non-ui) for traditional endpoints
import { FineUploaderBasic  } from 'fine-uploader/lib/core';
import { DragAndDrop } from 'fine-uploader/lib/dnd';

import { getCedentId } from '../../../common/utils/cedent.utils';

@Component({
  selector: 'policyimport',
  templateUrl: './policyimport.component.html',
  styleUrls: ['./policyimport.component.scss']
})
export class PolicyImportComponent
  implements OnInit, OnDestroy {
    
    @ViewChild('dropArea') dropArea: ElementRef;

    public complete = false;
    public progressValue: number;
    public succeed: number;
    public importing: boolean;
    public unsucceeded: number;

    

  constructor(private http: Http) {  }

  ngOnInit(): void {

    var controller = this;
    var cedentId = getCedentId();

    let uploader = new FineUploaderBasic({
        button: this.dropArea.nativeElement,
        request: {
            endpoint: 'api/' + cedentId + '/csvuploader'
        },
        callbacks: {
          onComplete(fielId: number, name: string, response: any){
            controller.complete = true;
            controller.importing = true;
            this.progressValue = 0;
            this.succeed = 0;
            this.unsucceeded = 0;
            controller.watchTask(response.taskId);
          }
        }
    });

    var dragAndDropModule = new DragAndDrop({
      dropZoneElements: [this.dropArea.nativeElement],
      classes: {
          dropActive: "drag-active"
      },
      callbacks: {
          processingDroppedFilesComplete: function(files, dropTarget) {
            uploader.addFiles(files); //this submits the dropped files to Fine Uploader
            uploader.uploadStoredFiles();
          }
      }
  });
  }

  ngOnDestroy() {
    
  }

  private async watchTask(taskId: string){
    var cedentId = getCedentId();

    var result: TaskResult = await this.http.get('api/' + cedentId + '/csvuploader/'+ taskId)
    .map(res => res.json())
    .first().toPromise();

    if(result.error){
      return;
    }

    this.progressValue = result.progress;
    this.succeed = result.succeed;
    this.unsucceeded = result.unsucceeded;

    if(result.progress === 100){
      this.importing = false;
      return;
    }

    setTimeout(() => this.watchTask(taskId), 1000);
  }

}

interface TaskResult {
  error: string;
  progress: number;
  succeed: number;
  unsucceeded: number;
}