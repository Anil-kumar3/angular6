﻿import { Component, Injector } from '@angular/core';

import { PolicyHolderService } from '../../services/policyholder.service';

import { PolicyHolderDataSource } from '../../models/policyholder.datasource';
import { IPolicyHolder } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({
  templateUrl: './policyholder.list.component.html',
  styleUrls: ['./policyholder.list.component.scss']
})
export class PolicyHolderListComponent 
  extends CedentEntityListComponent<IPolicyHolder> {

  displayedColumns = ['id', 'policyNumber', 'identifier', 'email', 'delete'];
  dataSource: PolicyHolderDataSource | null;

  get messageDeleteSuccess(): string {
    return this.getTranslation("policyholder.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("policyholder.deleteerror");
  }

  constructor(injector: Injector, private policyHolderService: PolicyHolderService){
    super(injector, policyHolderService);
  }

  protected createDataSource(){
    return new PolicyHolderDataSource(this.entityService);
  }

  getMessageDelete(policyHolder: IPolicyHolder) {
    var options = { policyHolder: policyHolder.Identifier };
    return this.getTranslation('policyholder.reallydelete', options);
  }

  public goToImportPage(){
    this.router.navigate(['import'], { relativeTo: this.route });
  }
}