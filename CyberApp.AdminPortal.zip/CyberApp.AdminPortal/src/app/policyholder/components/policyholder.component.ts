import { Component } from '@angular/core';


@Component({
  selector: 'policyholder',
  template: '<router-outlet></router-outlet>'
})
export class PolicyHolderComponent {

  constructor(  ) {}
}