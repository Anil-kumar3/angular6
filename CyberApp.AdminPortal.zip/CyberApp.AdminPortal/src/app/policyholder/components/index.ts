export { PolicyHolderComponent } from './policyholder.component';
export { PolicyHolderListComponent } from './policyholderlist/policyholder.list.component';
export { PolicyHolderDetailComponent } from './policyholderdetail/policyholder.detail.component';
export { PolicyImportComponent } from './policyimport/policyimport.component';

import { PolicyHolderComponent } from './policyholder.component';
import { PolicyHolderListComponent } from './policyholderlist/policyholder.list.component';
import { PolicyHolderDetailComponent } from './policyholderdetail/policyholder.detail.component';
import { PolicyImportComponent } from './policyimport/policyimport.component';

export var policyComponents = [
    PolicyHolderComponent,
    PolicyHolderListComponent,
    PolicyHolderDetailComponent,
    PolicyImportComponent
];
