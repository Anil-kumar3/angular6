﻿import { Component, OnInit, OnDestroy, Injector } from '@angular/core';
import { Subscription } from 'rxjs/Rx';

import { PolicyHolderService } from '../../services/policyholder.service';
import { RegistrationService } from '../../services/registration.service';

import { PolicyHolder } from '../../models/policyholder';

import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { IPolicyHolder, IQuestionnaireItem, IQuestionnaireAnswer, IMessageTask } from '../../../common/models/contracts/models.contracts';

import { QuestionnaireService } from "../../../questionnaire/services/questionnaire.service";


type AnsweredQuestion = { id: string, title: string, answers: IQuestionnaireAnswer[] };

@Component({
  selector: 'policyholder-detail',
  templateUrl: './policyholder.detail.component.html',
  styleUrls: ['./policyholder.detail.component.scss']
})
export class PolicyHolderDetailComponent
  extends CedentEntityDetailComponent<IPolicyHolder>
  implements OnInit, OnDestroy {
    
    private questionSubscription: Subscription;
    public answeredQuestions: AnsweredQuestion[] = [];
    public messageTasks : IMessageTask[];

  constructor(
    injector: Injector,
    private policyHolderService: PolicyHolderService,
    private registrationService: RegistrationService,
    private questionnaireService: QuestionnaireService
  ) {
    super(injector, policyHolderService);
   }

  ngOnInit(): void {
    super.ngOnInit();
  }

  ngOnDestroy() {
    if(this.questionSubscription){
      this.questionSubscription.unsubscribe();
      this.questionSubscription = undefined;
    }
  }

  protected async onEntityLoaded(){

    if(!this.cedentEntity.AnsweredQuestions || this.cedentEntity.AnsweredQuestions.length === 0){
      return;
    }

    this.messageTasks = this.cedentEntity.MessageTasks.filter(mt => mt.IsTask === true && mt.IsServer === true);

    var questions = await this.questionnaireService.getEntities().first().toPromise();

    for(let question of questions){
      let includedQuestion = this.cedentEntity.AnsweredQuestions.find(aq => aq.QuestionId === question.id);
      if(!includedQuestion){
        continue;
      }

      let answers = includedQuestion.GivenAnswers.map(ga => question.Answers.find(a => a.UniqueId === ga));
      
      this.answeredQuestions.push({
        id: question.id,
        title: question.Title,
        answers: answers
      });
    }
  }

  protected resetPassword(): void {
    this.registrationService.reregister(this.cedentEntity)
      .then(() => this.goBack());
  }

  protected createNewObject(): IPolicyHolder {
    return new PolicyHolder("", "", this.cedentId);
  }
}