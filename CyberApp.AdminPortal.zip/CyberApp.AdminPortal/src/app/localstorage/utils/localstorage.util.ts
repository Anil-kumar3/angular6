export enum ExpiredUnit {
  SECONDS,
  MINUTES,
  HOURS,
  DAYS,
  WEEKS,
  YEARS,
  TICKS
}

export class StorageUtil {
  static get(storage: Storage, key: string) {

    let item = storage.getItem(key);
    if (item === null) { 
      return null
    };

    let itemObj = StorageUtil.parse(item);

    if (itemObj._expired !== 0
      && +new Date() > itemObj._expired){
      
      console.log("Token expired on "+ new Date(itemObj._expired) +". Removing...")
      StorageUtil.remove(storage, key);
      return null;
    }
    return itemObj._value;
  }

  static set(storage: Storage, key: string, value: any, expiredAt: number = 0, expiredUnit: ExpiredUnit = ExpiredUnit.TICKS) {
    let expired = StorageUtil.getExpired(expiredAt, expiredUnit);
    console.log("Expires in: ");
    console.log(expired);
    
    storage.setItem(key, StorageUtil.stringify({
      _expired: StorageUtil.getExpired(expiredAt, expiredUnit),
      _value: value
    }));
  }

  static remove(storage: Storage, key: string) {
    storage.removeItem(key);
  }

  private static parse(text: string) {
    try {
      return JSON.parse(text) || null;
    } catch (e) {
      return text;
    }
  }

  private static getExpired(val: number, unit: ExpiredUnit): number {
    if (val <= 0) return 0;
      let now = new Date();
      switch (unit) {
        case ExpiredUnit.SECONDS:
          return +now.setSeconds(now.getSeconds() + val);
        case ExpiredUnit.MINUTES:
          return +now.setMinutes(now.getMinutes() + val);
        case ExpiredUnit.HOURS:
          return +now.setHours(now.getHours() + val);
        case ExpiredUnit.DAYS:
          return +now.setDate(now.getDate() + val);
        case ExpiredUnit.WEEKS:
          return +now.setDate(now.getDate() + (val + 7));
        case ExpiredUnit.YEARS:
          return +now.setFullYear(now.getFullYear() + val);
        case ExpiredUnit.TICKS:
          return +now + val;
      }
      return 0;
    }

    private static stringify(value: any) {
      return JSON.stringify(value);
    }

}