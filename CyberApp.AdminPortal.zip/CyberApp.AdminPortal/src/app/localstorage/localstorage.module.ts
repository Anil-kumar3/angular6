import { NgModule } from '@angular/core';

import { LocalStorageService } from './services/localstorage.service';

@NgModule({
  providers: [
    LocalStorageService
  ]
})
export class LocalStorageModule {}