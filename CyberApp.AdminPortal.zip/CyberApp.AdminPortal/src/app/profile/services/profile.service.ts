import { Injectable } from '@angular/core';

import { ProfileHttpService } from './profile.http.service';

import { IPolicyHolder, IRole, RoleNames } from '../../common/models/contracts/models.contracts';


import { Observable } from 'rxjs/Rx';

@Injectable()
export class ProfileService {

  constructor(private _profileHttpService: ProfileHttpService){ }

  public hasRole(roles: string[], cedentId: string): Promise<boolean> {

    return new Promise<boolean>((resole, reject) => {
      let subscription = this.getAuthenticatedProfile().subscribe((usr: IPolicyHolder) => {
        if(usr === null || usr === undefined || !usr.CedentId || usr.CedentId !== cedentId){
          resole(false);
          return;
        }
        for (let role2Check of roles) {
          let role = usr.Roles.find(r => r.Name === role2Check);
          if (role) {
            resole(true);
            return;
          }
        }

        resole(false);
        subscription.unsubscribe();
      });
    });
  }

  
  public getAuthenticatedProfile(): Observable<IPolicyHolder> {
    return this._profileHttpService.getProfile();
  }

  public clearProfile() {
    this._profileHttpService.clearProfile();
  }

  public refreshProfile() {
    this._profileHttpService.refreshProfile();
  }
}