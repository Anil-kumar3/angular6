import { Injectable } from '@angular/core';

import { IPolicyHolder } from '../../common/models/contracts/models.contracts';
import { HttpService } from '../../common/services/http.service';
import { AuthenticatedHttpService } from '../../common/services/authenticated.http.service';

import { Observable, ReplaySubject } from 'rxjs/Rx';

@Injectable()
export class ProfileHttpService {

  private _profileReplaySubject: ReplaySubject<IPolicyHolder>;
  private profileRequested = false;
  private profileSeq =false; /** Flag used to block multiple calling of profile service and side menu **/
  
  private _url: string = '/profile/me'; /** For Local URL: '/profile/me'; For Serevr URL: '/Cyruss/profile/me' **/

  constructor(private _http: AuthenticatedHttpService) {
    this._profileReplaySubject = new ReplaySubject<IPolicyHolder>(1);
  }

  public getProfile(): Observable<IPolicyHolder> {
     if(!this.profileRequested) {
       this.refreshProfile()
     }

    return this._profileReplaySubject.asObservable();
  }

  public clearProfile()  {
    this.profileRequested = false;
    this._profileReplaySubject.next(undefined);
  }

  public refreshProfile(){
    this.profileRequested = true;
	if(this.profileSeq == false){
		this.profileSeq = true;
		this._http.get(this._url)
		.map(response => response.json())
		.subscribe(
		  profile => {
			this._profileReplaySubject.next(profile);
			this.profileSeq=false;
		  },
		error => {
			this.profileSeq=false;
		  this._profileReplaySubject.next(undefined);
		});
	}
  }
}