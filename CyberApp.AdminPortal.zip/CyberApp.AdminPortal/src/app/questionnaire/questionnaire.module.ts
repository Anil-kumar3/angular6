import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CdkTableModule } from '@angular/cdk/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { 
  MdButtonModule, MdCardModule, 
  MdCheckboxModule, MdChipsModule, 
  MdDialogModule, MdIconModule, 
  MdInputModule, MdSelectModule, 
  MdSnackBarModule, MdTableModule,
  MdSlideToggleModule
} from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';

import { BrowserModule } from '@angular/platform-browser';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { CommonModule } from '../common/common.module';

//Components
import { QuestionnaireComponent } from './components/questionnaire.component';
import { QuestionnaireAnswerDetailComponent } from './components/questionnaireanswerdetail/questionnaire.answer.detail.component';
import { QuestionnaireDetailComponent } from './components/questionnairedetail/questionnaire.detail.component';
import { QuestionnaireListComponent } from './components/questionnairelist/questionnaire.list.component';

//Services
import { QuestionnaireService } from './services/questionnaire.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule,
    MdCheckboxModule,
    MdSlideToggleModule,
    MdChipsModule,
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdSelectModule,
    MdSnackBarModule,
    MdTableModule,
    CdkTableModule,
    FlexLayoutModule,
    CommonModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    QuestionnaireComponent,
    QuestionnaireAnswerDetailComponent,
    QuestionnaireDetailComponent,
    QuestionnaireListComponent
  ],
  providers: [
    QuestionnaireService
  ],
  entryComponents: [
    QuestionnaireAnswerDetailComponent
  ]
})
export class QuestionnaireModule { }
