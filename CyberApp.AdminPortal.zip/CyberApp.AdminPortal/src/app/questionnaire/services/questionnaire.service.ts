import { Injectable } from '@angular/core';

import { IQuestionnaireItem } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class QuestionnaireService
  extends BaseCedentEntityService<IQuestionnaireItem> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'questionairequestion');
  }
}