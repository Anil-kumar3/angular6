import { Component, OnInit, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MdDialogRef, MD_DIALOG_DATA } from '@angular/material';

import { IQuestionnaireAnswer, recurrenceTaskIntervalls } from '../../../common/models/contracts/models.contracts';
import { MessageTask } from '../../../messages/models/messagetask';
import { StringUtils } from '../../../common/utils/string.utils';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Component({
  moduleId: module.id,
  selector: 'questionnaireanswer-detail',
  templateUrl: './questionnaire.answer.detail.component.html',
  styleUrls: ['./questionnaire.answer.detail.component.scss']
})
export class QuestionnaireAnswerDetailComponent
  implements OnInit {

  cedentEntity: IQuestionnaireAnswer;
  cedentEntityTitle: string;
  cedentEntitySeverity: number;
  messageTitle: string;
  messageSubTitle: string;
  messageDescription: string;
  taskRecurrencyIntervalDays: number = 0;

  public recurrenceTaskIntervalls;

  private _dialogRef: MdDialogRef<QuestionnaireAnswerDetailComponent>;

  constructor(
    dialogRef: MdDialogRef<QuestionnaireAnswerDetailComponent>,
    @Inject(MD_DIALOG_DATA) public data: any
  ){
    this._dialogRef = dialogRef;
    this.cedentEntity = data.entity;
    this.cedentEntityTitle = this.cedentEntity.Title;
    this.cedentEntitySeverity = this.cedentEntity.Severity;
    if (this.cedentEntity.CompulsoryMessageTask !== null) {
      this.messageTitle = this.cedentEntity.CompulsoryMessageTask.Title;
      this.messageSubTitle = this.cedentEntity.CompulsoryMessageTask.SubTitle;
      this.messageDescription = this.cedentEntity.CompulsoryMessageTask.Description;
      this.taskRecurrencyIntervalDays = this.cedentEntity.CompulsoryMessageTask.RecurrencyIntervalDays;
    }
  }

  ngOnInit(): void {
    this.recurrenceTaskIntervalls = recurrenceTaskIntervalls;
  }

  get isValid(): boolean {
    var isValidMessage: boolean = !StringUtils.isNullUndefinedOrEmpty(this.messageTitle) &&
                                  !StringUtils.isNullUndefinedOrEmpty(this.messageSubTitle) &&
                                  !StringUtils.isNullUndefinedOrEmpty(this.messageDescription);
    return !StringUtils.isNullUndefinedOrEmpty(this.cedentEntityTitle) &&
      (this.cedentEntitySeverity === 1 ||
      ((this.cedentEntitySeverity === 2 || this.cedentEntitySeverity === 3) && isValidMessage));
  }
  
  submit(): void {
    if (this.isValid) {
      this.cedentEntity.Title = this.cedentEntityTitle;
      this.cedentEntity.Severity = this.cedentEntitySeverity;
      if (this.cedentEntity.Severity === 1) {
        this.cedentEntity.CompulsoryMessageTask = null;
      }
      else {
        if (this.cedentEntity.CompulsoryMessageTask === null) {
          this.cedentEntity.CompulsoryMessageTask = new MessageTask("", "", "", this.cedentEntity.CedentId, [], []);
        }
        this.cedentEntity.CompulsoryMessageTask.Title = this.messageTitle;
        this.cedentEntity.CompulsoryMessageTask.SubTitle = this.messageSubTitle;
        this.cedentEntity.CompulsoryMessageTask.Description = this.messageDescription;
        this.cedentEntity.CompulsoryMessageTask.CreatedFromQuestionaireAnswerId = this.cedentEntity.UniqueId;
        if (this.cedentEntity.Severity === 2) {
          this.cedentEntity.CompulsoryMessageTask.IsTask = false;
          this.cedentEntity.CompulsoryMessageTask.RecurrencyIntervalDays = 0;
          this.cedentEntity.CompulsoryMessageTask.TaskSeverity = 0;
        }
        if (this.cedentEntity.Severity === 3) {
          this.cedentEntity.CompulsoryMessageTask.IsTask = true;
          this.cedentEntity.CompulsoryMessageTask.RecurrencyIntervalDays = this.taskRecurrencyIntervalDays;
          this.cedentEntity.CompulsoryMessageTask.TaskSeverity = 3;
        }
      }
      this._dialogRef.close(this.cedentEntity);
    }
  }

  goBack(): void {
    this._dialogRef.close(null);
  }

}
