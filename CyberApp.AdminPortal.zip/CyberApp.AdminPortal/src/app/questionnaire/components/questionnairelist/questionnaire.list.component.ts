import { Component, Injector } from '@angular/core';

import { QuestionnaireService } from '../../services/questionnaire.service';
import { QuestionnaireDataSource } from '../../models/questionnaire.datasource';
import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

import { IQuestionnaireItem } from '../../../common/models/contracts/models.contracts';

@Component({ 
  templateUrl: './questionnaire.list.component.html',
  styleUrls: ['./questionnaire.list.component.scss']
})
export class QuestionnaireListComponent extends CedentEntityListComponent<IQuestionnaireItem> {
  
  displayedColumns = ['title', 'weight', 'isExposure', 'delete'];


  get messageDeleteSuccess(): string {
    return this.getTranslation("questionnaire.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("questionnaire.deleteerror");
  }

  constructor(injector: Injector, private questionnaireService: QuestionnaireService){
    super(injector, questionnaireService);
  }

  protected createDataSource(){
    return new QuestionnaireDataSource(this.entityService);
  }

  getMessageDelete(questionnaireItem: IQuestionnaireItem) {
    var options = { questionnaireItem: questionnaireItem.id };
    return this.getTranslation('questionnaire.reallydelete', options);
  }
}