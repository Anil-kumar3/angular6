import { Component, OnInit, OnDestroy, Injector } from '@angular/core';
import { MdSlideToggleChange, MdDialog, MdDialogRef } from '@angular/material';

import { BehaviorSubject, Subscription, Observable } from 'rxjs/Rx';

import { TranslateService } from '@ngx-translate/core';

import { remove } from 'lodash-es';

import { QuestionnaireService } from '../../services/questionnaire.service';

import { AnswerDataSource } from '../../models/answer.datasource';
import { QuestionnaireAnswer } from '../../models/questionnaireanswer';
import { QuestionnaireItem } from '../../models/questionnaireitem';
import { MessageTask } from '../../../messages/models/messagetask';

import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { QuestionnaireAnswerDetailComponent } from '../questionnaireanswerdetail/questionnaire.answer.detail.component';
import { IQuestionnaireItem, IQuestionnaireAnswer } from '../../../common/models/contracts/models.contracts';
import { BaseCedentEntityService } from '../../../common/services/cedent.entity.service';


@Component({
  selector: 'questionnaire-detail',
  templateUrl: './questionnaire.detail.component.html',
  styleUrls: ['./questionnaire.detail.component.scss']
})
export class QuestionnaireDetailComponent 
extends CedentEntityDetailComponent<IQuestionnaireItem>   
implements OnInit, OnDestroy
  {
    displayedColumns = ['title', 'value', 'delete'];

    answersObservable: BehaviorSubject<Array<IQuestionnaireAnswer>>;
    answerSource: AnswerDataSource | null;

    public questions: IQuestionnaireItem[];
    public isDependFrom: boolean = false;

    //public dependAnswerIds : string[] = [];
    //public dependQuestions : Observable<IQuestionnaireItem[]>;
    //private dependQuestionsBehaviour : BehaviorSubject<IQuestionnaireItem[]>

    private questionsSubscription: Subscription;

  constructor(
    private questionnaireService: QuestionnaireService,
    private _translate: TranslateService,
    private _dialog: MdDialog,
    injector: Injector
  ){
    super(injector, questionnaireService);

    this.answersObservable = new BehaviorSubject<Array<IQuestionnaireAnswer>>(new Array());
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.answerSource = new AnswerDataSource(this.answersObservable);


    this.entityLoaded.subscribe(() => {
      this.answersObservable.next(this.cedentEntity.Answers);
      this.isDependFrom = this.cedentEntity.DependencyIds.length > 0;

      this.questionsSubscription = this.questionnaireService.getEntities(true).subscribe(questions => {
        this.questions = questions.filter(q => q.id !== this.cedentEntity.id);
      });

    });

    if(!this.isExistEntity) {

      this.questionsSubscription = this.questionnaireService.getEntities(true).subscribe(questions => {
        this.questions = questions;
      });

    }
  }

  ngOnDestroy() {
    if(this.questionsSubscription){
      this.questionsSubscription.unsubscribe();
      this.questionsSubscription = undefined;
    }
  }

  protected createNewObject(): IQuestionnaireItem {
    return new QuestionnaireItem(this.cedentId);
  }

  public get isValid(): boolean {
    return this.cedentEntity.Title !== "" && this.cedentEntity.Weight !== null;
  }

  public getSeverityTitle(value: number): string {
    switch (value) {
      case 1: return this._translate.instant("questionnaire.severityLow");
      case 2: return this._translate.instant("questionnaire.severityMedium");
      case 3: return this._translate.instant("questionnaire.severityHigh");
      default: return "?";
    }
  }

  protected goToItem(item: IQuestionnaireAnswer): void {
    /*
    if (item.CompulsoryMessageTask === null) {
      item.CompulsoryMessageTask = new MessageTask("", "", "", this.cedentId, [], []);
    }
    */
    let dialog = this._dialog.open(QuestionnaireAnswerDetailComponent, {
      width: '600px',
      data: {
        entity: item
      }
    });
  }

  protected openAddAnswerModal(): void {
    let dialog = this._dialog.open(QuestionnaireAnswerDetailComponent, {
      width: '600px',
      data: {
        entity: new QuestionnaireAnswer(this.cedentId, "", 0, new MessageTask("", "", "", this.cedentEntity.CedentId, [], []))
      }
    });
    dialog.afterClosed().subscribe((result: IQuestionnaireAnswer) => {
      if (result !== null && result !== undefined) {
        this.addAnswer(result);
      }
    })
  }

  private addAnswer(questionnaireAnswer: IQuestionnaireAnswer) {
    this.cedentEntity.Answers.push(questionnaireAnswer);
    this.answersObservable.next(this.cedentEntity.Answers);
  }

  protected deleteAnswer(answer: IQuestionnaireAnswer): void {
    let index = this.cedentEntity.Answers.indexOf(answer);

    if (index >= 0){
      this.cedentEntity.Answers.splice(index, 1);
      this.answersObservable.next(this.cedentEntity.Answers);
    }
  }

  dependFromChanged(event: MdSlideToggleChange){

    this.isDependFrom = event.checked;

    if(!event.checked) {
      this.cedentEntity.DependencyIds.length = 0;
    }

  }
}
