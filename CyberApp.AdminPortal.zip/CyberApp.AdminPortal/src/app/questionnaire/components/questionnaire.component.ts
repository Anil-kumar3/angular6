﻿import { Component} from '@angular/core';

@Component({
  selector: 'questionnaire',
  template: '<router-outlet></router-outlet>'
})
export class QuestionnaireComponent {
}