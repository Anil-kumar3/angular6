import { QuestionnaireComponent } from './questionnaire.component';
import { QuestionnaireDetailComponent } from './questionnairedetail/questionnaire.detail.component';
import { QuestionnaireListComponent } from './questionnairelist/questionnaire.list.component';


export { QuestionnaireComponent } from './questionnaire.component';
export { QuestionnaireDetailComponent } from './questionnairedetail/questionnaire.detail.component';
export { QuestionnaireListComponent } from './questionnairelist/questionnaire.list.component';


export var questionnaireComponents = [
    QuestionnaireComponent, 
    QuestionnaireDetailComponent, 
    QuestionnaireListComponent
];
