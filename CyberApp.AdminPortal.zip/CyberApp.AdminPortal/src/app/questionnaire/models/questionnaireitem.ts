import { IQuestionnaireItem, IQuestionnaireAnswer } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class QuestionnaireItem 
  extends CedentEntity
  implements IQuestionnaireItem {

  public Title: string;
  public Description: string;
  public Weight: number;
  public IsExposure: boolean;
  public IsMultipleChoice: boolean;
  
  public Answers: Array<IQuestionnaireAnswer>;
  public DependencyIds: string[];
  

  constructor(cedentId: string){
    super(cedentId);

    this.Title = "";
    this.Weight = 0;
    this.IsExposure = false;
    this.IsMultipleChoice = false;

    this.DependencyIds = [];
    this.Answers = new Array<IQuestionnaireAnswer>();
  }
}
