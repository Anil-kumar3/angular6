import {DataSource} from '@angular/cdk/table';

import { IQuestionnaireAnswer } from '../../common/models/contracts/models.contracts';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable} from 'rxjs/Observable';

export class AnswerDataSource extends DataSource<any> {

  constructor(private _answers: BehaviorSubject<Array<IQuestionnaireAnswer>>) {
    super();
  }

  /** Connect function called by the table to retrieve one stream containing the data to render. */
  connect(): Observable<IQuestionnaireAnswer[]> {

    const dataChanges = [
      this._answers
    ];

    return Observable.merge(...dataChanges).map(() => {
      return this._answers.value;
    });
  }

  disconnect() {}
}