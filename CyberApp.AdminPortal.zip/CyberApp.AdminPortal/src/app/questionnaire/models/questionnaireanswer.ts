import { IQuestionnaireAnswer, IMessageTask } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class QuestionnaireAnswer
  extends CedentEntity
  implements IQuestionnaireAnswer {

  public Title: string;
  public Value: number;
  public Severity: number;
  public CompulsoryMessageTask: IMessageTask;

  constructor(cedentId: string, title: string, severity: number, messageTask?: IMessageTask) {
    super(cedentId);

    this.Title = title;
    this.Severity = severity;
    this.CompulsoryMessageTask = messageTask;
  }
}
