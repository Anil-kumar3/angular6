import { QuestionnaireService } from '../services/questionnaire.service';

import { IQuestionnaireItem } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class QuestionnaireDataSource 
  extends CedentEntityDataSource<IQuestionnaireItem>{

  constructor(questionnaireService: QuestionnaireService){
    super(questionnaireService);
  }

  buildSearchString(item: IQuestionnaireItem): string {
    return (item.Title).toLowerCase();
  }
}