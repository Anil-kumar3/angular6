import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';


import { QuestionnaireComponent, QuestionnaireDetailComponent, QuestionnaireListComponent } from './components';

export var  questionnaireRoutes: Routes = [
  {
    path: 'questions',
    component: QuestionnaireComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    data: { roles: [ RoleNames.CEDENT_READER, RoleNames.CEDENT_CONTENT_MANAGER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER ] },
    children: [
      {
        path: '',
        component: QuestionnaireListComponent,
      },
      {
        path: ':id',
        component: QuestionnaireDetailComponent,
      },
      {
        path: 'create',
        component: QuestionnaireDetailComponent,
      }
    ]
  }
];
