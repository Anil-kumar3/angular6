import { Component, OnInit, HostListener, Injector,NgModule } from '@angular/core';
import { Router } from '@angular/router';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { IPolicyHolder, IRole, RoleNames, IThreshold } from '../common/models/contracts/models.contracts';
import { AuthenticatedHttpService } from '../common/services/authenticated.http.service';
import { LocalStorageService } from '../localstorage/services/localstorage.service';
import { CedentEntityDetailComponent } from '../common/components/cedent.entity.detail.component';
import { Thresholdsetting } from '../thresholdsetting/models/thresholdsetting';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { ThresholdsettingService } from '../thresholdsetting/services/thresholdsetting.service';


@Component({
  selector: 'payment-screen',
  templateUrl: './paymentScreen.component.html',
  styleUrls: ['./paymentScreen.component.scss']
})

export class PaymentScreenComponent extends CedentEntityDetailComponent < IThreshold > implements OnInit {

  private webURL:string;
  private urlData:any;
  private param:any;
  private refSplit:any;
  private quoteSplit:any;
  private amountSplit:any;
  private referenceNum:string;
  private quoteNum:string;
  private paymentStatus:string;
  private rejectStatus:boolean;
  private refStatus:string;
  private amount:number;
  private reference:string;
  private _policynum:string;
  private Premium:number;
  loadingFlag:string;
  protected snackBar: MdSnackBar;
  
  constructor(injector: Injector,
				private thresholdService: ThresholdsettingService,
  ) { 
	super(injector,thresholdService);
	this.snackBar = injector.get(MdSnackBar);
  }

  

	ngOnInit() {
		/** URL: http://localhost:4200/#/paymentScreen?ref=REF00001&quote=Q00001&premium=5646.34 **/
		// ref=REF00001&quote=Q00001&premium=5646.34
		this.webURL = window.location.href;
		console.log("URL:"+this.webURL);
		this.urlData = this.webURL.split("?");
		this.param = this.urlData[1].split("&");
		this.refSplit=this.param[0].split("=");
		this.quoteSplit=this.param[1].split("=");
		this.amountSplit=this.param[2].split("=");
		this.referenceNum=this.refSplit[1];
		this.quoteNum=this.quoteSplit[1];
		this.Premium=this.amountSplit[1];
		console.log(this.referenceNum+"--"+this.quoteNum+"--"+this.Premium);
		this.paymentStatus="pending";
		
		this.amount=this.Premium;
		this.reference=this.referenceNum;
	}
	
	private payment()
	{
		this.loadingFlag = "Loading data...";
		var countryPromise = this.quoteProcess('QuoteProcess/PaymentProcess',this.referenceNum,"payment","","","")
		.subscribe(
			  response => {
				var result = response;
				console.log(JSON.stringify(result))
				if(result.Status==0)
				{
					this.paymentStatus=result.Message;
					this.loadingFlag=""
				} else if(result.Status==1)
				{
					this.loadingFlag=""
					//this._policynum = result.Data;
					this.paymentStatus=result.Message;
				}
			  }, error => {
				  this.loadingFlag=""
					this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
					return;
			}
		);
	}
	
	/**
		Creating Object for Thresholdsetting
	**/
	protected createNewObject(): IThreshold {
		return new Thresholdsetting("", this.cedentId);
	}
}
