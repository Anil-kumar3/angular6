import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { TranslateService } from '@ngx-translate/core';

import { ConfigurationService } from './configuration/services/configuration.service';
import { ProfileService } from './profile/services/profile.service';
import { CedentService } from './cedent/services/cedent.service';

import { IPolicyHolder, ICedent } from './common/models/contracts/models.contracts';
import { AuthenticatedHttpService } from './common/services/authenticated.http.service';
import { NullUndefined } from "./common/utils/NullUndefined.utils";

import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
//import { Globals } from 'global';

@Component({
  moduleId: module.id,
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent
  implements OnInit {

  title = 'CyRUSS - Admin Portal';
  environmentName: string;
  currentUser: IPolicyHolder;
  cedent: BehaviorSubject<ICedent>;
  public showHeader : string;

  public languages: string[];

  constructor(
    private translate: TranslateService, 
    private configurationService: ConfigurationService, 
    private _profileService: ProfileService,
    private _authService: AuthenticatedHttpService,
    private _router: Router,
    private _cedentService: CedentService
  ){
    translate.addLangs(["en", "de"]);
    translate.setDefaultLang(configurationService.getDefaultLanguage());
    
    this.environmentName = configurationService.getEnvironmentName();
    this.cedent = new BehaviorSubject<ICedent>(null);
  }

  ngOnInit() {
	//this.showHeader="true";
	var str = window.location.href;; 
	var resStatus = str.match(/statusScreen/);
	var resPayment = str.match(/paymentScreen/);
	if ( NullUndefined(resStatus).length > 0){
		this.showHeader="";
	}else if(NullUndefined(resPayment).length>0){
		this.showHeader="";
	}else{
		this.showHeader="true";
	}
    this.languages = this.translate.getLangs();
    
    this._profileService.getAuthenticatedProfile()
    .subscribe((value) => {
      this.currentUser = value;
      if (value){
        this._cedentService.getOwnInformation(value.CedentId, true).subscribe(cedent => this.cedent.next(cedent));
      }
    });

    this._authService.loggedIn.subscribe(islogged => {
      if(!islogged){
        this.onLogout();
      }
    });
  }

  public set currentLanguage(lang: string){
    this.translate.use(lang);
  }

  public get currentLanguage(): string {
    return this.translate.currentLang ? this.translate.currentLang : this.translate.defaultLang;
  }

  public logout(): void {
    this._authService.logout().subscribe({
      complete: () => {
        this.onLogout();
      }
    });
  }

  private onLogout(){
	//this.globals.loginUserRole="";
    this._profileService.clearProfile();
    this._router.navigate(['/login']);
  }

}
