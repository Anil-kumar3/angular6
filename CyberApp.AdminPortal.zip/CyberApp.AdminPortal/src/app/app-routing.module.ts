import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from './login/login.component';
import { StatusScreenComponent } from './statusScreen/statusScreen.component';
import { PaymentScreenComponent } from './paymentScreen/paymentScreen.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login', component: LoginComponent },
  { path: 'statusScreen', component: StatusScreenComponent },
  { path: 'paymentScreen', component: PaymentScreenComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
