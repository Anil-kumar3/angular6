import { Component, OnInit, HostListener } from '@angular/core';
import { MdDialogRef } from '@angular/material';
import { Router } from '@angular/router';

import { ProfileService } from '../profile/services/profile.service';

import { IPolicyHolder, IRole, RoleNames } from '../common/models/contracts/models.contracts';
import { AuthenticatedHttpService } from '../common/services/authenticated.http.service';
import { LocalStorageService } from '../localstorage/services/localstorage.service';

import { PolicyHolder } from '../policyholder/models/policyholder';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Globals } from '../global';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  _loginData = { username: '', password: '',scope:'' };
  credentialsBlocked: string;	
  error: string;	

  get credentialsinvalid(): Observable<boolean> {
	  if(this.globals.loginStatus==""){
		return this._authService.accessDenied;
	  }else{
		  this.credentialsBlocked="Blocked";
		  this.error=this.globals.loginStatus;
		  this.globals.loginStatus="";
	  }
  }

  constructor(
    private _authService: AuthenticatedHttpService,
    private _router: Router,
	public globals: Globals,
	private localStorageService: LocalStorageService,
    private _profileService: ProfileService
  ) { }

  @HostListener('window:keyup', ['$event'])
  keyEvent(event: KeyboardEvent) {
    //Submit on enter
    if (event.keyCode === 13) {
      this.submit();
    }
  }

  ngOnInit() {

    this._authService.loggedIn.subscribe((value: boolean) => {
      if (value === true) {
        this._profileService.clearProfile();
        this._profileService.refreshProfile();
      }
    });


    this._profileService.getAuthenticatedProfile().subscribe(profile => {

      if (profile !== null && profile !== undefined) {
        let isManager = profile.Roles.find(r => r.Name === RoleNames.CEDENT_MANAGER);
		let isSuperUser = profile.Roles.find(r => r.Name === RoleNames.MR_PLATFORMMANAGER);
        if (isManager || isSuperUser) {
		  this.localStorageService.set("superAdminID", profile.CedentId);
          this._router.navigate(["administration"]);
        } else {
          this._router.navigate(["cedent", profile.CedentId]);
        }
      }
    });

  }

  submit(): void {
	  this.credentialsBlocked="";
	this._loginData.scope= JSON.stringify({app:"IM"});//"IM";
    this._authService.login(this._loginData.username, this._loginData.password,this._loginData.scope);
  }
}
