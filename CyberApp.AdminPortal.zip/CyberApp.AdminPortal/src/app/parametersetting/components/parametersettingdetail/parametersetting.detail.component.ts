import {Component, OnInit, Injector, ViewChild, ElementRef} from '@angular/core';
import {FormControl} from '@angular/forms';
import {MdSnackBar} from '@angular/material';
import {TranslateService} from '@ngx-translate/core';
import {RoleService, ParameterService, CountryService} from '../../../cedent/services';
import {IParametersetting, ICountry, IsearchData} from '../../../common/models/contracts/models.contracts';
import {ParametersettingService} from '../../services/parametersetting.service';
import {Parametersetting} from '../../models/parametersetting';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';
import {StringUtils} from '../../../common/utils/string.utils';
import {ConfigurationService} from '../../../configuration/services/configuration.service';
import {Observable, Subscription} from 'rxjs/Rx';
import {keyPressvalidUtils} from "../../../common/utils/keyPress-valid.Utils";
import { getCedentId } from '../../../common/utils/cedent.utils';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { Globals } from '../../../global';


@Component({
    selector: 'parametersetting-detail',
    templateUrl: './parametersetting.detail.component.html',
    styleUrls: ['./parametersetting.detail.component.scss']
})


export class ParametersettingDetailComponent extends CedentEntityDetailComponent<IParametersetting> implements OnInit {
    private validationErrors: Array<string>;
    public country: ICountry[];
    error: string;
    minDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
	maxDate = new Date(new Date().getFullYear(), new Date().getMonth() + (12 - new Date().getMonth()), 0);
    countrycode: string;
    public ParametercedentIdArr: IsearchData[];
    public ParameterArr: IsearchData[];
    public ParametersArr: IsearchData[];
	private _parametersetting: IParametersetting;
	protected snackBar: MdSnackBar;
	search:string;
	loadingFlag:string;
	offset:any;
	private localStorageService = new LocalStorageService

	/**
		Calling the Country list and Parameter Key list from web service to get the list once we come from edit case.
	**/
	public set cedentEntity(entity: IParametersetting) {
		entity.EffectiveDate = new Date(entity.EffectiveDate);
		entity.ParameterCedentId = entity.ParameterCedentId;
		if(NullUndefined(entity.Country) != ""){
			var rootcedentId = getCedentId();
			this.fetchRecord(entity.Country,entity.CountryCode,rootcedentId); 
		}
		if(NullUndefined(entity.ParameterKey) != ""){
			this.fetchParameter();
		}
		
		this._parametersetting = entity;
	}

	/**
		Getting the Country list and ThresholdKey list from web service and assigning it to object once we come from edit case.
	**/
	public get cedentEntity() {
		return this._parametersetting;
	}
  
  
	constructor(
        injector: Injector,
        private cedentcreationService: ParametersettingService,
        private countryService: CountryService,
        private configurationService: ConfigurationService,
        private _translate: TranslateService,
        private roleService: RoleService,
        private parameterService: ParameterService,
		public globals: Globals
    ) {
        super(injector, cedentcreationService);
        this.validationErrors = new Array<string>();
		this.snackBar = injector.get(MdSnackBar);
    }

	/** 
		Function Calling on page load
	**/
    async ngOnInit() {
		this.loadingFlag = "loading...";
        super.ngOnInit();
        
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		
		
		this.fetchParameter();
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
    }

	/**
		Creating Object for Thresholdsetting
	**/
    protected createNewObject(): IParametersetting {
        return new Parametersetting("", this.cedentId);
    }

	/**
		Calling for Field validations and upload data into server.
	**/
    public save(): void {
        if (NullUndefined(this.cedentEntity.Country) == '') {
            this.error = 'selectCountry';
            return;
        } else if (NullUndefined(this.cedentEntity.ParameterCedentId) == '') {
            this.error = 'selectCedentID';
            return;
        } else if (NullUndefined(this.cedentEntity.ParameterKey) == '') {
            this.error = 'selectParameter';
            return;
        }else if (NullUndefined(this.cedentEntity.Value) == '') {
			this.error = 'validParametervalue';
			return;
		}else if (NullUndefined(this.cedentEntity.Value) != '' && !Number(this.cedentEntity.Value)) {
			this.error = 'validValueformat';
			return;
		}/* else if (NullUndefined(this.cedentEntity.Value) != '' && (this.cedentEntity.Value.length < 5)) {
			this.error = 'validParametervalue';
			return;
		} */else if (NullUndefined(this.cedentEntity.EffectiveDate) == "") {
            this.error = 'selectEffectiveDate';
            return;
        } else {
            this.error = '';
			//this.cedentEntity.EffectiveDate=new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
			//console.log("Date:"+this.cedentEntity.EffectiveDate);
			//this.offset = new Date().toString().match(/([A-Z]+[\+-][0-9]+.*)/)[1];
			//this.offset = new Date().toString().match(/([A-Z]+[\+-][0-9]+)/)[1];
			this.cedentEntity.UnderwriterID = NullUndefined(this.globals.loginUserID);
			this.cedentEntity.GMTTimeZone=new Date().toString().match(/\(([A-Za-z\s].*)\)/)[1];
			console.log(this.cedentEntity.GMTTimeZone);
			this.loadingFlag = "Saving data...";
            super.save();
        }
    }
	
	/**
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	**/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "Value"){
			return keyPressvalidUtils.onlyNumeric(evt,NullUndefined(FieldValue));
		}
	}
	
	/** 
		Clear the Field when click on Reset Button
	**/
    public resetData(): void {
        this.cedentEntity.Country = "";
        this.cedentEntity.ParameterCedentId = "";
        this.cedentEntity.CedentName = "";
        this.cedentEntity.ParameterKey = "";
        this.cedentEntity.Value = "";
        this.cedentEntity.EffectiveDate = undefined;
        this.error = "";
    }

	/**
		Function called whenever country drop down is changed.
		It internally calls fetch record for cedent id created for the country selected.
	**/
    public changeCountry() {
		this.loadingFlag="Loading...";
        this.cedentEntity.CedentName = "";
        for (let cnt = 0; cnt < this.country.length; cnt++) {
            if (this.cedentEntity.Country == this.country[cnt].CountryName) {
                this.countrycode = this.country[cnt].CountryCode;
				this.cedentEntity.CountryCode = this.countrycode;
                break;
            }
        }
		var rootcedentId = getCedentId();
        this.fetchRecord(this.cedentEntity.Country,this.countrycode,rootcedentId);
    }

	/**
		Fetching CedentID & CedentName as per Country Selected.
		country: Country name will pass
		countrycode: Country code name will pass
		cedentId: Unique id of the User
	**/
    private async fetchRecord(country,countrycode,cedentId) {
		this.loadingFlag="Loading...";
        var promises = [];
		if (NullUndefined(cedentId) == "")
        {
			cedentId = this.localStorageService.get("superAdminID");
		}
		
		var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(country), NullUndefined(countrycode), NullUndefined(cedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.ParametercedentIdArr = result;
                    this.ParameterArr = result;
                    this.snackBar.dismiss();
				}else{
					this.cedentEntity.ParameterCedentId = "";
					this.cedentEntity.CedentName = "";
					this.ParametercedentIdArr=[];
					this.ParameterArr=[];
					this.snackBar.open(this._translate.instant("commonMessage.cedentDetails"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}

	/**
		Fetching Cedent Name as per CedentID Selected
	**/
    public changeParameterCedentID() {
        this.cedentEntity.CedentName = "";
        console.log("cedentEntity.ParameterCedentId:" + this.cedentEntity.ParameterCedentId);
        for (let cnt = 0; cnt < this.ParametercedentIdArr.length; cnt++) {
            if (this.cedentEntity.ParameterCedentId == this.ParametercedentIdArr[cnt].CedentLoginID) {
                this.cedentEntity.CedentName = this.ParametercedentIdArr[cnt].CedentName;
                break;
            }
        }
    }

	/**
		Web service call for Parameter Key Details
	**/
    private async fetchParameter() {
      
		var seqnoPromise = this.searchRecord('ParameterSetting', "", "", "", "")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.ParametersArr = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchParameter"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		
	}
	
	/**
		Search CedentId w.r.t Cedent Name
	**/
	public filterListCareUnit(val){
		this.ParametercedentIdArr=this.ParameterArr;
		this.ParametercedentIdArr=this.ParametercedentIdArr.filter((unit) => unit.CedentName.indexOf(val) > -1);
	}
	
	/**
		Clear Cedent Search Field 
	**/
	public clearSearch(){
		this.search=""
		this.ParametercedentIdArr=this.ParameterArr;
	}
	
	/**
		Web service Error validation
	**/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}
}
