import { Component, Injector } from '@angular/core';

import { ParametersettingService } from '../../services/parametersetting.service';

import { Parametersetting, ParametersettingDataSource } from '../../models';
import { IParametersetting } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './parametersetting.list.component.html',
  styleUrls: ['./parametersetting.list.component.scss']
})
export class ParametersettingListComponent extends CedentEntityListComponent<IParametersetting> {

 
  displayedColumns = ['id','cedentid', 'cedentname', 'parameter','value','effetivedate','delete'];
  dataSource: ParametersettingDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("parametersetting.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("parametersetting.deleteerror");
  }

  constructor(
    injector: Injector,
    private userService: ParametersettingService
  ){
    super(injector, userService);
  }

  protected createDataSource(): ParametersettingDataSource {
    return new ParametersettingDataSource(this.entityService);
  }

  getMessageDelete(parametersetting: IParametersetting) {
    var options = { userid: parametersetting.ParameterCedentId, param: parametersetting.ParameterKey};
    return this.getTranslation('parametersetting.reallydelete', options);
  }
}