import { Component } from '@angular/core';


@Component({
  selector: 'parametersetting',
  template: '<router-outlet></router-outlet>'
})
export class ParametersettingComponent {

  constructor(  ) {}
}