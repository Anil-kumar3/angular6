import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { ParametersettingComponent } from './components/parametersetting.component';
import { ParametersettingListComponent } from './components/parametersettinglist/parametersetting.list.component';
import { ParametersettingDetailComponent } from './components/parametersettingdetail/parametersetting.detail.component';


export var  ParametersettingRoutes: Routes = [
  {
    path: 'parametersetting',
    component: ParametersettingComponent,
    canActivateChild: [ IsCedentRoleGuard ],
	data: { roles: [RoleNames.CE_PLATFORMMANAGER, RoleNames.CE_UW_MANAGER]},
    children: [
      {
        path: '',
        component: ParametersettingListComponent,
       // component:ParametersettingDetailComponent,
      },
      {
        path: ':id',
        component: ParametersettingDetailComponent,
      },
      {
        path: 'create',
        component: ParametersettingDetailComponent,
      }
    ]
  }
];
