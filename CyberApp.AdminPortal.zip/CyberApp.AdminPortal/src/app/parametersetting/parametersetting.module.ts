import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule,MdDatepickerModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';
import { CommonModule } from '../common/common.module';
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { ParametersettingComponent } from './components/parametersetting.component';
import { ParametersettingListComponent } from './components/parametersettinglist/parametersetting.list.component';
import { ParametersettingDetailComponent } from './components/parametersettingdetail/parametersetting.detail.component';

import { ParametersettingService } from './services/parametersetting.service';

//import { 
//  MdAutocompleteModule, MdButtonModule, MdCardModule, 
//  MdCheckboxModule, MdChipsModule, MdDatepickerModule, MdDialogModule, 
//  MdIconModule, MdInputModule, MdNativeDateModule, MdSnackBarModule, MdTableModule,
//  MdTabsModule, MdSelectModule
// } from '@angular/material';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdDatepickerModule,
    MdCheckboxModule,
    CdkTableModule,
	CommonModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    ParametersettingComponent,
    ParametersettingListComponent,
    ParametersettingDetailComponent
  ], 
  providers: [
    ParametersettingService
  ],
  exports: [
    ParametersettingListComponent
  ]
})
export class  ParametersettingModule { }