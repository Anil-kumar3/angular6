import { IParametersetting, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Parametersetting
  extends CedentEntity
  implements IParametersetting {

     public Country:string;
	 public CountryCode:string;
     public ParameterCedentId:string;
     public CedentName:string;
     public ParameterKey:string;
     public Value:string;
     public EffectiveDate:Date;
	 public GMTTimeZone:any;
	 public UnderwriterID:string;

  constructor(identifier: string, cedentId: string){
    super(cedentId);

    this.ParameterCedentId = identifier;
  }
}