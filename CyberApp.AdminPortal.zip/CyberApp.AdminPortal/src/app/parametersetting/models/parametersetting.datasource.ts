import { ParametersettingService } from '../services/parametersetting.service';

import { IParametersetting } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class ParametersettingDataSource 
  extends CedentEntityDataSource<IParametersetting>{

  constructor(userService: ParametersettingService){
    super(userService);
  }

  buildSearchString(item: IParametersetting): string {
    return (item.ParameterCedentId).toLowerCase();
  }
}