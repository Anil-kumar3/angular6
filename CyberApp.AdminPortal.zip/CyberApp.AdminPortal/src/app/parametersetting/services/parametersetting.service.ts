import { Injectable } from '@angular/core';

import { IParametersetting } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class ParametersettingService
  extends BaseCedentEntityService<IParametersetting> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'parametersetting');
  }
}