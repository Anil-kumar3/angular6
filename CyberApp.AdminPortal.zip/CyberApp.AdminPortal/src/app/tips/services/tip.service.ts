﻿import { Injectable } from '@angular/core';

import { ITipService } from './contracts/tip.services.contracts';

import { ITip } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';


@Injectable()
export class TipService
  extends BaseCedentEntityService<ITip>
  implements ITipService {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'tip');
  }
}