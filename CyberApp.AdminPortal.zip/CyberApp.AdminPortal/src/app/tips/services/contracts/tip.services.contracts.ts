﻿import { Observable } from 'rxjs/Observable';

import { ICedentEntityService } from '../../../common/services/contracts/common.services.contracts';
import { ITip } from '../../../common/models/contracts/models.contracts';

export interface ITipService
  extends ICedentEntityService<ITip> {

}