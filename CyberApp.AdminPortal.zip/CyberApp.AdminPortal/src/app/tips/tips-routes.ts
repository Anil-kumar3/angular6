import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { TipsComponent } from './components/tips.component';
import { TipListComponent } from './components/tiplist/tip.list.component';
import { TipDetailComponent } from './components/tipdetail/tip.detail.component';


export var  tipsRoutes: Routes = [
  {
    path: 'tips',
    component: TipsComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    data: { roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER ] },
    children: [
      {
        path: '',
        component: TipListComponent,
      },
      {
        path: ':id',
        component: TipDetailComponent,
      },
      {
        path: 'create',
        component: TipDetailComponent,
      }
    ]
  }
];
