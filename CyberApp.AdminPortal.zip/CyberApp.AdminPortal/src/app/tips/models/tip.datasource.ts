﻿import { TipService } from '../services/tip.service';

import { ITip } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';

 
export class TipDataSource 
  extends CedentEntityDataSource<ITip> {

  constructor(tipService: TipService) {
    super(tipService);
  }

  buildSearchString(item: ITip): string {
    return (item.Title + item.SubTitle + item.Description).toLowerCase();
  }
}