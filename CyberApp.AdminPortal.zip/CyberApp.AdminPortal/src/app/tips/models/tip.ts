﻿import { ITip } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Tip
  extends CedentEntity
  implements ITip {

  public Icon: string;
  public Title: string;
  public SubTitle: string;
  public Description: string;

  constructor(icon: string, title: string, subtitle: string, description: string, cedentID: string){
    super(cedentID);

    this.Icon = icon;
    this.Title = title;
    this.SubTitle = subtitle;
    this.Description = description;
  }
}