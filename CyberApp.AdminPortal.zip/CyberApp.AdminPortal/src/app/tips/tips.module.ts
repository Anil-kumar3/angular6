﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdAutocompleteModule, MdButtonModule, MdCardModule, MdCheckboxModule, MdChipsModule, MdDatepickerModule, MdDialogModule, MdIconModule, MdInputModule, MdNativeDateModule, MdTableModule } from '@angular/material';
import {  FlexLayoutModule } from '@angular/flex-layout';
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserModule } from '@angular/platform-browser';

import { CommonModule } from '../common/common.module';

import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

//Components
import { TipsComponent } from './components/tips.component';
import { TipListComponent } from './components/tiplist/tip.list.component';
import { TipDetailComponent } from './components/tipdetail/tip.detail.component';
import { TipDescriptionPreviewComponent } from './components/tipdescriptionpreview/tip.descriptionpreview.component';

//Services
import { TipService } from './services/tip.service';

export function HttpLoaderFactory(http: Http){
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MdAutocompleteModule,
    MdButtonModule,
    MdCardModule,
    MdCheckboxModule,
    MdChipsModule,
    MdDatepickerModule,
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdNativeDateModule,
    MdTableModule,
    CdkTableModule,
    FlexLayoutModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    TipsComponent,
    TipListComponent,
    TipDetailComponent,
    TipDescriptionPreviewComponent
  ],
  entryComponents: [
    TipDescriptionPreviewComponent
  ],
  providers: [
    TipService
  ]
})
export class TipsModule {}