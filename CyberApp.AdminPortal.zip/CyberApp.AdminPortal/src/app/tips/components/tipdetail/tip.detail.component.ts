﻿import { Component, OnInit, Injector, ViewChild, ElementRef } from '@angular/core';
import { MdDialog } from '@angular/material';

import { TipService } from '../../services/tip.service';
import { Tip } from '../../models/tip';

import { TipDescriptionPreviewComponent } from '../tipdescriptionpreview/tip.descriptionpreview.component';

import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';

import { MarkdownParserService } from '../../../common/services/markdown-parser.service';
import { ITip } from '../../../common/models/contracts/models.contracts';

import { StringUtils } from '../../../common/utils/string.utils';
import { Subscription } from "rxjs/Subscription";

@Component({
  selector: 'tip-detail',
  templateUrl: './tip.detail.component.html',
  styleUrls: ['./tip.detail.component.scss']
})
export class TipDetailComponent extends CedentEntityDetailComponent<ITip> {

  // pager object
  pager: any = {};

  @ViewChild('profileDatumInput') profileDatumInput: ElementRef;

  public parsedDescription: string;
  private entityLoadedSubscription: Subscription;
  constructor(
    injector: Injector,
    private tipService: TipService,
    private _markdownParserService: MarkdownParserService,
    private dialog: MdDialog,
  ) {
    super(injector, tipService);

  }

  ngOnInit() {
    super.ngOnInit();
    this.entityLoadedSubscription = this.entityLoaded.subscribe((entity) => this.parsedDescription = this._markdownParserService.convert(this.cedentEntity.Description));
  }

  ngOnDestroy() {
    this.entityLoadedSubscription.unsubscribe();
  }

  onKey(event: any) { // without type info
    this.parsedDescription = this._markdownParserService.convert(this.cedentEntity.Description);
  }

  protected createNewObject(): ITip {
    return new Tip("", "", "", "", this.cedentId);
  }

  protected get isDescriptionFieldValid(): boolean {
    var isValid = false;
    if(this.cedentEntity && !StringUtils.isNullUndefinedOrEmpty(this.cedentEntity.Description)){
      isValid = true;
    }
    return isValid;
  }

  private showPreview() {
    let descriptionPreview = this._markdownParserService.convert(this.cedentEntity.Description);
    return this.dialog.open(TipDescriptionPreviewComponent, {
      data: {
        descriptionPreview: descriptionPreview
      },
      height: '400px',
      width: '600px',
    });
  }
}