﻿import { Component, Injector } from '@angular/core';


import { Tip, TipDataSource } from '../../models';
import { TipService } from '../../services/tip.service';
import { ITip } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({
  templateUrl: './tip.list.component.html',
  styleUrls: ['./tip.list.component.scss']
})
export class TipListComponent extends CedentEntityListComponent<ITip> {

  displayedColumns = ["id", "icon", "title", "subtitle", 'delete'];
  dataSource: TipDataSource | null;

  get messageDeleteSuccess(): string {
    return this.getTranslation("tip.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("tip.deleteerror");
  }

  constructor(injector: Injector, private tipService: TipService) {
    super(injector, tipService);
  }

  protected createDataSource(): TipDataSource {
    return new TipDataSource(this.entityService);
  }

  getMessageDelete(tip: ITip) {
    var options = { tip: tip.Title };
    return this.getTranslation('tip.reallydelete', options);
  }
}