﻿import { Component, OnInit, Inject } from '@angular/core';

import { MdDialogRef, MdDialogConfig, MD_DIALOG_DATA } from '@angular/material';

@Component({
  moduleId: module.id,
  selector: 'tip-descriptionpreview',
  templateUrl: './tip.descriptionpreview.component.html',
  styleUrls: ['./tip.descriptionpreview.component.scss']
})
export class TipDescriptionPreviewComponent {

  descriptionPreview: string;

  constructor(dialogRef: MdDialogRef<TipDescriptionPreviewComponent>, @Inject(MD_DIALOG_DATA) public data: any) {
    this.descriptionPreview = this.data.descriptionPreview;
  }

}