import { Component } from '@angular/core';


@Component({
  selector: 'users',
  template: '<router-outlet></router-outlet>'
})
export class TipsComponent {

  constructor(  ) {}
}