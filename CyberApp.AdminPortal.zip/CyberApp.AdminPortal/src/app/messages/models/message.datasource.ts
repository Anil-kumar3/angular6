import { MessageService } from '../services/message.service';

import { IMessageTask } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';

import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
 
export class MessageDataSource 
  extends CedentEntityDataSource<IMessageTask> {

  _showTasksChange = new BehaviorSubject<boolean>(false);

  get showTasks(): boolean { return this._showTasksChange.value; }
  set showTasks(showTasks: boolean) { this._showTasksChange.next(showTasks); }

  constructor(messageService: MessageService) {
    super(messageService);
  }

  connect(): Observable<Array<IMessageTask>> {
    const displayDataChanges = [
      this._entities,
      this._filterChange,
      this._showTasksChange
    ];

    return Observable.merge(...displayDataChanges).map(() => {
      return this._entities.value.slice().filter((item: IMessageTask) => {
        return item.IsTask === this.showTasks;
      }).filter((item: IMessageTask) => {
        let searchStr = this.buildSearchString(item);
        return searchStr.indexOf(this.filter.toLocaleLowerCase()) != -1;
      });
    });
  }

  buildSearchString(item: IMessageTask): string {
    return (item.Title + item.SubTitle + item.Description).toLowerCase();
  }
}
