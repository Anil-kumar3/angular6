import { IMessageTask } from '../../common/models/contracts/models.contracts';
import { Message } from './message';

export class MessageTask extends Message
                         implements IMessageTask {

  public IsTask: boolean = false;
  public IsServer: boolean;
  public Done: boolean = false;
  public Due: Date = new Date();
  public RecurrencyIntervalDays: number;
  public TaskValue: number;
  public TaskSeverity: number;
  public CreatedFromQuestionaireAnswerId: string;

  constructor(title: string, subtitle: string, description: string, cedentID: string, answerIds: string[], policyHolderIds: string[]){
    super(title, subtitle, description, cedentID, answerIds, policyHolderIds);
    this.RecurrencyIntervalDays = 0;
  }
}
