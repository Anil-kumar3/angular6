import { IMessage } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Message
  extends CedentEntity
  implements IMessage {

  public Title: string;
  public SubTitle: string;
  public Description: string;
  public Date: Date;
  public AnswerIds: string[];
  public PolicyHolderIds: string[];
  public IsDefault: boolean = false;

  constructor(title: string, subtitle: string, description: string, cedentID: string, answerIds: string[], policyHolderIds: string[]){
    super(cedentID);
    
    this.Title = title;
    this.SubTitle = subtitle;
    this.Description = description;
    
    this.Date = new Date();
    this.AnswerIds = answerIds;
    this.PolicyHolderIds = policyHolderIds;
  }
}