import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { 
  MdAutocompleteModule, MdButtonModule, MdCardModule, 
  MdCheckboxModule, MdChipsModule, MdDatepickerModule, MdDialogModule, 
  MdIconModule, MdInputModule, MdNativeDateModule, MdSnackBarModule, MdTableModule,
  MdTabsModule, MdSelectModule
 } from '@angular/material';
import { FlexLayoutModule } from "@angular/flex-layout";
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserModule } from '@angular/platform-browser';

import { CommonModule } from '../common/common.module';

import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

//Components
import { MessagesComponent } from './components/messages.component';
import { MessageListComponent } from './components/messagelist/message.list.component';
import { MessageDetailComponent } from './components/messagedetail/message.detail.component';

//services
import { MessageService } from './services/message.service';

export function HttpLoaderFactory(http: Http){
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    MdAutocompleteModule,
    MdButtonModule,
    MdCardModule,
    MdCheckboxModule,
    MdChipsModule,
    MdDatepickerModule,
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdNativeDateModule,
    MdSnackBarModule,
    MdTableModule,
    MdTabsModule,
    MdSelectModule,
    CdkTableModule,
    FlexLayoutModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    MessagesComponent,
    MessageListComponent,
    MessageDetailComponent,
  ],
  providers: [
    MessageService
  ]
})
export class MessagesModule {}