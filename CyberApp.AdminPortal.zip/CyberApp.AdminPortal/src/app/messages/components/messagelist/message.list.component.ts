import { Component, Injector } from '@angular/core';

import { MessageDataSource } from '../../models/message.datasource';
import { IMessageTask } from '../../../common/models/contracts/models.contracts';
import { MessageService } from '../../services/message.service';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({
  templateUrl: './message.list.component.html',
  styleUrls: ['./message.list.component.scss']
})
export class MessageListComponent extends CedentEntityListComponent<IMessageTask>
{
  displayedMessageColumns = ["id", "date", "title", "subtitle", "isDefault", 'delete'];
  displayedTaskColumns = ["id", "date", "titleTask", "subtitleTask", "due", "severity", "recurrency", "isDefault", 'delete'];
  displayedColumns = this.displayedMessageColumns;
  dataSource: MessageDataSource | null;
  showTasks: boolean = false;

  get messageDeleteSuccess(): string {
    return this.getTranslation("message.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("message.deleteerror");
  }

  constructor(
    injector: Injector,
    private messageService: MessageService,
    private localStorageService: LocalStorageService
  ){
    super(injector, messageService);
  }

  ngOnInit() {
    super.ngOnInit();
    this.toggleShowTasks(this.localStorageService.get("showTasks"));
  }

  protected createDataSource(): MessageDataSource {
    return new MessageDataSource(this.entityService);
  }

  getMessageDelete(message: IMessageTask) {
    var options = {message: message.Title} ;
    return this.getTranslation('message.reallydelete', options);
  }

  toggleShowTasks(showTasks: boolean): void {
    this.displayedColumns = showTasks ? this.displayedTaskColumns : this.displayedMessageColumns;
    this.dataSource.showTasks = this.showTasks = showTasks;
    this.localStorageService.set("showTasks", showTasks);
  }
}
