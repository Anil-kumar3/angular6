import { Component } from '@angular/core';


@Component({
  selector: 'messages',
  template: '<router-outlet></router-outlet>'
})
export class MessagesComponent {

  constructor(  ) {}
}