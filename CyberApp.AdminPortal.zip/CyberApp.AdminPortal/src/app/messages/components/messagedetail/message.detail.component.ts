import { Component, OnInit, OnDestroy, ViewChild, ElementRef, Injector } from '@angular/core';
import { FormControl } from '@angular/forms';

import { Subscription } from 'rxjs/Rx';

import { remove } from 'lodash';



import { MessageTask } from '../../models/messagetask';
import { MessageService } from '../../services/message.service';
import { QuestionnaireService } from '../../../questionnaire/services/questionnaire.service';
import { PolicyHolderService } from '../../../policyholder/services/policyholder.service';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';

import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';

import { IMessageTask, IQuestionnaireItem, IPolicyHolder, recurrenceTaskIntervalls } from '../../../common/models/contracts/models.contracts';

@Component({
  selector: 'message-detail',
  templateUrl: './message.detail.component.html',
  styleUrls: ['./message.detail.component.scss']
})
export class MessageDetailComponent
  extends CedentEntityDetailComponent<IMessageTask>
  implements OnInit, OnDestroy {

  private _message: IMessageTask;
  public questions: IQuestionnaireItem[];

  public findPolicyHolders: IPolicyHolder[];
  public searchPolicyHolderString: string;
  private searchTimeout;
  public messagePolicyHolders: IPolicyHolder[] = [];

  public recurrenceTaskIntervalls;

  private questionsSubscription: Subscription;

  public set cedentEntity(entity: IMessageTask) {
    if ((new Date(entity.Due)).getFullYear() === 1) {
      entity.Due = new Date();
    }
    else {
      entity.Due = new Date(entity.Due);
    }
    entity.Date = new Date(entity.Date);
    this._message = entity;
  }

  public get cedentEntity() {
    return this._message;
  }

  @ViewChild('profileDatumInput') profileDatumInput: ElementRef;

  constructor(
    injector: Injector,
    private messageService: MessageService,
    private questionnaireService: QuestionnaireService,
    private policyHolderService: PolicyHolderService,
    private localStorageService: LocalStorageService
  ) {
    super(injector, messageService);
  }

  ngOnInit() {
    super.ngOnInit();
    this.recurrenceTaskIntervalls = recurrenceTaskIntervalls;
    this.questionsSubscription = this.questionnaireService.getEntities(true).subscribe(questions => {
      this.questions = questions;
    });
  }

  ngOnDestroy() {
    this.questionsSubscription.unsubscribe();
    this.questionsSubscription = undefined;
  }

  protected onEntityLoaded() {

    if (this.cedentEntity.PolicyHolderIds.length === 0) {
      return;
    }

    this.policyHolderService.getEntitiesByIds(this.cedentEntity.PolicyHolderIds).subscribe(holders => {
      for (let ph of holders) {
        this.messagePolicyHolders.push(ph);
      }
    });
  }

  protected onEntityCreated() {
    this.localStorageService.set("showTasks", this.cedentEntity.IsTask);
  }

  public searchPolicyHolders() {

    if (this.searchTimeout) {
      clearTimeout(this.searchTimeout);
    }

    if (!this.searchPolicyHolderString || this.searchPolicyHolderString === '') {
      this.findPolicyHolders = [];
      return;
    }

    this.searchTimeout = setTimeout(() => {
      this.policyHolderService.search(this.searchPolicyHolderString).subscribe(users => this.findPolicyHolders = users);
      this.searchTimeout = undefined;
    }, 600);
  }

  public addPollicyHolder(policyHolder: IPolicyHolder) {

    if (this.cedentEntity.PolicyHolderIds.indexOf(policyHolder.id) !== -1) {
      return;
    }

    this.messagePolicyHolders.push(policyHolder);
    this.cedentEntity.PolicyHolderIds.push(policyHolder.id);
  }

  public removePolicyHolder(policyHolder: IPolicyHolder) {
    remove(this.messagePolicyHolders, ph => ph === policyHolder);
    remove(this.cedentEntity.PolicyHolderIds, phId => phId === policyHolder.id);
  }

  protected createNewObject(): IMessageTask {
    var messageTask = new MessageTask("", "", "", this.cedentId, [], []);
    messageTask.IsTask = this.localStorageService.get("showTasks");
    return messageTask;
  }

  protected get minDate(): Date {
    return new Date();
  }

  toggleIsTask(checked: boolean/*$event: any*/): void {
    this.cedentEntity.IsTask = checked;
    if (!this.cedentEntity.IsTask) {
      this.removeTaskProperties();
    }
    /*
    if ($event !== null && $event !== undefined && !$event.checked){
      this.removeTaskProperties();
    }
    */
  }

  private isValidDate(date: Date): boolean {
    return !!(Object.prototype.toString.call(date) === "[object Date]" && + date);
  }

  public get isValid(): boolean {
    return this.cedentEntity.Title !== "" && this.cedentEntity.SubTitle !== "" && this.cedentEntity.Description !== "" && this.isValidDate(this.cedentEntity.Date) &&
      (!this.cedentEntity.IsTask || this.cedentEntity.IsTask && this.isValidDate(this.cedentEntity.Due) && this.cedentEntity.TaskSeverity > 0);
  }

  private removeTaskProperties(): void {
    if (this.cedentEntity !== null && this.cedentEntity !== undefined) {
      this.cedentEntity.Due = new Date();
      this.cedentEntity.TaskValue = 0;
      this.cedentEntity.TaskSeverity = 0;
      this.cedentEntity.RecurrencyIntervalDays = 0;
    }
  }
}
