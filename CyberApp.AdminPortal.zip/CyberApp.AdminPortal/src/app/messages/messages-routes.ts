import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { MessagesComponent } from './components/messages.component';
import { MessageListComponent } from './components/messagelist/message.list.component';
import { MessageDetailComponent } from './components/messagedetail/message.detail.component';


export var  messagesRoutes: Routes = [

  {
    path: 'messages',
    component: MessagesComponent,
    canActivateChild: [IsCedentRoleGuard],
    data: { roles: [RoleNames.CEDENT_READER,  RoleNames.CEDENT_CONTENT_MANAGER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER ] },
    children: [
      {
        path: '',
        component: MessageListComponent
      },
      {
        path: ':id',
        component: MessageDetailComponent
      },
      {
        path: 'create',
        component: MessageDetailComponent
      }
    ]
  }
];
