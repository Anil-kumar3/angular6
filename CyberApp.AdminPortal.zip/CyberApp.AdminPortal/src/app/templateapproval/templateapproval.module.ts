import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule, MdDatepickerModule, MdNativeDateModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';

import { CommonModule } from '../common/common.module';
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { TemplateApprovalComponent } from './components/templateapproval.component';
import { TemplateApprovalListComponent } from './components/templateapprovallist/templateapproval.list.component';
import { TemplateApprovalDetailComponent } from './components/templateapprovaldetail/templateapproval.detail.component';
import { TemplateEditComponent } from './components/templateedit/templateedit.component';

import { TemplateApprovalService } from './services/templateapproval.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdCheckboxModule,
    CdkTableModule,
	CommonModule,
    ReactiveFormsModule,
	MdDatepickerModule,
	MdNativeDateModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    TemplateApprovalComponent,
    TemplateApprovalListComponent,
    TemplateApprovalDetailComponent,
	TemplateEditComponent
  ], 
  providers: [
    TemplateApprovalService
  ],
  exports: [
    TemplateApprovalListComponent
  ],
  entryComponents: [
    TemplateEditComponent
  ]
})
export class TemplateApprovalModule { }