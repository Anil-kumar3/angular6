import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { TemplateApprovalComponent } from './components/templateapproval.component';
import { TemplateApprovalListComponent } from './components/templateapprovallist/templateapproval.list.component';
import { TemplateApprovalDetailComponent } from './components/templateapprovaldetail/templateapproval.detail.component';


export var  TemplateApprovalRoutes: Routes = [
  {
    path: 'templateapproval',
    component: TemplateApprovalComponent,
    canActivateChild: [ IsCedentRoleGuard ],
	data: { roles: [RoleNames.CE_PLATFORMMANAGER, RoleNames.CE_UW_MANAGER]},
    children: [
      {
        path: '',
        // component: TemplateApprovalDetailComponent,
        component: TemplateApprovalListComponent,
      },
      {
        path: ':id',
        component: TemplateApprovalDetailComponent,
      },
      {
        path: 'create',
        component: TemplateApprovalDetailComponent,
      }
    ]
  }
];
