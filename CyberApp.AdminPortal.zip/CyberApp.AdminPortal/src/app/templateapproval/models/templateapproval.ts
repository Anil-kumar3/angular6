import { ITemplateApproval, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class TemplateApproval
  extends CedentEntity
  implements ITemplateApproval {
	public id: string;
	public Readonly: boolean;
	public Country: string;
	public CountryCode: string;
	public TemplateCedentId: string;
	public CedentName: string;
	public TemplateType:string;
	public EffectiveDate: Date;
	public Status:string;
	public TemplateDocument: string;
	public FileUpload:string;
	public RejectReason:string;
	public UserTemplateName:string;
	public UnderwriterID:string;

  constructor(UserLoginID: string, CedentName: string){
    super(CedentName);

    this.CedentName = UserLoginID;
  }
}