import { TemplateApprovalService } from '../services/templateapproval.service';

import { ITemplateApproval } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class TemplateApprovalDataSource 
  extends CedentEntityDataSource<ITemplateApproval>{

  constructor(userService: TemplateApprovalService){
    super(userService);
  }

  buildSearchString(item: ITemplateApproval): string {
    return (item.TemplateCedentId).toLowerCase();
  }
}