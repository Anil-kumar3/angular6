import { Component } from '@angular/core';


@Component({
  selector: 'templateapproval',
  template: '<router-outlet></router-outlet>'
})
export class TemplateApprovalComponent {

  constructor(  ) {}
}