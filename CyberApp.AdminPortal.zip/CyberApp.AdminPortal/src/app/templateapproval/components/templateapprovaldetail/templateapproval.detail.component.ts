import { Component, OnInit, Injector, ViewChild } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TemplateApprovalService } from '../../services/templateapproval.service';
import { CountryService } from '../../../cedent/services';
import { TemplateApproval } from '../../models/templateapproval';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { ICountry, IsearchData, ITemplateApproval, IPricingTemplate } from '../../../common/models/contracts/models.contracts';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { Observable, Subscription } from 'rxjs/Rx';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { getCedentId } from '../../../common/utils/cedent.utils';

import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { TemplateEditComponent } from '../templateedit/templateedit.component';
import { Globals } from '../../../global';


@Component({
  selector: 'templateapproval-detail',
  templateUrl: './templateapproval.detail.component.html',
  styleUrls: ['./templateapproval.detail.component.scss']
})
export class TemplateApprovalDetailComponent extends CedentEntityDetailComponent < ITemplateApproval > implements OnInit {

	private validationErrors: Array < string > ;
	public country: ICountry[];
	public countrySelected: ICountry;
	public cedentID: IsearchData[];
	public cedentID1: IsearchData[];
	private _template: ITemplateApproval;
	protected snackBar: MdSnackBar;
	public templateDocx: IPricingTemplate[];
	public userstatus;
	error: string;
	countrycode: string;
	countryChoosen: string;
	search: string;
	Status = ["Approval", "Reject"];
	TemplateType = ["Onboarding", "Risk management", "Claims"];
	loadingFlag : string;
	private blockApprovalFlag : string;
	private displayFlag:string;
	@ViewChild('myModal') myModal;
	public dialogRef:any;

	
	/**
		Calling Template approval Details from web service to get the list once we come from edit case.
	**/
	public set cedentEntity(entity: ITemplateApproval) {
		if (NullUndefined(entity.CedentId) == "") {
			if (NullUndefined(entity[0].EffectiveDate) != "")
				entity[0].EffectiveDate = new Date(entity[0].EffectiveDate);
			if (NullUndefined(entity[0].Country) != "" && NullUndefined(entity[0].TemplateDocument) == "Cedent Template") {
				this.fetchRecord(entity[0].Country, entity[0].CountryCode);
			}
			if(NullUndefined(entity[0].TemplateDocument) != ""){
				this.fetchTemplate();
				console.log("entity.CedentId:"+entity);
				this.fetchRecordStatus(entity[0].id);
			}
			this._template = entity[0];
		} else {
			this._template = entity;
		}
	}

	/**
		Getting the Template Approval details from web service and assigning it to object once we come from edit case.
	**/
	public get cedentEntity() {
		return this._template;
	}

	constructor(
		injector: Injector,
		private templateapprovalService: TemplateApprovalService,
		private countryService: CountryService,
		private _translate: TranslateService,
		private localStorageService: LocalStorageService,
		public dialog: MdDialog,
		public globals: Globals
	) {
		super(injector, templateapprovalService);
		this.validationErrors = new Array < string > ();
		this.snackBar = injector.get(MdSnackBar);
	}

	/** 
		Function Calling on page load
	**/
	async ngOnInit() {
		this.loadingFlag="Loading...";
		super.ngOnInit();
		var promises = [];
		/*var countryPromise = this.searchRecord('Country','Country',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			this.loadingFlag="";
			return;
		});
		promises.push(countryPromise);
		if (this.isExistEntity) {
			var userPromise = this.entityLoaded.first().toPromise();
			promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		this.country = result[0];*/
		console.log("Login ID:"+this.globals.loginUserID);
		console.log("Roles:"+this.globals.loginUserRole);
		if(this.globals.loginUserRole.toUpperCase()=="CEDENT - PLATFORM MANAGER"){
			this.displayFlag="";
		}else{
			this.displayFlag="Y";
		}
		
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		this.fetchTemplate();
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
		this.loadingFlag="";
	}
	
	/**
		Calling web service for pricing template list
	**/
	private async fetchTemplate() {
		/*var pricingpromises = [];
		//var pricingTemplatePromise = this.pricingtemplateService.getEntities().first().toPromise()
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect pricing template web service", null, {duration: 3500})
			return;
		});
		pricingpromises.push(pricingTemplatePromise);
		if(this.isExistEntity) {
		  var templatePromise = this.entityLoaded.first().toPromise();
		  pricingpromises.push(templatePromise);
		}
		var result1 = await Promise.all(pricingpromises);
		this.pricingTemplate = result1[0];*/
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.templateDocx = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchTemplate"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }
	
	
	/** Fetch the status if thresold parameter is set **/
	private async fetchRecordStatus(searchCedentID) {
		var rootcedentId = getCedentId();
		if (NullUndefined(rootcedentId) == "")
        {
			rootcedentId = this.localStorageService.get("superAdminID");
		}
		console.log("searchCedentID:"+searchCedentID);
		var pricingTemplatePromise = this.searchRecord('Country','ValidateTemplateApproval',NullUndefined(searchCedentID),NullUndefined(rootcedentId),"")
		.subscribe(
			  response => {
				var result = response;
				if(result !="No Data Found"){
					this.blockApprovalFlag = result.searchData;
				}else{
					this.blockApprovalFlag="DISABLE";
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }

	/** 
		Function called On change of Country Dropdown
	**/
	public changeCountry(): void {
		if (this.countryChoosen != "" && this.countryChoosen != this.cedentEntity.Country) {
			for (let cnt = 0; cnt < this.country.length; cnt++) {
				if (this.cedentEntity.Country == this.country[cnt].CountryName) {
					this.countrycode = this.country[cnt].CountryCode;
					this.cedentEntity.CountryCode = this.countrycode;
					break;
				}
			}
			this.cedentEntity.CedentName = "";
			this.fetchRecord(this.cedentEntity.Country, this.cedentEntity.CountryCode);
			this.countryChoosen = this.cedentEntity.Country;
		}
	}

	/** 
		Web service call for getting CedentID & CedentName datils as per Country selected
	**/
	private async fetchRecord(UserCountry, countrycode) {
		this.loadingFlag="Loading...";
		var promises = [];
		var rootcedentId = getCedentId();
		if (NullUndefined(rootcedentId) == "")
        {
			rootcedentId = this.localStorageService.get("superAdminID");
		}
		/*var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(UserCountry), NullUndefined(countrycode), NullUndefined(rootcedentId)).toPromise()
		.catch(error => {
			this.snackBar.open("Unable to fetch detail", null, {duration: 3500})
			this.loadingFlag="";
			return;
		});
		promises.push(seqnoPromise);
		if (this.isExistEntity) {
			var userPromise = this.entityLoaded.first().toPromise();
			promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		this.cedentID = result[0];
		this.cedentID1 = this.cedentID;
		this.loadingFlag="";*/
		var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(UserCountry), NullUndefined(countrycode), NullUndefined(rootcedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.cedentID = result;
                    this.cedentID1 = this.cedentID;
                    this.snackBar.dismiss();
				}else{
					this.cedentID = [];
					this.cedentID1 = [];
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}

	/**
		Fetching Cedent Name onchange of CedentID
	**/
	public changetemplatecedentID() {
		for (let cnt = 0; cnt < this.cedentID.length; cnt++) {
			if (this.cedentEntity.TemplateCedentId == this.cedentID[cnt].CedentLoginID) {
				this.cedentEntity.CedentName = this.cedentID[cnt].CedentName;
				this.cedentEntity.TemplateCedentId = this.cedentID[cnt].CedentLoginID;
				break;
			}
		}
	}

	/**
		Search CedentId w.r.t Cedent Name
	**/
	public filterListCareUnit(val) {
		this.cedentID = this.cedentID1;
		this.cedentID = this.cedentID.filter((unit) => unit.CedentName.indexOf(val) > -1);
	}

	/** 
		Clear Cedent Search Field 
	**/
	public clearSearch() {
		this.search = ""
		this.cedentID = this.cedentID1;
	}

	/** 
		Download Template by click on View File
	**/
	public viewFile(): void {
		this.approveRejectNview("");
	}

	/**
		Function Call for approval template on click of Approve Button 
	**/
	public approval(): void {
		if(this.blockApprovalFlag.toUpperCase()==="ENABLE"){
			this.approveRejectNview("ACTIVATED");
		}else{
			this.error = 'disableApprove';
			return;
		}
	}

	/**
		Function Call for rejecting template on click of Reject Button 
	**/
	public reject(): void {
		if (NullUndefined(this.cedentEntity.RejectReason) == '') {
			this.error = 'enterReason';
			return;
		} else {
			this.error = '';
			this.approveRejectNview("REJECTED");
		}
	}

	/**
		Web service call for Approve / Reject / Download the Template 
	**/
	private async approveRejectNview(Astatus: string) {
		this.loadingFlag="Loading...";
		if (Astatus) {
			/*var seqnoPromise = this.ApproveViewUW('ApproveViewUW', 'TemplateApproval', 'PROCESS', this.cedentEntity.id, Astatus, NullUndefined(this.cedentEntity.RejectReason)).toPromise();
			var promises = [];
			promises.push(seqnoPromise);
			var result = await Promise.all(promises);
			this.loadingFlag="";
			super.goBack();*/
			this.cedentEntity.UnderwriterID = NullUndefined(this.globals.loginUserID);
			var seqnoPromise = this.ApproveViewUW('ApproveViewUW', 'TemplateApproval', 'PROCESS', this.cedentEntity.id, Astatus, NullUndefined(this.cedentEntity.RejectReason),NullUndefined(this.cedentEntity.UnderwriterID))
			.subscribe(
				  response => {
					var result = response;
					this.loadingFlag="";
					super.goBack();
				  }, error => {
						this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
						this.loadingFlag="";
						return;
				  }
			);
		} else {
			var seqnoPromise =this.downloadFile(this.cedentEntity.UserTemplateName, 'TemplateApproval', 'VIEW', this.cedentEntity.id, '', '')
			.subscribe(
				  response => {
							this.snackBar.open(this._translate.instant("commonMessage.downloadfilesuccess"), null, {duration: 3500})
							this.loadingFlag="";
				  }, error => {
						this.snackBar.open(this._translate.instant("commonMessage.unabledownloadfile"), null, {duration: 3500})
						this.loadingFlag="";
						return;
				}
			);	
		}
	}
	
	/**
		Creating Object for Template Approval
	**/
	protected createNewObject(): ITemplateApproval {
		return new TemplateApproval("", this.cedentId);
	}

	/**
		Web service Error validation
	**/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}
	
	public editContent():void{
		console.log("sdfsfsdf");
		this.openDialog();
	}
	
	
	openDialog() {
		this.dialogRef = this.dialog.open(TemplateEditComponent, {
		  width: '70%',
		  height:'90%',
		  disableClose: true,
		  data:{
				recordID:this.cedentEntity.id
			}
		});
		/*dialogRef.afterClosed().subscribe(result => {
		  console.log(`Dialog closed: ${result}`);
		  this.dialogResult = result;
		});*/
	}

}