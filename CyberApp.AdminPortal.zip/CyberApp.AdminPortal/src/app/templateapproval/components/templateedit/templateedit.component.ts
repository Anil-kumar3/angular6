import { Component, OnInit, Injector, ViewChild, Inject, Directive, ElementRef, Input  } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TemplateApprovalService } from '../../services/templateapproval.service';
import { CountryService } from '../../../cedent/services';
import { TemplateApproval } from '../../models/templateapproval';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { IQuestionDeatil, IsearchData, ITemplateApproval, IPricingTemplate } from '../../../common/models/contracts/models.contracts';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType, MD_DIALOG_DATA } from '@angular/material';
import { Observable, Subscription } from 'rxjs/Rx';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { getCedentId } from '../../../common/utils/cedent.utils';

import { LocalStorageService } from '../../../localstorage/services/localstorage.service';

@Component({
  selector: 'templateedit',
  templateUrl: './templateedit.component.html',
  styleUrls: ['./templateedit.component.scss']
})
export class TemplateEditComponent extends CedentEntityDetailComponent < ITemplateApproval > implements OnInit {

	private validationErrors: Array < string > ;
	public questionDeatil: IQuestionDeatil[];
	public wordingDeatil: IQuestionDeatil[];
	public pricingModelDeatil: IQuestionDeatil[];
	public cedentID: IsearchData[];
	public cedentID1: IsearchData[];
	private _template: ITemplateApproval;
	protected snackBar: MdSnackBar;
	public templateDocx: IPricingTemplate[];
	public userstatus;
	error: string;
	countrycode: string;
	countryChoosen: string;
	search: string;
	Status = ["Approval", "Reject"];
	TemplateType = ["Onboarding", "Risk management", "Claims"];
	loadingFlag : string;
	public dialogRef:any;
	public questionUpdateList=[];
	public questionEditList=[];
	public wordingUpdateList=[];
	public wordingEditList=[];
	public pricingModelUpdateList=[];
	public pricingModelEditList=[];
	private questionarDetail=[];
	private wordingDetail=[];
	private pricingModelDetail=[];
	questionTag="";
	wordingTag="";
	pricingModelTag="";
	private cnt:number=0;

	

	constructor(
		injector: Injector,
		private templateapprovalService: TemplateApprovalService,
		private countryService: CountryService,
		private _translate: TranslateService,
		private localStorageService: LocalStorageService,
		public thisDialogRef: MdDialogRef<TemplateEditComponent>, 
		@Inject(MD_DIALOG_DATA) public data: any
	) {
		super(injector, templateapprovalService);
		this.validationErrors = new Array < string > ();
		this.snackBar = injector.get(MdSnackBar);
	}

	async ngOnInit() {
		this.loadingFlag="Loading...";
		super.ngOnInit();
		var promises = [];
		var questionPromise = this.searchRecord('TemplateData','Question',this.data.recordID,"","")
		.subscribe(
			  response => {
				var result = NullUndefined(response);
				if(result !=""){
					if(NullUndefined(result.QuestionDetails.data)!=""){
						this.questionDeatil = result.QuestionDetails.data;
						for (this.cnt = 0; this.cnt < result.QuestionDetails.data.length; this.cnt++) {
							this.questionTag="Y";
							this.questionarDetail[this.cnt]=result.QuestionDetails.data[this.cnt].labelName;
							this.questionUpdateList[this.cnt]="";
							this.questionEditList[this.cnt]="Y";
						}
						if(NullUndefined(result.Wordings.data)!=""){
							this.cnt=0;
							this.wordingDeatil = result.Wordings.data;
							for (this.cnt = 0; this.cnt < result.Wordings.data.length; this.cnt++) {
								this.wordingDetail[this.cnt]=result.Wordings.data[this.cnt].labelName;
								this.wordingUpdateList[this.cnt]="";
								this.wordingEditList[this.cnt]="Y";
							}
						}
						if(NullUndefined(result.PricingModels.data)!=""){
							this.cnt=0;
							this.pricingModelDeatil = result.PricingModels.data;
							for (this.cnt = 0; this.cnt < result.PricingModels.data.length; this.cnt++) {
								this.pricingModelDetail[this.cnt]=result.PricingModels.data[this.cnt].labelName;
								this.pricingModelUpdateList[this.cnt]="";
								this.pricingModelEditList[this.cnt]="Y";
							}
						}
					}else{
						this.snackBar.open(this._translate.instant("commonMessage.templateEdit"), null, {duration: 3500})
						this.thisDialogRef.close();
					}
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.templateEdit"), null, {duration: 3500})
					this.thisDialogRef.close();
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
		this.loadingFlag="";
	}

	
	protected createNewObject(): ITemplateApproval {
		return new TemplateApproval("", this.cedentId);
	}
	
	public EditDetail(rowNo,sectionName) {
		if(sectionName=="Question"){
			this.questionUpdateList[rowNo]="Y";
			this.questionEditList[rowNo]="";
		}else if(sectionName=="Wording"){
			this.wordingUpdateList[rowNo]="Y";
			this.wordingEditList[rowNo]="";
		}else if(sectionName=="PricingModel"){
			this.pricingModelUpdateList[rowNo]="Y";
			this.pricingModelEditList[rowNo]="";
		}
	}
	
	public UpdateDetail(rowNo,sectionName) {
		if(sectionName=="Question"){
			this.questionUpdateList[rowNo]="";
			this.questionEditList[rowNo]="Y";
		}else if(sectionName=="Wording"){
			this.wordingUpdateList[rowNo]="";
			this.wordingEditList[rowNo]="Y";
		}else if(sectionName=="PricingModel"){
			this.pricingModelUpdateList[rowNo]="";
			this.pricingModelEditList[rowNo]="Y";
		}
	}
	
	onCloseCancel() {
		this.thisDialogRef.close('Cancel');
	}
	
	public QuestionnaireList(){
		this.questionTag="Y";
		this.wordingTag="";
		this.pricingModelTag="";
	}
	
	public WordingList(){
		this.questionTag="";
		this.wordingTag="Y";
		this.pricingModelTag="";
	}
	
	public PricingModelList(){
		this.questionTag="";
		this.wordingTag="";
		this.pricingModelTag="Y";
	}
	
	
	public Publish(){
		this.thisDialogRef.close();
	}
}
