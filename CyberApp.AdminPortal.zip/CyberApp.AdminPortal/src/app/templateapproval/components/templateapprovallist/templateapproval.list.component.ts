import { Component, Injector } from '@angular/core';

import { TemplateApprovalService } from '../../services/templateapproval.service';

import { TemplateApproval, TemplateApprovalDataSource } from '../../models';
import { ITemplateApproval } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './templateapproval.list.component.html',
  styleUrls: ['./templateapproval.list.component.scss']
})
export class TemplateApprovalListComponent extends CedentEntityListComponent<ITemplateApproval> {

  //displayedColumns = ['id', 'country', 'cedentid', 'cedentname', 'pricingtemplate', 'delete'];
  displayedColumns = ['id','templateDocument','cedentID','cedentName','templateType','effectiveDate','reason','status'];
  dataSource: TemplateApprovalDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("templateApproval.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("templateApproval.deleteerror");
  }

  constructor(
    injector: Injector,
    private templateApprovalService: TemplateApprovalService
  ){
    super(injector, templateApprovalService);
  }

  protected createDataSource(): TemplateApprovalDataSource {
    return new TemplateApprovalDataSource(this.entityService);
  }
  
  public goToDetail(Approval)
  {
	if(Approval.Status.toUpperCase()=="PENDING")
	{
		super.goToDetail(Approval)
	}
  }

  getMessageDelete(templateApproval: ITemplateApproval) {
    var options = { templateApproval: templateApproval.TemplateCedentId};
    return this.getTranslation('templateApproval.reallydelete', options);
  }
}