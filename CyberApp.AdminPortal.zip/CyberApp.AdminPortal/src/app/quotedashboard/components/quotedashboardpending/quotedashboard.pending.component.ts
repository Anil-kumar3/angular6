import {PagedAutocompleteComponent} from '../../../common/components/pagedautocomplete/paged.autocomplete.component';
import {MdSlideToggleChange, MdDialog, MdDialogRef,MdSnackBar,ComponentType, MD_DIALOG_DATA} from '@angular/material';
import {IQuotedashboard, IRole, ICountry, IsearchData,ISearchquotes} from '../../../common/models/contracts/models.contracts';
import {QuotedashboardViewComponent} from '../quotedashboardview/quotedashboard.view.component';
import {QuotedashboardDataSource, Quotedashboard} from '../../models';
import {RoleService, ParameterService, CountryService} from '../../../cedent/services';
import { Component, OnInit, Injector, ViewChild, ElementRef, Renderer2, AfterViewInit, Inject } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {FormControl} from '@angular/forms';
import {QuotedashboardService} from '../../services/quotedashboard.service';
// import {Quotedashboard} from '../../models/quotedashboard';
import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';
import {StringUtils} from '../../../common/utils/string.utils';
import {ConfigurationService} from '../../../configuration/services/configuration.service';
import {Observable, Subscription} from 'rxjs/Rx';
import {keyPressvalidUtils} from "../../../common/utils/keyPress-valid.Utils";
import { environment } from '../../../../environments/environment';
import { Request, XHRBackend, RequestOptions, Response, Http, RequestOptionsArgs, Headers } from '@angular/http'; 
import { getCedentId } from '../../../common/utils/cedent.utils';
import { HttpService, HttpServiceFactory } from '../../../common/services/http.service';
import { ProfileService } from '../../../profile/services/profile.service';
import { Location } from '@angular/common';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { TemplateEditComponent } from '../../../templateapproval/components/templateedit/templateedit.component';
import { NouiFormatter } from "ng2-nouislider/src/nouislider"; 


@Component({
	templateUrl: './quotedashboard.pending.component.html',
	styleUrls: ['./quotedashboard.pending.component.scss']
})

export class QuotedashboardPendingComponent extends CedentEntityDetailComponent<IQuotedashboard> implements OnInit{
	
	protected snackBar: MdSnackBar;
	protected _entityHttpService: HttpService<any>;
	filestring : string;
	loadingFlag:string;
	public error: string;
	@ViewChild('slider', { read: ElementRef }) slider: ElementRef;
	private questionUpdateList: string;
	private questionEditList: string;
	private reason: string;
	public disabled: boolean = false;          
    public someValue: number = 10;
    public someMin: number = 5;
    public someMax: number = 20;
	public someRange2= [5]
	maxval;minval;
	public handleIndex = 0;
	someRange;
	
	/**
		Slider configuration setup
	**/
  someConfig: any = {
	behaviour: '', /** Movement of sliders **/
	connect: true, /** Connecting 2 handled **/
	start: [this.data.premium,Math.round(this.data.premium*2)], /** it decides how many slider handle need & whats the value for that.. Here we used 2 handles with 2 values **/
	padding: [this.data.premium,0], /** Setup padding left right value for both slider handles **/
	step: 1, /** Range movement of slider **/
	range: {  /** setting range for slider **/
		min: this.data.premium * 0.8, /** Minimum range is 80% of premium value **/
		max: this.data.premium*4
	}
  }
  
  /**
	Setup slider events for css
  **/
  firstHandle: Element;
  secondHandle: Element;
  firstConnect: Element;
  secondConnect: Element;
  firstOrigin: Element;
  horizontalSlider: Element;
  uibefore: Element;
	
	constructor(private _dialog: MdDialog,
		injector: Injector,
		private cedentcreationService: QuotedashboardService,
		private countryService: CountryService,
		private configurationService: ConfigurationService,
		private _translate: TranslateService,
		private roleService: RoleService,
		private parameterService: ParameterService,
		private profileService: ProfileService,
		private renderer: Renderer2,
		@Inject(MD_DIALOG_DATA) public data: any,
		public thisDialogRef: MdDialogRef<QuotedashboardPendingComponent>, 
		private location: Location,
		httpServiceFactory: HttpServiceFactory) {
			super(injector, cedentcreationService);
			this.snackBar = injector.get(MdSnackBar);
			this._entityHttpService = httpServiceFactory.getInstance<any>(this.filestring)
		}
	
	/**
		Slider initialization
	**/
	ngAfterViewInit() {
		this.firstHandle = this.slider.nativeElement.querySelector('.noUi-handle[data-handle=\'0\']'); 
		this.secondHandle = this.slider.nativeElement.querySelector('.noUi-handle[data-handle=\'1\']');
		this.firstConnect = this.slider.nativeElement.querySelector('.noUi-connect'); 
		this.secondConnect = this.slider.nativeElement.querySelector('.noUi-connect');
		this.firstOrigin = this.slider.nativeElement.querySelector('.noUi-origin'); 
		this.horizontalSlider = this.slider.nativeElement.querySelector('.noUi-horizontal');
		
	}

	/**
		Update slider CSS manually & set the min max value as per movement
	**/
	onUpdate(event) {
		this.renderer.setStyle(this.firstHandle, 'background', 'rgb(80, 207, 181)');
		this.renderer.setStyle(this.firstHandle,'border-radius','14px'); 
		this.renderer.setStyle(this.secondHandle, 'background', 'rgb(159, 1, 255)');
		this.renderer.setStyle(this.secondHandle,'border-radius','14px'); 
		this.renderer.setAttribute(this.firstOrigin,'disabled','true'); 
		this.renderer.setStyle(this.secondConnect,'background','rgb(159, 1, 255)'); 
		this.renderer.setStyle(this.horizontalSlider, 'height', '10px');
		this.renderer.setStyle(this.firstHandle, 'width', '26px');
		this.renderer.setStyle(this.firstHandle, 'height', '20px');
		this.renderer.setStyle(this.secondHandle, 'width', '26px');
		this.renderer.setStyle(this.secondHandle, 'height', '20px');
		
		
		if(this.someRange)
		{
			let res = this.someRange.toString().split(",");
			/* this.minval = "$ "+this.inrFormat(res[0]);
			this.maxval="$ "+this.inrFormat(res[1]); */
			this.minval = this.data.currency+" "+this.data.premium;
			this.maxval=this.data.currency+" "+res[1];
		}
	}
	  
	/**
		Function Calling on page load
	**/
	async ngOnInit() {
		this.minval=this.data.currency+" "+this.data.premium;
		this.maxval=this.data.currency+" "+(Math.round(this.data.premium*2));
		this.loadingFlag = "Loading data...";
		this.questionEditList="Y";
		super.ngOnInit();
		
		this.loadingFlag = "";
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);

		
	}
	
	/**
		Validation for click on Approve/Reject/Refer selected by underwriter
		@Action : Approve/Reject/Refer
	**/
	private gotoStatus(Action)
	{
		if(Action=="Rejected" && NullUndefined(this.cedentEntity.reason)=="")
		{
			this.error="selectReason"
		}else if(Action=="ReferEmail"){
			this.apiAction(Action,"")
		}else{
			this.apiAction(Action,this.cedentEntity.reason)
		}
	}
	
	/**
		Webservice call for Approve/Reject/Refer selected by underwriter
		@ Action : Approve/Reject/Refer
		@ Reason : Reason for Rejecting quote
	**/
	private apiAction(Action,Reason)
	{
		this.loadingFlag = "loading";
		var QuoteServices = this.searchRecord('QuoteDashboard',Action,this.data.referencenum,this.data.premium,NullUndefined(Reason))
			.subscribe(
			  response => {
				this.loadingFlag = "";
				var result = response;
				this.snackBar.open("Data Saved Successfully", null, {duration: 3500})
				console.log(result);
				this.thisDialogRef.close();
			  }, error => {
					this.loadingFlag = "";
					this.snackBar.open("Unable to connect web service", null, {duration: 3500})
					return;
			}
		);
	}
	
	/**
		Close Pop up on click of close button
	**/
	private closeModal() {
		this.thisDialogRef.close();
	}
	
	/**
		Enable Text area field on click of Edit button.
	**/
	public EditDetail(rowNo,sectionName) {
		this.questionUpdateList="Y";
		this.questionEditList="";
	}
	
	/**
		Dissable Text area field on click of Update button.
	**/
	public UpdateDetail(rowNo,sectionName) {
		this.questionUpdateList="";
		this.questionEditList="Y";
	}
	
	/**
		Create Object for Dashboard
	**/
	protected createNewObject(): IQuotedashboard {
		return new Quotedashboard(this.cedentId,"","","");
	}
	 
	 /** API Server Validation **/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag = "";
		return;
	}
	

}