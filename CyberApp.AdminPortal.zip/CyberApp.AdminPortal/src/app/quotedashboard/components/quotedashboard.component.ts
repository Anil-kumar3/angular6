import { Component } from '@angular/core';


@Component({
  selector: 'quotedashboard',
  template: '<router-outlet></router-outlet>'
})
export class QuotedashboardComponent {

  constructor(  ) {}
}