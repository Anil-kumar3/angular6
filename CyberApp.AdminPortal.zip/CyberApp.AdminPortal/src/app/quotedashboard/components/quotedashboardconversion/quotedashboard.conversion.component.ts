import {PagedAutocompleteComponent} from '../../../common/components/pagedautocomplete/paged.autocomplete.component';
import {MdSlideToggleChange, MdDialog, MdDialogRef,MdSnackBar,ComponentType} from '@angular/material';
import {IQuotedashboard, IRole, ICountry, IsearchData,ISearchquotes} from '../../../common/models/contracts/models.contracts';
import {QuotedashboardViewComponent} from '../quotedashboardview/quotedashboard.view.component';
import {QuotedashboardDataSource, Quotedashboard} from '../../models';
import {RoleService, ParameterService, CountryService} from '../../../cedent/services';
import { Component, OnInit, Injector, ViewChild, ElementRef,Inject, Pipe, PipeTransform  } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {FormControl} from '@angular/forms';
import {QuotedashboardService} from '../../services/quotedashboard.service';
// import {Quotedashboard} from '../../models/quotedashboard';
import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';
import {StringUtils} from '../../../common/utils/string.utils';
import {ConfigurationService} from '../../../configuration/services/configuration.service';
import {Observable, Subscription} from 'rxjs/Rx';
import {keyPressvalidUtils} from "../../../common/utils/keyPress-valid.Utils";
import { environment } from '../../../../environments/environment';
import { Request, XHRBackend, RequestOptions, Response, Http, RequestOptionsArgs, Headers } from '@angular/http'; 
import { getCedentId } from '../../../common/utils/cedent.utils';
import { HttpService, HttpServiceFactory } from '../../../common/services/http.service';
import { ProfileService } from '../../../profile/services/profile.service';
import { Location } from '@angular/common';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { QuotedashboardPendingComponent } from  '../quotedashboardpending/quotedashboard.pending.component'
import { DatePipe } from '@angular/common';

@Component({
	templateUrl: './quotedashboard.conversion.component.html',
	styleUrls: ['./quotedashboard.conversion.component.scss']
})

export class QuotedashboardConversionComponent extends CedentEntityDetailComponent<IQuotedashboard> implements OnInit{
	
	dataSource: QuotedashboardDataSource | null;
	displayedColumns = ['id', 'cedentID', 'cedentName'];
	public usertype:boolean;
	public fileList:FileList;
	public searchFlag:Number=0;	
	private validationErrors: Array<string>;
	public country: ICountry[];
	public serchQuotesArr:ISearchquotes[];
	public DashboardcedentIdArr:IsearchData[];
	public DashboardcedentIdArr1:IsearchData[];
	public searchQuoteflag: boolean = false;
	private userSubscription: Subscription;
	public Overview_searchinp = "";
	public DashboardCountry = undefined;
	public DashboardcedentId: any;
	public StartDate:string;
	public EndDate:string;
	public error: string;
	public countrycode: string;
	public collection = [];
	search: string;
	public NumberofFileArr=[];
	public fileName:string;	
	public file_details=[];
	private localStorageService = new LocalStorageService
	protected snackBar: MdSnackBar;
	protected _entityHttpService: HttpService<any>;
	filestring : string;
	public dialogRef:any;
	private file;
	private allowedExtensions=[];
	private fileExtension;
	private fileSize;
	private revised_premium=[];
	private loading_percentage=[];
	private viewerror =[];
	private Quote_reason=[];
	private status=[];
	private Identifier:string;
	private loadingFlag:string;
	private maxDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
	private pendingFlag="dashboardPage";
	/** Data for Dashboard **/
	chartData = [
		{label: '', data: []}
	];
	private quoteResponse=[{'Pending':'1'},{'Accepted':'1'},{'Rejected':'1'}];
	private PendingActionRequired:string;
	private WaitingForRIUWAction:string;
	private AcceptedAction:string;
	private DeniedAction:string;
	private quotePending:number;
	private quoteAccepted:number;
	private quoteDenied:number;
	private actionReqCount:number;
	private UWCount:number;
	private ActionRequired:Array<any>;
	
	
	constructor(private _dialog: MdDialog,
		injector: Injector,
		private cedentcreationService: QuotedashboardService,
		private countryService: CountryService,
		private configurationService: ConfigurationService,
		private _translate: TranslateService,
		private roleService: RoleService,
		private parameterService: ParameterService,
		private profileService: ProfileService,
		private location: Location,
		httpServiceFactory: HttpServiceFactory) {
			super(injector, cedentcreationService);
			this.validationErrors = new Array<string>();
			this.snackBar = injector.get(MdSnackBar);
			this._entityHttpService = httpServiceFactory.getInstance<any>(this.filestring)
		}

	/** 
		Function Calling on page load
	**/
	async ngOnInit() {
		this.loadingFlag = "Loading data...";
		this.pendingFlag = "dashboardPage"
		super.ngOnInit();
		this.userSubscription = this.profileService.getAuthenticatedProfile().subscribe(user => {
			if(NullUndefined(user)!="")
			{
				this.Identifier = user.Roles[0].Name;
				if(user.Identifier.toLowerCase()=="superadmin")
					this.usertype=true;
				else
					this.usertype=false;
			}else{
				this.usertype=false;
			}
        });
		
		/* var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		); */
		
		this.quoteRecord();
		
		// this.fetchQuotes();
		this.loadingFlag = "";
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
		
	}
	
	/**
		Webservice call for collecting the Dashboard data
	**/
	private async quoteRecord() {
		var rootcedentId = getCedentId();
		var countryPromise = this.searchRecord('Dashboard/QuoteData','Cedent - Underwriter',rootcedentId,"","")
		.subscribe(
			  response => {
				this.quoteResponse = response;
				this.PendingActionRequired = response.ActionRequired
				this.WaitingForRIUWAction = response.WaitingForRIUWAction
				this.actionReqCount = this.PendingActionRequired.length;
				this.UWCount = this.WaitingForRIUWAction.length;
				this.AcceptedAction = response.AcceptedData;
				this.DeniedAction = response.RejectedData;
				console.log("this.actionReqCount:"+this.actionReqCount+"--this.UWCount:"+this.UWCount);
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}
	
	/**
		Functionality of the Page will destroy once other page will load.
	**/
	ngOnDestroy() {
        this.userSubscription.unsubscribe();
        this.userSubscription = undefined;
    }
	
	/**
		Function is calling on click of pending/resolve button 
	**/
	private gotoAction() {
		this.pendingFlag="pendingPage"
		this.snackBar.dismiss();
	}
	
	/**
		Calling web service for collecting data of Accepted quotes
	**/
	private gotoAccept() {
		this.pendingFlag="acceptedPage"
	}
	
	/**
		Calling web service for collecting data of Denied quotes
	**/
	private gotoDenied() {
		this.pendingFlag="deniedPage"
	}
	
	/**
		Function calling on click of pending action back button. 
	**/
	private gotoDashboard() {
		this.pendingFlag="dashboardPage";
		this.quoteRecord();
	}
	
	/**
		Calling function for popup Display on click of pending data
		@param1: Country
		@param2: Client Name
		@param3: Quote Date
		@param4: Net Premium
		@param5: Quote Reference Number
		@param6: Currency
	**/
	private openModal(param1,param2,param3,param4,param5,param6) {
		console.log(param5)
		var datePipe = new DatePipe("en-US");
		param3 = datePipe.transform(param3, 'dd/MM/yyyy');
		param4=param4.replace(/,/g,'')
		console.log(param4);
		this.openDialog(param1,param2,param3,param4,param5,param6);
	}
	
	/**
		Passing all the parameters to Pending page & displaying the popup.
		@param1: Country
		@param2: Client Name
		@param3: Quote Date
		@param4: Net Premium
		@param5: Quote Reference Number
		@param6: Currency
	**/
	openDialog(param1,param2,param3,param4,param5,param6) {
		this.dialogRef = this._dialog.open(QuotedashboardPendingComponent, {
		  
		  disableClose: true,
		  data:{
				recordID:this.cedentEntity.id,
				country:param1,
				client_name:param2,
				quotedate:param3,
				premium:param4,
				referencenum:param5,
				currency:param6
			}
		});
		this.dialogRef.afterClosed().subscribe(result => {
		  this.quoteRecord();
		});
	}
	
	/**For Reponsive Dashbord bar chart**/
	chartOptions = {
		responsive: true    
	}
	
	/** 
		labels & background color for Dashboard bar chart 
	**/
	labels = ['Quoted', 'Converted', 'Lost', 'Rejected UW'];
	colors = [{backgroundColor: 'rgba(30, 169, 224, 0.8)'}]


	/** 
		Function call On click of chart bar 
	**/
	onChartClick(event) {
		console.log(event);
	}
	
	/** 
		Search CedentId w.r.t Cedent Name
	**/
	public filterListCareUnit(val) {
		this.DashboardcedentIdArr = this.DashboardcedentIdArr1;
		this.DashboardcedentIdArr = this.DashboardcedentIdArr.filter((unit) => unit.CedentName.indexOf(val) > -1);
	}

	/** 
		Clear Cedent Search Field 
	**/
	public clearSearch() {
		this.search = ""
		this.DashboardcedentIdArr = this.DashboardcedentIdArr1;
	}

	/** 
		Function call On click of choose File
	**/	
	public Uploadfile(event,docno):void {
		if(this.viewerror[docno])
			this.viewerror[docno] = '';
		
		this.file = event.target.files[0];
		this.fileName = this.file.name;
		this.fileSize = this.file.size;
		this.allowedExtensions = ["doc","docx","xlsx","xls","csv","pdf"];
		this.fileExtension = this.fileName.split('.').pop();
		if(this.isInArray(this.allowedExtensions, this.fileExtension)) {
			this.viewerror[docno]="errorfileextension";
		}else if(this.fileSize < 500000 || this.fileSize > 5000000 ){
			this.viewerror[docno]="errorfilesize";
		}else{
			this.file_details[docno][event.currentTarget.id[1]] = event.target.files[0];
		}
		
		event.target.value = null
	}
	
	
	/**
		Function is calling For checking Extension of file
	**/
	public isInArray(array, word):boolean {
		if(array.indexOf(word.toLowerCase()) > -1){
			return false;
		}else{
			return true;
		}
	}

	/** 
		Search Quotes w.r.t country,cedentId,startdate & endate 
	**/	
	public searchQuote():void {
		this.searchQuoteflag = true;
		this.error ="";
	}
	
	/**
		Calling for Close Search Section
	**/
	public Quoteconversion_Back():void {
		this.DashboardCountry = undefined;
		this.DashboardcedentId = undefined;
		this.StartDate = undefined;
		this.EndDate = undefined;
		this.searchQuoteflag = false;
		this.fetchQuotes();
		this.error ="";
	}

	/**
		Page lebel Field validation & upload the data into server
	**/	
	public Searchsave():void {
		if (NullUndefined(this.DashboardCountry) == '') {
			this.error = 'selectcountry';
			return;
		} else if (NullUndefined(this.DashboardcedentId) == '') {
			this.error = 'selectdashboardcedentId';
			return;
		}else if (NullUndefined(this.StartDate) == '') {
			this.error = 'selectstartdate';
			return;
		}else if (NullUndefined(this.EndDate) == '') {
			this.error = 'selectenddate';
			return;
		}else if ( new Date(NullUndefined(this.StartDate)) > new Date(NullUndefined(this.EndDate))){
			this.error = 'selectlessStartDate';
			return;
		}  else {
			this.error = '';
			this.SearchQuotes(NullUndefined(this.DashboardCountry),NullUndefined(this.DashboardcedentId),NullUndefined(this.StartDate),NullUndefined(this.EndDate));
		}
	}

	/**
		Function called whenever country drop down is changed.
		It internally calls fetch record for cedent id created for the country selected.
	**/
	 public changeCountry() {
		for (let cnt = 0; cnt < this.country.length; cnt++) {
			if (this.DashboardCountry == this.country[cnt].CountryName) {
				this.countrycode = this.country[cnt].CountryCode;
				break;
			}
		}
		this.fetchCedentIDs();
	}

	/** 
		Fetching Cedent IDs from web service w.r.t selected country
	**/
	private async fetchCedentIDs() {
		var promises = [];
		var rootcedentId = getCedentId();
		if (NullUndefined(rootcedentId) == "")
        {
			rootcedentId = this.localStorageService.get("superAdminID");
		}
		this.loadingFlag = "loading...";
		/*var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(this.DashboardCountry), NullUndefined(this.countrycode),		
		NullUndefined(rootcedentId)).toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			this.loadingFlag = "";
			return;
		});
		promises.push(seqnoPromise);
		if (this.isExistEntity) {
			var userPromise = this.entityLoaded.first().toPromise();
			promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		if(result[0].length>0){
			this.DashboardcedentIdArr = result[0];
			this.DashboardcedentIdArr1=this.DashboardcedentIdArr;
		}else{
			this.DashboardcedentId="";
			this.DashboardcedentIdArr=[];
		}
		this.loadingFlag = "";*/
		
		var seqnoPromise =this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(this.DashboardCountry), NullUndefined(this.countrycode),NullUndefined(rootcedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.DashboardcedentIdArr = result;
                    this.DashboardcedentIdArr1 = this.DashboardcedentIdArr;
                    this.snackBar.dismiss();
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.cedentDetails"), null, {duration: 3500})
					this.DashboardcedentId="";
					this.DashboardcedentIdArr=[];
					this.DashboardcedentIdArr1=[];
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}

	/**
		Creating Object for Quote dashboard
	**/
	protected createNewObject(): IQuotedashboard {
		return new Quotedashboard(this.cedentId,"","","");
	}

	/**
		Calling web service for getting records of dashboard & store it in collection array 
	**/	
	private async fetchQuotes() {
		this.file_details=[];
		this.NumberofFileArr=[];
		var promises2 = [];
		this.loadingFlag = "loading...";
		/*var seqnoPromise = this.searchRecord('Support', "", "", "", "").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to fetch quote detail", null, {duration: 3500})
			this.loadingFlag = "";
			return;
		});
		promises2.push(seqnoPromise);
		if (this.isExistEntity) {
			var userPromise2 = this.entityLoaded.first().toPromise();
			promises2.push(userPromise2);
		}
		var result = await Promise.all(promises2);
		console.log(result[0]);*/
		
		var result;
		var seqnoPromise = this.searchRecord('Support', "", "", "", "")
		.subscribe(
			  response => {
				result = response;
				if(result.QuoteData.length > 0 && result !="No Data Found"){
					console.log(result);
					this.chartData = [
						{
							label: '',
							data: []
						}
					];

					this.chartData[0].label = "Quotes";
					this.chartData[0].data.push(result.Quoted);
					this.chartData[0].data.push(result.Converted);
					this.chartData[0].data.push(result.Lost);
					this.chartData[0].data.push(result.RejectedUW);
					this.collection=[];
					for (let i = 0; i < result.QuoteData.length; i++) {
						if(this.usertype == true){
							this.revised_premium[this.collection.length]=result.QuoteData[i].RevisedPremium;
							this.loading_percentage[this.collection.length]=result.QuoteData[i].LoadingPercentage;
							this.Quote_reason[this.collection.length]=result.QuoteData[i].Quotereason;
							if(NullUndefined(result.QuoteData[i].Status)!="")
								this.status[this.collection.length]=result.QuoteData[i].Status;
							else if(NullUndefined(result.QuoteData[i].Status)=="")
								this.status[this.collection.length]="PENDING";
						}
						if((result.QuoteData[i].Status != "APPROVED" && result.QuoteData[i].Status != "REJECTED") || (this.usertype == true)){
							this.collection.push({QuoteNo: result.QuoteData[i].QuoteNumber, Premium: result.QuoteData[i].Premium,RecordID: result.QuoteData[i].id});
							
						}
						
						var temp_arry=[];
						var temp_arry1=[];
						this.file_details.push(temp_arry1);
						this.NumberofFileArr.push(temp_arry);
						if(this.usertype == true){
							for(let j=0; j < result.QuoteData[i].FileDetail.length; j++)
							{
								this.file_details[i].push(result.QuoteData[i].FileDetail[j].FileUploadName);
								this.NumberofFileArr[i].push(j)
							}
						}
					}
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.quoteData"), null, {duration: 3500});
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		this.loadingFlag = "";
	}

	/** Clear Serch fields **/	
	 public resetData(): void {
		this.DashboardCountry = undefined;
		this.DashboardcedentId = undefined;
		this.StartDate = undefined;
		this.EndDate = undefined;
	}

	/** Search Quotes w.r.t country,cedentId,startdate,endate & call to webservice  **/
	private async SearchQuotes(country,cedentId,startdate,enddate){
		var promises2 = [];
		this.loadingFlag = "loading...";
		/*var seqnoPromise = this.searchRecord('Support',country,cedentId,startdate,enddate).toPromise()
		.catch(error => {
			this.snackBar.open("Unable to fetch detail", null, {duration: 3500})
			this.loadingFlag = "";
			return;
		});
		promises2.push(seqnoPromise);
		/* if (this.isExistEntity) {
			var userPromise2 = this.entityLoaded.first().toPromise();
			promises2.push(userPromise2);
		} 
		var result = await Promise.all(promises2);
		this.serchQuotesArr = result[0];*/
		
		var seqnoPromise = this.searchRecord('Support',country,cedentId,startdate,enddate)
		.subscribe(
			  response => {
				var result = response;
				if(result.QuoteData.length>0 && result !="No Data Found"){
					this.chartData = [
						{
							label: '',
							data: []
						}
					];

					this.chartData[0].label = "Quotes";
					this.chartData[0].data.push(result.Quoted);
					this.chartData[0].data.push(result.Converted);
					this.chartData[0].data.push(result.Lost);
					this.chartData[0].data.push(result.RejectedUW);
					this.collection=[];
					for (let i = 0; i < result.QuoteData.length; i++) {
						if((result.QuoteData[i].Status != "APPROVED" && result.QuoteData[i].Status != "REJECTED") || (this.usertype == true)){
							this.collection.push({QuoteNo: result.QuoteData[i].QuoteNumber, Premium: result.QuoteData[i].Premium,RecordID: result.QuoteData[i].id});
						}	
					}
					this.loadingFlag = "";
				}else{
					//this.collection=[];
					this.snackBar.open(this._translate.instant("commonMessage.quoteData"), null, {duration: 3500})
					this.chartData = [
						{
							label: '',
							data: []
						}
					];
					this.collection=[];
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		
		
	}

	/**
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	**/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "Premium"){
			return keyPressvalidUtils.mobileValidation(evt,NullUndefined(FieldValue));
		}
	}

	/** Approve Quote **/
	public ApproveQuote(recordno):void {
		this.Quoteviewvalidation("APPROVED",recordno);
	}

	/** Reject Quote **/
	public RejectedQuote(recordno):void {
		this.Quoteviewvalidation("REJECTED",recordno);
	}

	/**Field Validation of  quote view **/	
	public Quoteviewvalidation(flag,recordno):void {
		if (NullUndefined(this.revised_premium[recordno]) == '' && (flag =="APPROVED")) {
			this.viewerror[recordno] = 'errorRevisedpremium';
			return;
		} else if (NullUndefined(this.loading_percentage[recordno]) == '' && (flag =="APPROVED")) {
			this.viewerror[recordno] = 'errorloadingpercentage';
			return;
		}else if (NullUndefined(this.Quote_reason[recordno]) == '' && (flag =="REJECTED")) {
			this.viewerror[recordno] = 'errorQuotereason';
			return;
		} else {
			this.viewerror[recordno] = '';
			this.upload(recordno,flag);
		}   
	}

	/** Upload data & files on database **/
	public upload(recordno,statusflag): void {
		const formData = new FormData();
			
		formData.append("Revisedpremium", NullUndefined(this.revised_premium[recordno]));
		formData.append("LoadingPercentage", NullUndefined(this.loading_percentage[recordno]));
		formData.append("Quotereason", NullUndefined(this.Quote_reason[recordno]));
		formData.append("QuoteNumber", NullUndefined(this.collection[recordno].QuoteNo));
		formData.append("RecordID", NullUndefined(this.collection[recordno].RecordID));
		formData.append("Status", NullUndefined(statusflag));
		for(let i=0;i<this.file_details[recordno].length;i++){
			formData.append('file',this.file_details[recordno][i],this.file_details[recordno][i].name);
		}	
		
		this._entityHttpService.uploadFile(formData,"QuoteDashboard").then(() => {
		  console.log("Upload Success");
		  location.reload();
		  this.fetchQuotes();
		}, (error) => {
		  this.onServerError(error,recordno);
		});
	}


	/** Add files **/
	public AddFiles(docno):void {
		if(this.file_details[docno].length == this.NumberofFileArr[docno].length){
			 if(this.NumberofFileArr[docno].length < 10){
				this.NumberofFileArr[docno].push(this.NumberofFileArr[docno].length);
			 }
		}else{
			this.viewerror[docno] = 'selectChooseFile';	
		}
	}
	
	/** Remove Files **/
	public RemoveFiles(docno,fileno):void {
		
		for(let i=fileno;i< this.file_details[docno].length;i++){
			this.file_details[docno][i]=this.file_details[docno][i+1];
		}
		this.NumberofFileArr[docno].pop();
		if(!this.file_details[docno][this.file_details[docno].length-1])
			this.file_details[docno].pop();
	}
	
		
	/**check Document availability after search **/	
	public searchinput():void {
		this.searchFlag =0; 
		for(var val in this.collection) {
			if((this.collection[val].Premium).indexOf(this.Overview_searchinp) > -1 || (this.collection[val].QuoteNo).indexOf(this.Overview_searchinp) > -1 ) {
				this.searchFlag =1;
				break;
			}
		}
	}
	
	/** API call for View File **/
	private async viewFile(fileno,filename,QuoteNo) {
		//QuoteNo="Q0004";
		
		console.log("fileNo:"+fileno);
		console.log("filename:"+filename);
		console.log("QuoteNo:"+QuoteNo);
		this.loadingFlag = "loading...";
		/*var seqnoPromise = this.downloadFile(filename,'QuoteDashboard', 'VIEWDOC', QuoteNo,fileno,'').toPromise()
		.catch(error => {
			this.snackBar.open("Unable To Download File", null, {duration: 3500})
			this.loadingFlag = "";
			return;
		});
		this.loadingFlag = "";*/
		
		var seqnoPromise = this.downloadFile(filename,'QuoteDashboard', 'VIEWDOC', QuoteNo,fileno,'')
		.subscribe(
			  response => {
				var result = response;
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabledownloadfile"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}
	
	/** API Server Validation **/
	public onServerError(error,recordno){
		this.viewerror[recordno] = error.Message;
		this.loadingFlag="";
	}
	
	/** Referrel Email **/
	 public ReferralMail(QuoteNo,RecordId):void {
		 let dialog = this._dialog.open(QuotedashboardViewComponent, {
		  width: '600px',
		   data: {
			entity: new Quotedashboard("","",QuoteNo,RecordId)
		  } 
		});
		
		dialog.afterClosed().subscribe((result: IQuotedashboard) => {
		  if (result !== null && result !== undefined) {
			//this.addAnswer(result);
			console.log("result:"+result);
		  }
		  console.log("result:"+result);
		})
	 }
	 
	 /** API Server Validation **/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag = "";
		return;
	}
	
	 protected createDataSource(): QuotedashboardDataSource {
    return new QuotedashboardDataSource(this._entityService);
  }

}