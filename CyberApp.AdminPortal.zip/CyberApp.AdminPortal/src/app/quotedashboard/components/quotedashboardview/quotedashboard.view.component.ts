import { Component, OnInit,Inject,Injector, ViewChild, ElementRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {FormControl} from '@angular/forms';

import {RoleService, ParameterService, CountryService} from '../../../cedent/services';

import {IQuotedashboard, IRole, ICountry, IsearchData} from '../../../common/models/contracts/models.contracts';
import {QuotedashboardService} from '../../services/quotedashboard.service';

import {Quotedashboard} from '../../models/quotedashboard';

import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';
import {StringUtils} from '../../../common/utils/string.utils';
import {ConfigurationService} from '../../../configuration/services/configuration.service';

import {Observable, Subscription} from 'rxjs/Rx';
import {keyPressvalidUtils} from "../../../common/utils/keyPress-valid.Utils";
import {MdSlideToggleChange, MdDialog, MdDialogRef,MdSnackBar,MD_DIALOG_DATA,ComponentType} from '@angular/material';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { EmailValidate } from "../../../common/utils/emailvalidation.utils";

@Component({
  selector: 'quotedashboardview',
  templateUrl: './quotedashboard.view.component.html',
  styleUrls: ['./quotedashboard.view.component.scss']
})
export class QuotedashboardViewComponent extends CedentEntityDetailComponent<IQuotedashboard> implements OnInit {

		cedentEntity: IQuotedashboard;
		public DataArr:any;
		public emailId:string = "";
		public error: string;
		
        private validationErrors: Array<string>;
        private _dialogRef: MdDialogRef<QuotedashboardViewComponent>;
		protected snackBar: MdSnackBar;
		loadingFlag:string;
		
        constructor(
		dialogRef: MdDialogRef<QuotedashboardViewComponent>,
		@Inject(MD_DIALOG_DATA) public data: any,
        injector: Injector,
        private cedentcreationService: QuotedashboardService,
        private countryService: CountryService,
        private configurationService: ConfigurationService,
        private _translate: TranslateService,
        private roleService: RoleService,
        private parameterService: ParameterService
	) {
        super(injector, cedentcreationService);
        this.validationErrors = new Array<string>();
		 this._dialogRef = dialogRef;
		 this.snackBar = injector.get(MdSnackBar);
		 
		 this.cedentEntity = data.entity;
		 this.DataArr=this.cedentEntity;
		 console.log("this.cedentEntity:");
		 console.log(this.cedentEntity);
		 console.log(JSON.stringify(this.cedentEntity));
    }
	
	/** 
		Function Calling on page load
	**/
    async ngOnInit() {
		//this.loadingFlag = "Loading data...";
        super.ngOnInit();
        
    }
       
/**
		Creating Object for Quote dashboard
	**/
    protected createNewObject(): IQuotedashboard {
        return new Quotedashboard(this.cedentId,"","","");
    }

	/**
		Function Calling for Field Validation & update the data
	**/
	submit(): void {
		
		if (NullUndefined(this.emailId) == '') {
			this.error = 'erroremailId';
			return;
		}else if(EmailValidate(this.emailId) == false){
			this.error = 'errorValidEmailID';
			return;
		}else 
		{
			this.error = '';
			this.loadingFlag = "Saving data...";
			var result = this.searchRecord('QuoteDashboard',"referralemail",NullUndefined(this.emailId),NullUndefined(this.DataArr.RecordID),NullUndefined(this.DataArr.QuoteNumber)).toPromise()
			.then(response => 
			{
				this.error='';
				this.loadingFlag = "";
				this.snackBar.open(this._translate.instant("commonMessage.mailSent"), null, {duration: 3500});
				this.goBack();
			}) 
			.catch(error => {console.log(error);this.onError(error)})
		}
	}
    
	/**
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	**/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "EmailID"){
			return keyPressvalidUtils.emailFormat(evt,NullUndefined(FieldValue));
		}
	}
	
	/**
		Calling for Popup close on click of Back.
	**/
	goBack(): void {
		this._dialogRef.close(null);
	}
	
	/**
		Web service Error validation
	**/
	protected onError(error: any): void {
		console.log(error);
		this.loadingFlag = "";
		this.error = JSON.parse(error._body).Message;
		return;
	}
}
