import { Routes, RouterModule } from '@angular/router';

//import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
//import { RoleNames } from '../common/models/contracts/models.contracts';

import { QuotedashboardComponent } from './components/quotedashboard.component';
import { QuotedashboardConversionComponent } from './components/quotedashboardconversion/quotedashboard.conversion.component';
import { QuotedashboardViewComponent } from './components/quotedashboardview/quotedashboard.view.component';


export var  QuotedashboardRoutes: Routes = [
  {
    path: 'quotedashboard',
    component: QuotedashboardComponent,
    canActivateChild: [ ],
    children: [
      {
        path: '',
        component: QuotedashboardConversionComponent,
      },
      {
        path: ':id',
        component: QuotedashboardViewComponent,
      },
      {
        path: 'create',
        component: QuotedashboardViewComponent,
      }
    ]
  }
];
