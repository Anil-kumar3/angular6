//import { QuotedashboardService } from '../services/quotedashboard.service';
//
//import { IQuotedashboard } from '../../common/models/contracts/models.contracts';
//import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';
//
//
//export class QuotedashboardDataSource 
//  extends CedentEntityDataSource<IQuotedashboard>{
//
//  constructor(userService: QuotedashboardService){
//    super(userService);
//  }
//
//  buildSearchString(item: IQuotedashboard): string {
//    return (item.DashboardCedentId).toLowerCase();
//  }
//}


import { QuotedashboardService } from '../services/quotedashboard.service';

import { IQuotedashboard } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class QuotedashboardDataSource 
  extends CedentEntityDataSource<IQuotedashboard>{

  constructor(userService: QuotedashboardService){
    super(userService);
  }

  buildSearchString(item: IQuotedashboard): string {
    return (item.DashboardCedentId).toLowerCase();
  }
}