import { IQuotedashboard, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Quotedashboard
  extends CedentEntity
  implements IQuotedashboard {

     // public Country:string;
     // public DashboardCedentId:string;
     // public StartDate:Date;
     // public EndDate:Date;
	 public DashboardCedentId:string;
	 public QuoteNumber:string;
	 public RecordID:string;
	 public reason:string;

  constructor(cedentId: string,DashboardCedentId: string, QuoteNumber: string,RecordID: string){
    super(cedentId);

    this.DashboardCedentId = DashboardCedentId;
    this.QuoteNumber = QuoteNumber;
    this.RecordID = RecordID;
  }
}