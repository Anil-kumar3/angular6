import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule,MdDatepickerModule,MdAutocompleteModule,MdSliderModule } from '@angular/material';
//import { MatTableModule,MatPaginatorModule } from '@angular/material';

//import { MdAutocompleteModule, MdButtonModule, MdCardModule, MdCheckboxModule, MdChipsModule, MdDatepickerModule, MdDialogModule, MdIconModule, MdInputModule, MdNativeDateModule, MdTableModule } from '@angular/material';
import { CommonModule } from '../common/common.module';
import { CdkTableModule } from '@angular/cdk/table';
import { NgxPaginationModule } from 'ngx-pagination'
//import {CdkPaginatorModule }from '@angular/cdk';
//import { } from '@angular/material';
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { QuotedashboardComponent } from './components/quotedashboard.component';
import { QuotedashboardConversionComponent } from './components/quotedashboardconversion/quotedashboard.conversion.component';
import { QuotedashboardViewComponent } from './components/quotedashboardview/quotedashboard.view.component';
import { QuotedashboardPendingComponent } from './components/quotedashboardpending/quotedashboard.pending.component';
import { NouisliderModule } from 'ng2-nouislider';

import { ChartsModule } from 'ng2-charts'
//import { FilterPipe } from './filter.pipe';
import { QuotedashboardFilterPipe } from '../common/pipes/QuotedashboardFilter.pipe';
import { QuotedashboardService } from './services/quotedashboard.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdCheckboxModule,
    CdkTableModule,
    MdDatepickerModule,
    CommonModule,
    ChartsModule,
    NgxPaginationModule,
	NouisliderModule,
    MdAutocompleteModule,
    ReactiveFormsModule,
	MdSliderModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    QuotedashboardComponent,
    QuotedashboardConversionComponent,
    QuotedashboardViewComponent,
	QuotedashboardPendingComponent,
	QuotedashboardFilterPipe
    //FilterPipe
  ], 
  providers: [
   QuotedashboardService
  ],
  exports: [
    QuotedashboardConversionComponent
  ],
  entryComponents: [
    QuotedashboardPendingComponent
  ]
})
export class  QuotedashboardModule { }