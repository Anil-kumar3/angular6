import { Injectable } from '@angular/core';

import { IUserType } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class UsertypeService
  extends BaseCedentEntityService<IUserType> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'UserType');
  }
}