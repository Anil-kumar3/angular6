import { Component, OnInit, Injector, ViewChild, ElementRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UsertypeService } from '../../services/usertype.service';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { Usertype, UsertypeDataSource } from '../../models';
import { IUserType, IUTFMap } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { Observable, Subscription } from 'rxjs/Rx';
import { AlertDialog } from '../../../common';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";

@Component({
  selector: 'usertype-detail',
  templateUrl: './usertype.detail.component.html',
  styleUrls: ['./usertype.detail.component.scss']
})
export class UsertypeDetailComponent extends CedentEntityDetailComponent < IUserType > implements OnInit {

	public utfresult: IUserType[];
	error: string;
	displayedColumns = [];
	private _tableFormat = false;
	protected dialog: MdDialog;
	protected snackBar: MdSnackBar;
	dataSource: UsertypeDataSource | null;
	keys = [];
	loadingFlag : string;

	constructor(
		injector: Injector,
		private usertypeService: UsertypeService,
		private _translate: TranslateService
	) {
		super(injector, usertypeService);
		this.dialog = injector.get(MdDialog);
		this.snackBar = injector.get(MdSnackBar);
	}

	/** 
		Function Calling on page load
	**/
	async ngOnInit() {
		this.loadingFlag="Loading";
		super.ngOnInit();
		this.loadingFlag="";
	}

	/** 
		Disable the View button if Cedent & Reinsurer are not selected.
	**/
	public get isValid(): boolean {
		return (this.cedentEntity.isReinsurer || this.cedentEntity.isCedent);
	}

	/** 
		Onclick of View Button 
	**/
	public view(): void {
		this.fetchRecord()
	}
	
	/**
		Function Calling on Checkbox click 
	**/
	private clickOnCheck(): void {
		if (this._tableFormat == true)
			this._tableFormat = false;
	}

	/**
		API call for User Type details 
	**/
	private async fetchRecord() {
		this.loadingFlag="Loading...";
		
		if (this.cedentEntity.isReinsurer && this.cedentEntity.isCedent) {
			this.displayedColumns = ['SlNo', 'User Group', 'User Type'];
			var seqnoPromise = this.searchRecord('UserType', 'UserType', 'REINSURER', 'CEDENT', '')
			.subscribe(
				  response => {
					this.fetchRecordData(response);
				  }, error => {
					this.fetchRecordError();	
				}
			);
		} else if (this.cedentEntity.isReinsurer) {
			this.displayedColumns = ['SlNo', 'User Type'];
			var seqnoPromise = this.searchRecord('UserType', 'UserType', 'REINSURER', '', '')
			.subscribe(
				  response => {
					this.fetchRecordData(response);
				  }, error => {
					this.fetchRecordError();	
				}
			);	
		} else if (this.cedentEntity.isCedent) {
			this.displayedColumns = ['SlNo', 'User Type'];
			var seqnoPromise = this.searchRecord('UserType', 'UserType', 'CEDENT', '', '')
			.subscribe(
				  response => {
					this.fetchRecordData(response);
				  }, error => {
					this.fetchRecordError();	
				}
			);
		}
		
	}

	/**
		Getting User Type Response from API
	**/
	fetchRecordData(response){
		var result = response;
		this.utfresult=result;
		if(result.length>0 && result !="No Data Found"){
			this._tableFormat = true;
			this.insertData();
		}else{
			this._tableFormat = false;
			this.snackBar.open(this._translate.instant("commonMessage.quoteData"), null, {duration: 3500});
		}
		this.loadingFlag="";
	}
	
	/**
		Error function from API
	**/
	fetchRecordError(){
		this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
		this.loadingFlag="";
		return;
	}
	
	
	
	/**
		Inserting User Type details into an Array 
	**/
	private insertData() {
		this.keys = [];
		for (let cnt = 0; cnt < this.utfresult.length; cnt++) {
			this.keys.push(this.utfresult[cnt]);
		}
	}
	
	/**
		Creating Object for the User type mapping
	**/
	protected createNewObject(): IUserType {
		return new Usertype("", this.cedentId);
	}
}