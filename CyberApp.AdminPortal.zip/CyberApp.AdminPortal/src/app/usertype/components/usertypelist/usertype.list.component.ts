import { Component, Injector } from '@angular/core';

import { UsertypeService } from '../../services/usertype.service';

import { Usertype, UsertypeDataSource } from '../../models';
import { IUserType } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './usertype.list.component.html',
  styleUrls: ['./usertype.list.component.scss']
})
export class UsertypeListComponent extends CedentEntityListComponent<IUserType> {

  // displayedColumns = ['id', 'CedentID', 'CedentName', 'contractNumber', 'value', 'effective', 'role', 'delete'];
  displayedColumns = [];
  dataSource: UsertypeDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("threshold.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("threshold.deleteerror");
  }

  constructor(
    injector: Injector,
    private usertypeService: UsertypeService
  ){
    super(injector, usertypeService);
  }

  protected createDataSource(): UsertypeDataSource {
    return new UsertypeDataSource(this.entityService);
  }
  
   getMessageDelete(threshold: IUserType) {
    var options = { threshold: threshold.CountryRegion };
    return this.getTranslation('threshold.reallydelete', options);
  }
}