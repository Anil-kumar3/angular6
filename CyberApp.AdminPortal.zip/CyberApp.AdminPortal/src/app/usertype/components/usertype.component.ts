import { Component } from '@angular/core';


@Component({
  selector: 'usertype',
  template: '<router-outlet></router-outlet>'
})
export class UsertypeComponent {

  constructor(  ) {}
  
  public getResponseData (param) {
		console.log("param:"+param)
	}
}