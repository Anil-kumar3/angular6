import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule,MdDatepickerModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { CommonModule } from '../common/common.module';
import { UsertypeComponent } from './components/usertype.component';
import { UsertypeDetailComponent } from './components/usertypedetail/usertype.detail.component';

import { UsertypeService } from './services/usertype.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
    MdDialogModule,
    MdIconModule,
	CommonModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdCheckboxModule,
    CdkTableModule,
	MdDatepickerModule,
    ReactiveFormsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    UsertypeComponent,
    UsertypeDetailComponent
  ], 
  providers: [
    UsertypeService
  ],
  exports: [
  ]
})
export class UsertypeModule { }