import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { UsertypeComponent } from './components/usertype.component';
import { UsertypeDetailComponent } from './components/usertypedetail/usertype.detail.component';


export var  UsertypeRoutes: Routes = [
  {
    path: 'usertype',
    component: UsertypeComponent,
    canActivateChild: [ IsCedentRoleGuard ],
	data: {roles: [RoleNames.CEDENT_ADMIN,RoleNames.CE_PLATFORMMANAGER]},
    children: [
	{
		path: '',
		component: UsertypeDetailComponent,
	}
    ]
  }
];
