import { IUser, IRole, IUserType, IUTFMap } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Usertype
  extends CedentEntity
  implements IUserType {

  public id: string;
  public Readonly: boolean;
  /*
  public Roles: Array<IRole>;
  public Identifier: string;
  public Prefix: string;
  public Password: string;
  public PasswordHash: string;
  */
  public isReinsurer: boolean;
  public isCedent: boolean;
  public CountryRegion: string;
  public UserGroup: string;
  public UserType: string;
  public SNo: number;
  public Functionalities: Array<IUTFMap>
  

  constructor(identifier: string, CedentID: string){
    super(CedentID);

    this.CountryRegion = identifier;
  }
}