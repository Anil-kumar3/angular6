import { UsertypeService } from '../services/usertype.service';

import { IUserType } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class UsertypeDataSource 
  extends CedentEntityDataSource<IUserType>{

  constructor(usertypeService: UsertypeService){
    super(usertypeService);
  }

  buildSearchString(item: IUserType): string {
    return (item.CountryRegion).toLowerCase();
  }
}