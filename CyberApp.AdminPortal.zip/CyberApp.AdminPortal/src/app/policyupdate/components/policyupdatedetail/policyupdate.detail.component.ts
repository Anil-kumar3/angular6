import { Component, OnInit, Injector, ViewChild, ElementRef, Inject } from '@angular/core';
import {FormControl} from '@angular/forms';
import { TranslateService } from '@ngx-translate/core';
import { PolicyUpdateService } from '../../services/policyupdate.service';
import { CountryService } from '../../../cedent/services';
import { PolicyUpdate, PolicyUpdateDataSource } from '../../models';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { IPolicyUpdate, ICountry, IsearchData } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { Observable, Subscription } from 'rxjs/Rx';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { AlertDialog } from '../../../common';
import { CedentAddComponent } from '../../../cedent/components/cedentadd/cedent.add.component';
import { MdDialog, MdDialogRef, MdSnackBar, ComponentType } from '@angular/material';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { getCedentId } from '../../../common/utils/cedent.utils';
import { ProfileService } from '../../../profile/services/profile.service';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';

@Component({
  selector: 'policyupdate-detail',
  templateUrl: './policyupdate.detail.component.html',
  styleUrls: ['./policyupdate.detail.component.scss']
})
export class PolicyUpdateDetailComponent extends CedentEntityDetailComponent < IPolicyUpdate > implements OnInit {

	private validationErrors: Array < string > ;
	private _policyupdate: IPolicyUpdate;
	public country: ICountry[];
	error: string;
	minDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
	maxDate = new Date(new Date().getFullYear(), new Date().getMonth() + (12 - new Date().getMonth()), 0);
	protected snackBar: MdSnackBar;
	private localStorageService = new LocalStorageService;
	private userSubscription: Subscription;
	loadingFlag : string;
	Quotenumber = [];
	Iuser: string;
	Identifier:string;
	displayedColumns = ['quotenum','reason','premium', 'policynum','covers', 'startdate', 'enddate'];
	dataSource: PolicyUpdateDataSource | null;
	_tableData=false;
	
	constructor(
		injector: Injector,
		private thresholdService: PolicyUpdateService,
		private countryService: CountryService,
		private _translate: TranslateService,
		private profileService: ProfileService
	) {
		super(injector, thresholdService);
		this.validationErrors = new Array < string > ();
		this.snackBar = injector.get(MdSnackBar);
	}

	/** Page Loading **/
	async ngOnInit() {
		// this.loadingFlag="Loading...";
		super.ngOnInit();
		
		this.Quotenumber = ["Q573942","Q573943","Q573944","Q573945","Q573946"];
		this.userSubscription = this.profileService.getAuthenticatedProfile().subscribe(user => {
			if(NullUndefined(user)!="")
			{
				this.Identifier = user.Roles[0].Name;
				console.log("this.Identifier:"+this.Identifier);
				if(user.Identifier.toLowerCase()=="superadmin")
					this.Iuser="superadmin";
				else
					this.Iuser="cedent";
			}else{
				this.Iuser="cedent";
			}
        });
		
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
	}
	
	public get isValid(): string {
		return this.cedentEntity.QuoteNum;
	}
	
	public save(): void {
		if(NullUndefined(this.cedentEntity.QuoteNum)=="")
		{
			this.error = 'selectQuote';
			return;
		}else if(NullUndefined(this.cedentEntity.PolicyNum)==""){
			this.error = 'enterPolicy';
			return;
		}else if(NullUndefined(this.cedentEntity.StartDate)==""){
			this.error = 'selectStartdate';
			return;
		}else if(NullUndefined(this.cedentEntity.EndDate)==""){
			this.error = 'selectEnddate';
			return;
		}else{
			this.error = '';
			this.loadingFlag = "";
			super.save();
		}
		
	}
	
	private resetData(): void {
		this.cedentEntity.QuoteNum = "";
		this.cedentEntity.PolicyNum = "";
		this.cedentEntity.StartDate = undefined;
		this.cedentEntity.EndDate = undefined;
		this._tableData=false;
		this.error = '';
	}
	
	private search(): void {
		this._tableData=true;
	}

	protected createNewObject(): IPolicyUpdate {
		return new PolicyUpdate("", this.cedentId);
	}
	
	protected createDataSource(): PolicyUpdateDataSource {
		return new PolicyUpdateDataSource(this._entityService);
	}

	/** API Server Validation **/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}
}