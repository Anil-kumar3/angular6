import { Component } from '@angular/core';


@Component({
  selector: 'policyupdate',
  template: '<router-outlet></router-outlet>'
})
export class PolicyUpdateComponent {

  constructor(  ) {}
}