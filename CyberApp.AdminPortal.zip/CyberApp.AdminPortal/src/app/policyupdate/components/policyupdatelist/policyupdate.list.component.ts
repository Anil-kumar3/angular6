import { Component, Injector } from '@angular/core';
import { PolicyUpdateService } from '../../services/policyupdate.service';
import { PolicyUpdate, PolicyUpdateDataSource } from '../../models';
import { IPolicyUpdate } from '../../../common/models/contracts/models.contracts';
import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './policyupdate.list.component.html',
  styleUrls: ['./policyupdate.list.component.scss']
})
export class PolicyUpdateListComponent extends CedentEntityListComponent<IPolicyUpdate> {

  displayedColumns = ['id','quotenum', 'policynum', 'startdate', 'enddate'];
  dataSource: PolicyUpdateDataSource | null;

  get messageDeleteSuccess(): string {
    return this.getTranslation("threshold.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("threshold.deleteerror");
  }

  constructor(
    injector: Injector,
    private policyService: PolicyUpdateService
  ){
    super(injector, policyService);
  }

  protected createDataSource(): PolicyUpdateDataSource {
    return new PolicyUpdateDataSource(this.entityService);
  }

  getMessageDelete(threshold: IPolicyUpdate) {
    var options = { threshold: threshold.QuoteNum};
	console.log(threshold);
    return this.getTranslation('threshold.reallydelete', options);
  }
}