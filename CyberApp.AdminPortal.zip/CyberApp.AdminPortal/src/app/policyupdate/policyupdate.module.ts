import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule,MdDatepickerModule, MdNativeDateModule, MdProgressSpinnerModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import { CommonModule } from '../common/common.module';
import { PolicyUpdateComponent } from './components/policyupdate.component';
import { PolicyUpdateListComponent } from './components/policyupdatelist/policyupdate.list.component';
import { PolicyUpdateDetailComponent } from './components/policyupdatedetail/policyupdate.detail.component';

import { PolicyUpdateService } from './services/policyupdate.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
	MdProgressSpinnerModule,
	
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdCheckboxModule,
    CdkTableModule,
	MdDatepickerModule,
	MdNativeDateModule,
    ReactiveFormsModule,
	CommonModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    PolicyUpdateComponent,
    PolicyUpdateListComponent,
    PolicyUpdateDetailComponent
  ], 
  /* entryComponents: [
    DialogOverviewExampleDialog
  ], */
  providers: [
    PolicyUpdateService
  ],
  exports: [
    PolicyUpdateListComponent
  ]
})
export class PolicyUpdateModule { }