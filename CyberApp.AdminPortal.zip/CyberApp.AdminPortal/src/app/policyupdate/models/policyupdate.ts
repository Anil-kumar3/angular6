import { IUser, IRole, IPolicyUpdate } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class PolicyUpdate
  extends CedentEntity
  implements IPolicyUpdate {

  public id: string;
  public Readonly: boolean;
  
  public QuoteNum: string;
  public PolicyNum: string;
  public StartDate: Date;
  public EndDate: Date;
  
  

  constructor(identifier: string, QuoteNum: string){
    super(QuoteNum);

    this.QuoteNum = identifier;
  }
}