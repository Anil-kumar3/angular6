import { PolicyUpdateService } from '../services/policyupdate.service';

import { IPolicyUpdate } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class PolicyUpdateDataSource 
  extends CedentEntityDataSource<IPolicyUpdate>{

  constructor(policyService: PolicyUpdateService){
    super(policyService);
  }

  buildSearchString(item: IPolicyUpdate): string {
    return (item.QuoteNum).toLowerCase();
  }
}