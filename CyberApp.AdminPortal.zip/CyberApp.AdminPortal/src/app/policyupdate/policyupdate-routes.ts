import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { PolicyUpdateComponent } from './components/policyupdate.component';
import { PolicyUpdateListComponent } from './components/policyupdatelist/policyupdate.list.component';
import { PolicyUpdateDetailComponent } from './components/policyupdatedetail/policyupdate.detail.component';


export var  PolicyUpdateRoutes: Routes = [
  {
    path: 'policyupdate',
    component: PolicyUpdateComponent,
    canActivateChild: [ IsCedentRoleGuard ],
	data: {roles: [RoleNames.CEDENT_ADMIN,RoleNames.CE_PLATFORMMANAGER]},
    children: [
      {
        path: '',
        component: PolicyUpdateListComponent,
      },
      {
        path: ':id',
        component: PolicyUpdateDetailComponent,
      },
      {
        path: 'create',
        component: PolicyUpdateDetailComponent,
      }
    ]
  }
];
