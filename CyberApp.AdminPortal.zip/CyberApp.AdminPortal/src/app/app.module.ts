﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';

import { DomSanitizer } from '@angular/platform-browser';
import { MdIconRegistry } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';

import { TranslateModule, TranslateLoader, TranslateService } from "@ngx-translate/core";
import {TranslateHttpLoader} from "@ngx-translate/http-loader";

import { environment } from '../environments/environment';

import { SuperAdminModule } from './superadmin/superadmin.module';
import { CedentModule } from './cedent/cedent.module';
import { UsersModule } from './users/users.module';
import { PolicyHolderModule } from './policyholder/policyholder.module';
import { QuestionnaireModule } from './questionnaire/questionnaire.module';
import { ConfigurationModule } from './configuration/configuration.module';
import { MessagesModule } from './messages/messages.module';
import { ParametersettingModule } from './parametersetting/parametersetting.module';
import { TipsModule } from './tips/tips.module';
import { FirstAidModule } from './firstaid/firstaid.module';
import { CedentCreationModule } from './cedentcreation/cedentcreation.module';
import { CedentUserCreationModule } from './cedentusercreation/cedentusercreation.module';
import { PaymentScreenModule } from './paymentScreen/paymentScreen.module';
import { StatusScreenModule } from './statusScreen/statusScreen.module';


import { QuotedashboardModule } from './quotedashboard/quotedashboard.module';
import { ThresholdsettingModule } from './thresholdsetting/thresholdsetting.module';
import { PolicyUpdateModule } from './policyupdate/policyupdate.module';
import { TemplateUploadModule } from './templateupload/templateupload.module';
import { TemplateApprovalModule } from './templateapproval/templateapproval.module';
import { UsertypefunctionalityMappingModule } from './usertypefunctionalitymapping/usertypefunctionalitymapping.module';
import { UsertypeModule } from './usertype/usertype.module';

import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { MdGridListModule, MdCardModule, MdToolbarModule, MdSidenavModule, MdButtonModule, MdListModule, MdIconModule, MdDialogModule, MdInputModule, MdMenuModule, MdSelectModule, MdTableModule } from '@angular/material';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
//import { StatusScreenComponent } from './statusScreen/statusScreen.component';
// import { PaymentScreenComponent } from './paymentScreen/paymentScreen.component';

import { LoggedInGuard } from './common/services/loggedin.guard';
import { IsCedentRoleGuard } from './common/services/is-cedent-role.guard';
import { IoniconDataService } from './common/services/ionicon.provider';
import { PagerService } from './common/services/pager.service';
import { MarkdownParserService } from './common/services/markdown-parser.service';

import { ProfileService } from './profile/services/profile.service';
import { ProfileHttpService } from './profile/services/profile.http.service';

import { LocalStorageService } from './localstorage/services/localstorage.service';
import { Globals } from './global';


// AoT requires an exported function for factories
export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, environment.assetsRoot + "assets/i18n/", ".json");
}

@NgModule({
  imports: [	
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    MdGridListModule,
    MdCardModule,
    MdIconModule,
    MdToolbarModule,
    MdSidenavModule,
    MdButtonModule,
    MdListModule,
    MdMenuModule,
    MdSelectModule,
    MdInputModule,
    FlexLayoutModule,
    SuperAdminModule,
    CedentModule,
    PolicyHolderModule,
    QuestionnaireModule,
    ReactiveFormsModule,
    UsersModule,
    MessagesModule,
    ParametersettingModule,
    TipsModule,
    FirstAidModule,
	CedentCreationModule,
	CedentUserCreationModule,
	PaymentScreenModule,
	StatusScreenModule,
    QuotedashboardModule,
	ThresholdsettingModule,
	PolicyUpdateModule,
	TemplateUploadModule,
	TemplateApprovalModule,
	UsertypefunctionalityMappingModule,
	UsertypeModule,
    ConfigurationModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [	
    AppComponent,
    LoginComponent
  ],
  entryComponents: [
    LoginComponent
  ],
  providers: [
    LoggedInGuard,
    IsCedentRoleGuard,
    ProfileService,
    ProfileHttpService,
    IoniconDataService,
    PagerService,
    MarkdownParserService,
    LocalStorageService,
	Globals
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(mdIconRegistry: MdIconRegistry,
              sanitizer: DomSanitizer,
              ioniconDataService: IoniconDataService) {

    ioniconDataService.getIonicons().subscribe((values) => {
      values.forEach((value) => {
        mdIconRegistry.addSvgIcon(value.Name, sanitizer.bypassSecurityTrustResourceUrl(environment.assetsRoot + `assets/ionicons/ios-${value.Name}.svg`));
      });
    });
  }
}
