import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { TemplateUploadComponent } from './components/templateupload.component';
import { TemplateUploadListComponent } from './components/templateuploadlist/templateupload.list.component';
import { TemplateUploadDetailComponent } from './components/templateuploaddetail/templateupload.detail.component';


export var  TemplateUploadRoutes: Routes = [
  {
    path: 'templateupload',
    component: TemplateUploadComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    children: [
      {
        path: '',
        // component: TemplateUploadDetailComponent,
        component: TemplateUploadListComponent,
      },
      {
        path: ':id',
        component: TemplateUploadDetailComponent,
      },
      {
        path: 'create',
        component: TemplateUploadDetailComponent,
      }
    ]
  }
];
