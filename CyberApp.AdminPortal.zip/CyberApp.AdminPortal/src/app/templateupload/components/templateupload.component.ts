import { Component } from '@angular/core';


@Component({
  selector: 'templateupload',
  template: '<router-outlet></router-outlet>'
})
export class TemplateUploadComponent {

  constructor(  ) {}
}