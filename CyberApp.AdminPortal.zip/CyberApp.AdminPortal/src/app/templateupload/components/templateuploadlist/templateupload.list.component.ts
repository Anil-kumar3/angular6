import { Component, Injector } from '@angular/core';

import { TemplateUploadService } from '../../services/templateupload.service';

import { TemplateUpload, TemplateUploadDataSource } from '../../models';
import { ITemplate } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './templateupload.list.component.html',
  styleUrls: ['./templateupload.list.component.scss']
})
export class TemplateUploadListComponent extends CedentEntityListComponent<ITemplate> {

  // displayedColumns = ['id','cedentID', 'cedentName', 'templateType','effectiveDate','reason','status','delete'];
  displayedColumns = ['id','cedentID', 'cedentName', 'templateType','effectiveDate','reason','status'];
  
  dataSource: TemplateUploadDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("template.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("template.deleteerror");
  }

  constructor(
    injector: Injector,
    private userService: TemplateUploadService
  ){
    super(injector, userService);
  }

  protected createDataSource(): TemplateUploadDataSource {
    return new TemplateUploadDataSource(this.entityService);
  }

  getMessageDelete(template: ITemplate) {
    var options = { template: template.TemplateCedentId};
    return this.getTranslation('template.reallydelete', options);
  }
}