import { Component, OnInit, Injector, ViewChild, ElementRef } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TemplateUploadService } from '../../services/templateupload.service';
import { CountryService } from '../../../cedent/services';
import { TemplateUpload } from '../../models/templateupload';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { ICountry, IsearchData, ITemplate, IPricingTemplate } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { environment } from '../../../../environments/environment';
import { Observable, Subscription } from 'rxjs/Rx';
import { getCedentId } from '../../../common/utils/cedent.utils';
import { ConvertEffectiveDate } from '../../../common/utils/date.utils';
import { HttpService, HttpServiceFactory } from '../../../common/services/http.service';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { MdSnackBar } from '@angular/material';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';


@Component({
  selector: 'templateupload-detail',
  templateUrl: './templateupload.detail.component.html',
  styleUrls: ['./templateupload.detail.component.scss']
})
export class TemplateUploadDetailComponent extends CedentEntityDetailComponent < ITemplate > implements OnInit {

	private validationErrors: Array < string > ;
	public country: ICountry[];
	public countrySelected: ICountry;
	public cedentID: IsearchData[];
	public cedentID1: IsearchData[];
	private _template: ITemplate;
	protected snackBar: MdSnackBar;
	public templateDocx: IPricingTemplate[];
	error: string;
	countrycode: string;
	countryChoosen: string;
	search: string;
	private fileStatus = false;
	Status = ["Approval", "Reject"];
	//TemplateType = ["Onboarding", "Risk management", "Claims"];
    TemplateType = ["Onboarding"];
	public templatefileList: FileList;
	public wordingfileList: FileList;
	filestring: string;
	//minDate = new Date(new Date().getTime() + (24 * 60 * 60 * 1000));
	minDate = new Date(new Date().getTime());
	loadingFlag : string;
	protected _entityHttpService: HttpService<any>;
	constructor(
		injector: Injector,
		private cedentcreationService: TemplateUploadService,
		private countryService: CountryService,
		httpServiceFactory: HttpServiceFactory,
		private _translate: TranslateService,
		private localStorageService: LocalStorageService
	) {
		super(injector, cedentcreationService);
		this.validationErrors = new Array < string > ();
		this.snackBar = injector.get(MdSnackBar);
		this._entityHttpService = httpServiceFactory.getInstance<any>(this.filestring)
	}

	/** 
		Function Calling on page load
	**/
	async ngOnInit() {
		this.loadingFlag="Loading...";
		super.ngOnInit();
		/*var promises = [];
		var countryPromise = this.searchRecord('Country','Country',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			this.loadingFlag="";
			return;
		});
		promises.push(countryPromise);
		if (this.isExistEntity) {
			var userPromise = this.entityLoaded.first().toPromise();
			promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		this.country = result[0]; */
		
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		this.fetchTemplate();
		
		var cedentId = getCedentId();
		if (cedentId){
			this.cedentEntity.Cedentid = cedentId;
		} else{
			this.cedentEntity.Cedentid=this.localStorageService.get("superAdminID");
		}
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
		this.loadingFlag="";
	}
	
	/** 
		Field value need to clear On change of Template Document 
	**/
	public onSelectDocx(): void {
		console.log("dsdsad");
		this.cedentEntity.Country="";
		this.cedentEntity.CountryCode="";
		this.cedentEntity.TemplateCedentId="";
		this.cedentEntity.CedentName="";
	}
	
	/** 
		Calling Webservice for getting pricing template list.
	**/
	private async fetchTemplate() {
		/*var pricingpromises = [];
		//var pricingTemplatePromise = this.pricingtemplateService.getEntities().first().toPromise()
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect pricing template web service", null, {duration: 3500})
			return;
		});
		pricingpromises.push(pricingTemplatePromise);
		if(this.isExistEntity) {
		  var templatePromise = this.entityLoaded.first().toPromise();
		  pricingpromises.push(templatePromise);
		}
		var result1 = await Promise.all(pricingpromises);
		this.pricingTemplate = result1[0];*/
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.templateDocx = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchTemplate"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }

	/**
		Function called whenever country drop down is changed.
		It internally calls fetch record for cedent id created for the country selected.
	**/
	public changeCountry(): void {
		this.loadingFlag="Loading...";
		if (this.countryChoosen != "" && this.countryChoosen != this.cedentEntity.Country) {
			for (let cnt = 0; cnt < this.country.length; cnt++) {
				if (this.cedentEntity.Country == this.country[cnt].CountryName) {
					this.countrycode = this.country[cnt].CountryCode;
					this.cedentEntity.CountryCode = this.countrycode;
					break;
				}
			}
			this.cedentEntity.CedentName = "";
			this.fetchRecord(this.cedentEntity.Country, this.cedentEntity.CountryCode);
			this.countryChoosen = this.cedentEntity.Country;
		}
	}

	/**
		Calling webservice for getting CedentID & CedentName as per Country selected
	**/
	private async fetchRecord(UserCountry, countrycode) {
		this.loadingFlag="Loading...";
		var promises = [];
		var rootcedentId = getCedentId();
		if (NullUndefined(rootcedentId) == "")
        { 
			rootcedentId = this.localStorageService.get("superAdminID"); 
		}
		/*var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(UserCountry), NullUndefined(countrycode), NullUndefined(rootcedentId)).toPromise();
		promises.push(seqnoPromise);
		if (this.isExistEntity) {
			var userPromise = this.entityLoaded.first().toPromise();
			promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		if(result[0].length>0){
			this.cedentID = result[0];
			this.cedentID1 = this.cedentID;
		}else{
			this.cedentID=[];
			this.cedentEntity.TemplateCedentId="";
		}
		this.loadingFlag="";*/
		
		var seqnoPromise = this.searchRecord('CedentIDList', 'CedentCreation', NullUndefined(UserCountry), NullUndefined(countrycode), NullUndefined(rootcedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.cedentID = result;
                    this.cedentID1 = this.cedentID;
                    this.snackBar.dismiss();
				}else{
					this.cedentID=[];
					this.cedentEntity.TemplateCedentId="";
					this.snackBar.open(this._translate.instant("commonMessage.cedentDetails"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}

	/**
		Fetching Cedent Name as per CedentID Selected
	**/
	public changetemplatecedentID() {
		for (let cnt = 0; cnt < this.cedentID.length; cnt++) {
			if (this.cedentEntity.TemplateCedentId == this.cedentID[cnt].CedentLoginID) {
				this.cedentEntity.CedentName = this.cedentID[cnt].CedentName;
				this.cedentEntity.TemplateCedentId = this.cedentID[cnt].CedentLoginID;
				break;
			}
		}
	}

	/** 
		Search CedentId w.r.t Cedent Name
	**/
	public filterListCareUnit(val) {
		this.cedentID = this.cedentID1;
		this.cedentID = this.cedentID.filter((unit) => unit.CedentName.indexOf(val) > -1);
	}

	/** 
		Clear Cedent Search Field 
	**/
	public clearSearch() {
		this.search = ""
		this.cedentID = this.cedentID1;
	}

	/**
		Calling for Field validations and upload data into server.
	**/
	public save(): void {
		/*var fileExtension = ""
		if (NullUndefined(this.cedentEntity.FileUpload) != '') {
			fileExtension = this.cedentEntity.FileUpload.split('.').pop();
		}*/
		if (NullUndefined(this.cedentEntity.TemplateDocument) == '') {
			this.error = 'selectTemlateDocument';
			return;
		} else if ((this.cedentEntity.TemplateDocument == "Cedent Template") && NullUndefined(this.cedentEntity.Country) == '') {
			this.error = 'selectCountry';
			return;
		} else if ((this.cedentEntity.TemplateDocument == "Cedent Template") && NullUndefined(this.cedentEntity.TemplateCedentId) == '') {
			this.error = 'selectTemplateCedentID';
			return;
		} /*else if (NullUndefined(this.cedentEntity.TemplateType) == '') {
			this.error = 'selectTemplateType';
			return;
		}*/ else if (NullUndefined(this.cedentEntity.EffectiveDate) == '') {
			this.error = 'selectEffectiveDate';
			return;
		} else if (NullUndefined(this.cedentEntity.FileUpload) == '') {
			this.error = 'chooseFile';
			return;
		} else if (NullUndefined(this.cedentEntity.FileUpload.split('.').pop()) != 'xls' && NullUndefined(this.cedentEntity.FileUpload.split('.').pop()) != 'xlsx') {
			this.error = 'validTemplateFile';
			return;
		}else if (NullUndefined(this.cedentEntity.WordingFileUpload) == '') {
			this.error = 'chooseWordingFile';
			return;
		} else if (NullUndefined(this.cedentEntity.WordingFileUpload.split('.').pop()) != 'xls' && NullUndefined(this.cedentEntity.WordingFileUpload.split('.').pop()) != 'xlsx') {
			this.error = 'validWordingFile';
			return;
		} else {
			this.loadingFlag="save details";
			this.error = '';
			if (NullUndefined(this.templatefileList) != "" && this.templatefileList.length > 0) {
				const templatefile = this.templatefileList[0];
				const template_file_name = templatefile.name;
				const wordingfile = this.wordingfileList[0];
				const wording_file_name = wordingfile.name;
				this.upload(templatefile, template_file_name, wordingfile, wording_file_name);
			} else {
				this.upload("", "", "", "");
			}
		}
	}
	
	
	/** API call for Upload File & Data **/
	public upload(templatefile, template_file_name, wordingfile, wording_file_name): void {
		this.loadingFlag="Loading...";
		var covEffDate = ConvertEffectiveDate(NullUndefined(this.cedentEntity.EffectiveDate));
		const formData = new FormData();
		formData.append("cedentid", NullUndefined(this.cedentEntity.Cedentid));
		formData.append("TemplateDocument", NullUndefined(this.cedentEntity.TemplateDocument));
		formData.append("Country", NullUndefined(this.cedentEntity.Country));
		formData.append("CountryCode", NullUndefined(this.cedentEntity.CountryCode));
		formData.append("TemplateCedentId", NullUndefined(this.cedentEntity.TemplateCedentId));
		formData.append("CedentName", NullUndefined(this.cedentEntity.CedentName));
		formData.append("TemplateType", NullUndefined(this.cedentEntity.TemplateType));
		formData.append("EffectiveDate", NullUndefined(covEffDate));
		formData.append('file', templatefile, template_file_name);
		formData.append('file', wordingfile, wording_file_name);
		this._entityHttpService.uploadFile(formData,"TemplateUpload").then(() => {
			this.loadingFlag="";
			super.goBack();
		}, (error) => {
			this.loadingFlag="";	
			this.onError(error);
		});
	}

	private addToItems(item) {
		if (!item) {
			return;
		}
	}

	/** Clear the Data **/
	public resetData(): void {
		this.cedentEntity.TemplateDocument = "";
		this.cedentEntity.Country = "";
		this.cedentEntity.TemplateCedentId = "";
		this.cedentEntity.CedentName = "";
		this.cedentEntity.TemplateType = "";
		this.cedentEntity.EffectiveDate = undefined;
		this.cedentEntity.FileUpload = "";
		this.error = '';
	}

	/** Onchange of File **/
	public fileChange(event,FileNo): void {
		this.fileStatus = true;
		if(FileNo==0){
			this.templatefileList = event.target.files;
		}else{
			this.wordingfileList = event.target.files;
		}
	}

	/**
		Creating Object for Template Upload
	**/
	protected createNewObject(): ITemplate {
		return new TemplateUpload("", this.cedentId);
	}

	/**
		Web service Error validation
	**/
	protected onError(error: any): void {
		console.log("Error:" + error.Message);
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}
}