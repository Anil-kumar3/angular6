import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';
import { MdButtonModule, MdCardModule, MdDialogModule, MdIconModule, MdInputModule, MdTableModule, MdSelectModule, MdCheckboxModule, MdDatepickerModule, MdNativeDateModule } from '@angular/material';
import { CdkTableModule } from '@angular/cdk/table';

import { CommonModule } from '../common/common.module';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { TemplateUploadComponent } from './components/templateupload.component';
import { TemplateUploadListComponent } from './components/templateuploadlist/templateupload.list.component';
import { TemplateUploadDetailComponent } from './components/templateuploaddetail/templateupload.detail.component';

import { TemplateUploadService } from './services/templateupload.service';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    BrowserModule,
    RouterModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule, 
    MdDialogModule,
    MdIconModule,
    MdInputModule,
    MdTableModule,
    MdSelectModule,
    MdCheckboxModule,
    CdkTableModule,
    ReactiveFormsModule,
	MdDatepickerModule,
	CommonModule,
	MdNativeDateModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    TemplateUploadComponent,
    TemplateUploadListComponent,
    TemplateUploadDetailComponent
  ], 
  providers: [
    TemplateUploadService
  ],
  exports: [
    TemplateUploadListComponent
  ]
})
export class TemplateUploadModule { }