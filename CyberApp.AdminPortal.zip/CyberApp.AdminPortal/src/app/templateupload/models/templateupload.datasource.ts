import { TemplateUploadService } from '../services/templateupload.service';

import { ITemplate } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class TemplateUploadDataSource 
  extends CedentEntityDataSource<ITemplate>{

  constructor(userService: TemplateUploadService){
    super(userService);
  }

  buildSearchString(item: ITemplate): string {
    return (item.TemplateCedentId).toLowerCase();
  }
}