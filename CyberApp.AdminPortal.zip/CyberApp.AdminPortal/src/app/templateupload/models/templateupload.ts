import { ITemplate, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class TemplateUpload
  extends CedentEntity
  implements ITemplate {
	public id: string;
	public Readonly: boolean;
	public Country: string;
	public CountryCode: string;
	public TemplateCedentId: string;
	public CedentName: string;
	public TemplateType:string;
	public EffectiveDate: Date;
	public Status:string;
	public TemplateDocument: string;
	public FileUpload:string;
	public Filename:string;
	public WordingFileUpload:string;
	public RejectReason:string;
	public Cedentid:string;

  constructor(UserLoginID: string, cedentId: string){
    super(cedentId);

    this.CedentName = UserLoginID;
  }
}