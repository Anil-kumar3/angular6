import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { CedentUserCreationComponent } from './components/cedentusercreation.component';
import { CedentUserCreationListComponent } from './components/cedentusercreationlist/cedentusercreation.list.component';
import { CedentUserCreationDetailComponent } from './components/cedentusercreationdetail/cedentusercreation.detail.component';


export var  cedentUserCreationRoutes: Routes = [
  {
    path: 'cedentusercreation',
    component: CedentUserCreationComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    children: [
      {
        path: '',
        component: CedentUserCreationListComponent,
      },
      {
        path: ':id',
        component: CedentUserCreationDetailComponent,
      },
      {
        path: 'create',
        component: CedentUserCreationDetailComponent,
      }
    ]
  }
];
