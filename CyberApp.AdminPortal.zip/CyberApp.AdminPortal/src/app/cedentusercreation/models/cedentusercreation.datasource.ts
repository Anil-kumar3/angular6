import { CedentUserCreationService } from '../services/cedentusercreation.service';

import { ICedentUserCreation } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class CedentUserCreationDataSource 
  extends CedentEntityDataSource<ICedentUserCreation>{

  constructor(userService: CedentUserCreationService){
    super(userService);
  }

  buildSearchString(item: ICedentUserCreation): string {
    return (item.UserLoginID).toLowerCase();
  }
}