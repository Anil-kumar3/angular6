import { ICedentUserCreation, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class CedentUserCreation
  extends CedentEntity
  implements ICedentUserCreation {

	public Roles: Array<IRole>;
    public UserCountry: string;
    public UserCountryCode: string;
    public UserCedentID: string;
    public UserCedentName: string;
    public UserName: string;
    public UserLoginID: string;
    public UserType: string;
    public UserStatus: string;
    public UserEmailID: string;
    public UserMobileNo: string;
	public Password: string;

  constructor(UserLoginID: string, cedentId: string){
    super(cedentId);

    this.CedentId = cedentId;
  }
}