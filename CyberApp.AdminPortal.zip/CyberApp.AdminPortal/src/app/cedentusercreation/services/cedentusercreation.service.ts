import { Injectable } from '@angular/core';

import { ICedentUserCreation } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class CedentUserCreationService
  extends BaseCedentEntityService<ICedentUserCreation> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'cedentuser');
  }
}