import { Component } from '@angular/core';


@Component({
  selector: 'cedentusercreations',
  template: '<router-outlet></router-outlet>'
})
export class CedentUserCreationComponent {

  constructor(  ) {}
}