import { Component, OnInit, Injector, ViewChild, ElementRef } from '@angular/core';
import {MdSnackBar} from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { CedentUserCreationService } from '../../services/cedentusercreation.service';
import { CountryService } from '../../../cedent/services';
import { CedentUserCreation } from '../../models/cedentusercreation';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { ICedentUserCreation, ICountry, IPricingTemplate, IsearchData, activestatus, IRole } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { ConfigurationService } from '../../../configuration/services/configuration.service';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { EmailValidate } from "../../../common/utils/emailvalidation.utils";
import { Observable, Subscription } from 'rxjs/Rx';
import { getCedentId } from '../../../common/utils/cedent.utils';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';


@Component({
	selector: 'cedentusercreation-detail',
	templateUrl: './cedentusercreation.detail.component.html',
	styleUrls: ['./cedentusercreation.detail.component.scss']
})


export class CedentUserCreationDetailComponent extends CedentEntityDetailComponent<ICedentUserCreation> implements OnInit{
	private validationErrors: Array<string>;
	public country: ICountry[];
	public countrySelected: ICountry;
	public pricingTemplate: IPricingTemplate[];
	public pricingTempSelect: IPricingTemplate;
	public cedentID: IsearchData[];
	public roles: IRole[];
	public roleSelected: IRole;
	private _message: ICedentUserCreation;
	protected snackBar: MdSnackBar;
	private localStorageService = new LocalStorageService;
	public userstatus ;
	loadingFlag: string;
	error: string;
	countrycode : string;
	countryChoosen : string;


	/*
		Calling the cedent ID list and User type from web service to get the list once we come from edit case.
	*/
	public set cedentEntity(entity: ICedentUserCreation) {
		entity.UserCedentID = entity.UserCedentID;
		if(NullUndefined(entity.UserCountry)!=""){
			var rootcedentId = getCedentId();
			this.fetchRecord("CedentIDList","CedentCreation",entity.UserCountry,entity.UserCountryCode,rootcedentId);
		}
		if(NullUndefined(entity.Roles) != ""){
			this.fetchUserType(NullUndefined(entity.Roles));
		}
		this._message = entity;
	}


	public get cedentEntity() {
		return this._message;
	}


	constructor(
		injector: Injector,
		private cedentcreationService: CedentUserCreationService,
		private countryService: CountryService,
		private configurationService: ConfigurationService,
		private _translate: TranslateService
	) { 
		super(injector, cedentcreationService);
		this.validationErrors = new Array<string>();    
		this.snackBar = injector.get(MdSnackBar);
	}


	async ngOnInit() {
		this.loadingFlag = "loading...";
		super.ngOnInit();
        /*var promises = [];
		//var countryPromise = this.countryService.getEntities().first().toPromise();
		var countryPromise = this.searchRecord('Country','Country',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			this.loadingFlag = "";
			return;
		});
		promises.push(countryPromise);
		if(this.isExistEntity) {
		  var userPromise = this.entityLoaded.first().toPromise();
		  promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		this.country = result[0];*/
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
				}else{
					this.country=[];
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
		this.fetchUserType("");
		/*var usertypepromises = [];
		var pricingTemplatePromise = this.searchRecord('UserType','CEDENTROLEDDL',"CEDENT","REINSURER","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			return;
		});
		usertypepromises.push(pricingTemplatePromise);
		if(this.isExistEntity) {
		  var templatePromise = this.entityLoaded.first().toPromise();
		  usertypepromises.push(templatePromise);
		}
		var result = await Promise.all(usertypepromises);
		this.roles = result[0];
		
		if(this.isExistEntity){
			var user = result[1];
			if(user && user.Roles && user.Roles.length > 0){
				let userRole = user.Roles[0];
				this.roleSelected =  this.roles.find(r => r.id === userRole.id);
			}
		}*/
		this.userstatus = activestatus;
		this.loadingFlag = "";
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
	}


	/*
		Fetch the usert type list.
	*/
	private async fetchUserType(roleSelected) {
		this.loadingFlag="Loading...";
        /*var usertypepromises = [];
		var pricingTemplatePromise = this.searchRecord('UserType','CEDENTROLEDDL',"CEDENT","REINSURER","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			return;
		});
		usertypepromises.push(pricingTemplatePromise);
		if(this.isExistEntity) {
		  var templatePromise = this.entityLoaded.first().toPromise();
		  usertypepromises.push(templatePromise);
		}
		var result = await Promise.all(usertypepromises);
		this.roles = result[0];
		
		if(this.isExistEntity){
			var user = result[1];
			if(user && user.Roles && user.Roles.length > 0){
				let userRole = user.Roles[0];
				this.roleSelected =  this.roles.find(r => r.id === userRole.id);
			}
		}*/
		
		var pricingTemplatePromise =this.searchRecord('UserType','CEDENTROLEDDL',"CEDENT","REINSURER","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.roles = result;
					//var user = result;
					console.log("roleSelected:"+roleSelected);
					if(roleSelected && roleSelected[0].Name && roleSelected.length > 0){
						let userRole = roleSelected[0];
						this.roleSelected =  this.roles.find(r => r.id === userRole.id);
					}
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchUserType"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }


	/*
		To clear all the selected value when click on reset button. 
	*/
	public resetData() : void {
		this.cedentEntity.UserCountry = undefined;
		this.cedentEntity.UserCedentID = undefined;
		this.cedentEntity.UserCedentName = "";
		this.cedentEntity.UserName = "";
		this.cedentEntity.UserLoginID = "";
		this.roleSelected=undefined;
		this.cedentEntity.UserStatus = undefined;
		this.cedentEntity.UserEmailID = "";
		this.cedentEntity.UserMobileNo = "";
		this.error = '';
	}
	
	/*public filterListCareUnit(val){
		this.cedentID=this.cedentID;
		this.cedentID=this.cedentID.filter((unit) => unit.CedentName.indexOf(val) > -1);
	}*/


	/*
		Function called whenever country drop down is changed.
		It internally calls fetch record for cedent id created for the country selected.
	*/
	public changeCountry(){
		if(this.countryChoosen!="" && this.countryChoosen != this.cedentEntity.UserCountry)
		{
			this.loadingFlag="Loading...";	
			for(let cnt=0;cnt<this.country.length;cnt++){
				if(this.cedentEntity.UserCountry == this.country[cnt].CountryName){
					this.countrycode=this.country[cnt].CountryCode;
					this.cedentEntity.UserCountryCode=this.countrycode;
					break;
				}
			}
			this.cedentEntity.UserCedentName="";
			var rootcedentId = getCedentId();
			this.fetchRecord("CedentIDList","CedentCreation",this.cedentEntity.UserCountry,this.cedentEntity.UserCountryCode,rootcedentId);
			this.countryChoosen = this.cedentEntity.UserCountry;
		}
	}


	/*
		Function fetch the details of parameter passed.
		webPage : Controller to be called.
		webmethod : Method name to be passed if any for any validation if required(For future use).
		webParam1 : Parameter1 on which search should happen.
		webParam2 : Parameter2 on which search should happen .
		cedentId : Cedent ID on which filter should happen.
	*/
	private async fetchRecord(webPage,webmethod,webParam1,webParam2,cedentId){
		this.loadingFlag="Loading...";
		var promises = [];
		if (NullUndefined(cedentId) == "")
		{ 
			cedentId = this.localStorageService.get("superAdminID"); 
		}
		/*var seqnoPromise = this.searchRecord(NullUndefined(webPage),NullUndefined(webmethod),NullUndefined(webParam1),NullUndefined(webParam2),NullUndefined(cedentId)).toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			return;
		});
		promises.push(seqnoPromise);
		if(this.isExistEntity) {
		  var userPromise = this.entityLoaded.first().toPromise();
		  promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		if(result[0].length>0){
			this.cedentID = result[0];
		}else{
			this.cedentID=[];
			this.cedentEntity.UserCedentID="";
			this.cedentEntity.UserName="";
		}*/
		
		var seqnoPromise =this.searchRecord(NullUndefined(webPage),NullUndefined(webmethod),NullUndefined(webParam1),NullUndefined(webParam2),NullUndefined(cedentId))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.cedentID = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.cedentDetails"), null, {duration: 3500})
					this.cedentID=[];
					this.cedentEntity.UserCedentID="";
					this.cedentEntity.UserName="";
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}


	/*
		To fetch cedent name whenever cedent Id is changed from drop down.
	*/
	public changeCedentID(){
		for(let cnt=0;cnt<this.cedentID.length;cnt++){
			if(this.cedentEntity.UserCedentID == this.cedentID[cnt].CedentLoginID){
				this.cedentEntity.UserCedentName=this.cedentID[cnt].CedentName;
				this.cedentEntity.UserCedentID=this.cedentID[cnt].CedentLoginID;
				break;
			}
		}
	}


	/*
		Function called on save button click.
		Basic validation before insert/update.
	*/
	public save(): void {
		/*if(!this.checkRoles()){
		  return;
		}
		super.save();*/
		if (NullUndefined(this.cedentEntity.UserCountry) == ''){
			this.error = 'selectCountry';
			return;
		}else if(NullUndefined(this.cedentEntity.UserCedentID) == ''){
			this.error = 'selectCedentID';
			return;
		}else if(NullUndefined(this.cedentEntity.UserName) == ''){
			this.error = 'enterUserName';
			return;
		}else if(NullUndefined(this.cedentEntity.UserLoginID) == ''){
			this.error = 'enterUserID';
			return;		
		}else if(NullUndefined(this.cedentEntity.UserLoginID).length < 6){
			this.error = 'validUserID';
			return;		
		}else if(!this.checkRoles()){
		  return;
		}else if(NullUndefined(this.cedentEntity.UserStatus) == ''){
			this.error = 'selectStatus';
			return;
		}else if(NullUndefined(this.cedentEntity.UserEmailID) == ''){
			this.error = 'enterEmailID';
			return;
		} else if(EmailValidate(NullUndefined(this.cedentEntity.UserEmailID)) == false){
			this.error = 'enterValidEmailID';
			return;
		} else if(NullUndefined(this.cedentEntity.UserMobileNo) == ''){
			this.error = 'enterMobileNo';
			return;
		} else if(NullUndefined(this.cedentEntity.UserMobileNo).length < 4){
			this.error = 'validMobileNo';
			return;
		} else{
			this.cedentEntity.Password="Test123!";
			this.error = '';
			this.loadingFlag = "Saving data...";
			super.save();
		}
	}


	/*
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	*/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "MobileNo"){
			return keyPressvalidUtils.mobileValidation(evt,NullUndefined(FieldValue));
		}else if (FieldName == "UserName"){
			return keyPressvalidUtils.onlyAlphaDotApo(evt,NullUndefined(FieldValue));
		}else if(FieldName == "UserID"){
			return keyPressvalidUtils.alphaNumeric(evt,NullUndefined(FieldValue));
		}else if(FieldName == "EmailID"){
			return keyPressvalidUtils.emailFormat(evt,NullUndefined(FieldValue));
		}
	}


	/*
		To pass the role array while saving/updating the details.
	*/
	private checkRoles() : boolean{
		if(!this.roleSelected){
		  this.error = 'selectUsertype';
		  return false;
		}
		if(!this.cedentEntity.Roles){
		  this.cedentEntity.Roles = [];
		}
		if(this.cedentEntity.Roles.length > 1){
		  this.cedentEntity.Roles.length = 0;
		}
		this.cedentEntity.Roles[0] = this.roleSelected;
		return true;
	}


	protected createNewObject(): ICedentUserCreation{
		return new CedentUserCreation("", this.cedentId);
	}


	/*
		To catch and display error if any in web service.
	*/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}
}
