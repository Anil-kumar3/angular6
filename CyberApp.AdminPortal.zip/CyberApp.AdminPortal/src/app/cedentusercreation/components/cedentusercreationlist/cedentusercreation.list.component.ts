import { Component, Injector } from '@angular/core';

import { CedentUserCreationService } from '../../services/cedentusercreation.service';

import { CedentUserCreation, CedentUserCreationDataSource } from '../../models';
import { ICedentUserCreation } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './cedentusercreation.list.component.html',
  styleUrls: ['./cedentusercreation.list.component.scss']
})
export class CedentUserCreationListComponent extends CedentEntityListComponent<ICedentUserCreation> {

  //displayedColumns = ['id', 'country', 'cedentid', 'cedentname', 'pricingtemplate', 'delete'];
  displayedColumns = ['id','cedentID', 'cedentname', 'Username','UserID','UserType','Status','EmailID','MobileNo','delete'];
  dataSource: CedentUserCreationDataSource | null;


  get messageDeleteSuccess(): string {
    return this.getTranslation("user.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("user.deleteerror");
  }

  constructor(
    injector: Injector,
    private userService: CedentUserCreationService
  ){
    super(injector, userService);
  }

  protected createDataSource(): CedentUserCreationDataSource {
    return new CedentUserCreationDataSource(this.entityService);
  }

  getMessageDelete(user: ICedentUserCreation) {
    var options = { user: user.UserLoginID};
    return this.getTranslation('user.reallydelete', options);
  }
}