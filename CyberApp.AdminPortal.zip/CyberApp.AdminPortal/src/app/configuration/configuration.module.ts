import { NgModule } from '@angular/core';

import { ConfigurationService } from './services/configuration.service';

@NgModule({
    imports: [],
    declarations: [],
    providers: [ ConfigurationService ],
    exports: []
})
export class ConfigurationModule {}