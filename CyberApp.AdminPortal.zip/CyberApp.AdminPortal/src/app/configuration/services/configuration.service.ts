import { Injectable } from '@angular/core';

import { environment } from '../../../environments/environment'

@Injectable() 
export class ConfigurationService {

  constructor() {
      
  }

  public getDefaultLanguage(): string {
    return environment.defaultLanguage;
  }

  public getAssetsRoot(): string {
    return environment.assetsRoot;
  }

  public getEnvironmentName(): string {
    return environment.envName;
  }

  public getTokenExpiration(): number {
    return environment.tokenExpiration;
  }
}