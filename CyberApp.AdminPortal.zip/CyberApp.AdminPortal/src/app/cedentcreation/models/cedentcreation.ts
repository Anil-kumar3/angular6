import { ICedentCreation, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class CedentCreation
  extends CedentEntity
  implements ICedentCreation {

  public Country: string;
  public CountryCode: string;
  public CountryRegion: string;
  public CedentLoginID: string;
  public CedentName: string;
  public PricingTemplate: string;
  public PricingTemplateCode: string;
  public UserStatus: string;
  public FinancialStartMonth: string;
  public FinancialEndMonth: string;

  constructor(identifier: string, cedentId: string){
    super(cedentId);

    this.CedentLoginID = identifier;
  }
}