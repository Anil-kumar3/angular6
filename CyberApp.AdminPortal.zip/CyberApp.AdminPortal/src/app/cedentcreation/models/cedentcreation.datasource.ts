import { CedentCreationService } from '../services/cedentcreation.service';

import { ICedentCreation } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class CedentCreationDataSource 
  extends CedentEntityDataSource<ICedentCreation>{

  constructor(userService: CedentCreationService){
    super(userService);
  }

  buildSearchString(item: ICedentCreation): string {
    return (item.CedentName).toLowerCase();
  }
}