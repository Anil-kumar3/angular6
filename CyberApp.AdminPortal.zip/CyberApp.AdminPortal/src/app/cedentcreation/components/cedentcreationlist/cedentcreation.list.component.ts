import { Component, Injector } from '@angular/core';

import { CedentCreationService } from '../../services/cedentcreation.service';

import { CedentCreation, CedentCreationDataSource } from '../../models';
import { ICedentCreation } from '../../../common/models/contracts/models.contracts';

import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({ 
  templateUrl: './cedentcreation.list.component.html',
  styleUrls: ['./cedentcreation.list.component.scss']
})
export class CedentCreationListComponent extends CedentEntityListComponent<ICedentCreation> {

	displayedColumns = ['id', 'country', 'cedentloginid', 'cedentname', 'pricingtemplate', 'status', 'finacialstartmonth', 'finacialendmonth', 'delete'];
	dataSource: CedentCreationDataSource | null;


	get messageDeleteSuccess(): string {
		return this.getTranslation("cedentcreation.deletesuccess");
	}

	get messageDeleteError(): string {
		return this.getTranslation("cedentcreation.deleteerror");
	}

	constructor(
		injector: Injector,
	private userService: CedentCreationService
	){
		super(injector, userService);
	}

	protected createDataSource(): CedentCreationDataSource {
		return new CedentCreationDataSource(this.entityService);
	}


	getMessageDelete(user: ICedentCreation) {
		var options = { user: user.CedentLoginID };
		return this.getTranslation('cedentcreation.reallydelete', options);
	}
}