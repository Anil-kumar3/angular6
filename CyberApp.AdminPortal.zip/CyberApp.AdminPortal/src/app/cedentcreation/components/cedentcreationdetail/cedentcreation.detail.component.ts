import { Component, OnInit, Injector, ViewChild, ElementRef } from '@angular/core';
import {MdSnackBar} from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { CedentCreationService } from '../../services/cedentcreation.service';
import { CountryService, CountrySeqNoService } from '../../../cedent/services';
import { CedentCreation } from '../../models/cedentcreation';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { ICedentCreation, ICountry, IPricingTemplate, IsearchData, activestatus, financialMonth } from '../../../common/models/contracts/models.contracts';
import { StringUtils } from '../../../common/utils/string.utils';
import { ConfigurationService } from '../../../configuration/services/configuration.service';
import { keyPressvalidUtils } from "../../../common/utils/keyPress-valid.Utils";
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { getCedentId } from '../../../common/utils/cedent.utils';
import { LocalStorageService } from '../../../localstorage/services/localstorage.service';
import { Observable, Subscription } from 'rxjs/Rx';

@Component({
	selector: 'cedentcreation-detail',
	templateUrl: './cedentcreation.detail.component.html',
	styleUrls: ['./cedentcreation.detail.component.scss']
})


export class CedentCreationDetailComponent extends CedentEntityDetailComponent<ICedentCreation> implements OnInit{
	private validationErrors: Array<string>;
	public country: ICountry[];
	public countrySelected: ICountry;
	public pricingTemplate: IPricingTemplate[];
	public searchresult: IsearchData[];
	private _cedentCreation: ICedentCreation;
	error: string;
	existError: string;
	loadingFlag : string;
	public userstatus ;
	public financialStartMonth ;
	public financialEndMonth ;
	protected snackBar: MdSnackBar;
	private localStorageService = new LocalStorageService;


	/*
		Changing the cedent Id to superadmin cedent id in case of superadmin login. 
		As the webservice required cedent Id.
	*/
	/*protected get cedentId(): string {
		var rootcedentId = getCedentId();
		if (rootcedentId == null || rootcedentId == "" || rootcedentId == undefined) {
		  rootcedentId = this.localStorageService.get("superAdminID");
		}
		return rootcedentId;
	}*/


	/*
		Calling the pricing template web service to get the list once we come from edit case.
	*/
	public set cedentEntity(entity: ICedentCreation) {
		if(NullUndefined(entity.PricingTemplate) != ""){
			this.fetchTemplate();
		}
		this._cedentCreation = entity;
	}

	public get cedentEntity() {
		return this._cedentCreation;
	}


	constructor(
		injector: Injector,
		private cedentcreationService: CedentCreationService,
		private countryService: CountryService,
		private countryseqnoservice: CountrySeqNoService,
		private configurationService: ConfigurationService,
		private _translate: TranslateService
	) { 
		super(injector, cedentcreationService);
		this.validationErrors = new Array<string>();    
		this.snackBar = injector.get(MdSnackBar);
	}


	async ngOnInit() {  
		this.loadingFlag="Loading...";
		super.ngOnInit();
		/*var promises = [];
		//var countryPromise = this.countryService.getEntities().first().toPromise();
		var countryPromise = this.searchRecord('Country','Country',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			this.loadingFlag="";
			return;
		});
		promises.push(countryPromise);
		if(this.isExistEntity) {
		  var userPromise = this.entityLoaded.first().toPromise();
		  promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		this.country = result[0];*/
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);

		this.fetchTemplate();
		
		this.userstatus = activestatus;
		this.financialStartMonth = financialMonth;
		this.financialEndMonth = financialMonth;
		
		document.addEventListener("drop", function( event ) {
			event.preventDefault();
		}, false);
		this.loadingFlag="";
	}


	/*
		Fetch the pricing template list.
	*/
	private async fetchTemplate() {
		/*var pricingpromises = [];
		//var pricingTemplatePromise = this.pricingtemplateService.getEntities().first().toPromise()
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","").toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect pricing template web service", null, {duration: 3500})
			return;
		});
		pricingpromises.push(pricingTemplatePromise);
		if(this.isExistEntity) {
		  var templatePromise = this.entityLoaded.first().toPromise();
		  pricingpromises.push(templatePromise);
		}
		var result1 = await Promise.all(pricingpromises);
		this.pricingTemplate = result1[0];*/
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.pricingTemplate = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchTemplate"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }


	/*
		Function called to reset all data when reset button clicked.
	*/
	public resetData() : void {
		this.cedentEntity.Country = undefined;
		this.cedentEntity.CountryCode='';
		this.cedentEntity.CountryRegion='';
		this.cedentEntity.CedentLoginID='';
		this.cedentEntity.CedentName = '';
		this.cedentEntity.PricingTemplate = undefined;
		this.cedentEntity.PricingTemplateCode = '';
		this.cedentEntity.UserStatus = undefined;
		this.cedentEntity.FinancialStartMonth = undefined;
		this.cedentEntity.FinancialEndMonth = undefined;
		this.error = '';
	}


	/*
		Called when we change of country drop down to assign country code.
		Also to fetch running sequence cedent ID depending on change of country.
	*/
	public changeCountry(){
		this.loadingFlag="Loading...";
		for(let cnt=0;cnt<this.country.length;cnt++){
			if(this.cedentEntity.Country == this.country[cnt].CountryName){
				this.cedentEntity.CountryCode=this.country[cnt].CountryCode;
				this.cedentEntity.CountryRegion=this.country[cnt].CountryRegion;
				this.cedentEntity.CedentLoginID="";
				break;
			}
		}
		this.fetchRecord()
		return false;
		
	}


	/*
		To fetch the cedent ID on change of country.
		Also to display the stored cedent Id for existing record.
	*/
	private async fetchRecord(){	
		this.loadingFlag="Loading...";
		/*var promises = [];
		var seqnoPromise = this.searchRecord('CountrySeqno','CountrySeqno',NullUndefined(this.cedentEntity.Country),NullUndefined(this.cedentEntity.CountryCode),NullUndefined(this.cedentEntity.CountryRegion)).toPromise()
		.catch(error => {
			this.snackBar.open("Unable to connect country web service", null, {duration: 3500})
			this.loadingFlag="";
			return;
		});
		this.loadingFlag="";
		promises.push(seqnoPromise);
		if(this.isExistEntity) {
		  var userPromise = this.entityLoaded.first().toPromise();
		  promises.push(userPromise);
		}
		var result = await Promise.all(promises);
		this.searchresult = result[0];		
		var sequenceNo = this.paddy((parseInt(this.searchresult[0].CountrySeqNo)+1), parseInt(this.searchresult[0].CountrySeqLength), '0');
		this.cedentEntity.CedentLoginID="C"+this.searchresult[0].CountryCode+sequenceNo;*/
		var seqnoPromise = this.searchRecord('CountrySeqno','CountrySeqno',NullUndefined(this.cedentEntity.Country),NullUndefined(this.cedentEntity.CountryCode),NullUndefined(this.cedentEntity.CountryRegion))
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					if(NullUndefined(result[0].CountryCode)==""){
						this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
					}else{
						var sequenceNo = this.paddy((parseInt(result[0].CountrySeqNo)+1), parseInt(result[0].CountrySeqLength), '0');
						this.cedentEntity.CedentLoginID="C"+result[0].CountryCode+sequenceNo;
					}
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
	}
	


	/*
		To add number of zero infront of cedent ID depending on paddinglen parameter fetched from DB.
		runningseq : running seq no.
		paddinglen : length of character to append.
		paddingchar : what character to append.
	*/
	private paddy(runningseq, paddinglen, paddingchar) {
		var pad_char = typeof paddingchar !== 'undefined' ? paddingchar : '0';
		var pad = new Array(1 + paddinglen).join(pad_char);
		return (pad + runningseq).slice(-pad.length);
	}


	/*
		Store the pricing template code for backend storage, on pricing template dropdown change.
	*/
	public changePricingTemplate(){
		for(let cnt=0;cnt<this.pricingTemplate.length;cnt++){
			if(this.cedentEntity.PricingTemplate == this.pricingTemplate[cnt].TemplateName){
				this.cedentEntity.PricingTemplateCode=this.pricingTemplate[cnt].TemplateCode;
				break;
			}
		}
	}


	/*
		Function called on save button click.
		Basic validation before insert/update.
	*/
	public save(): void {
		if (NullUndefined(this.cedentEntity.Country) == ''){
			this.error = 'selectCountry';
			return;
		}else if(NullUndefined(this.cedentEntity.CountryCode) == ''){
			this.error = 'countrycoderequired';
			return;
		}else if(NullUndefined(this.cedentEntity.CedentLoginID) == ''){
			this.error = 'preCedentID';
			return;
		}else if(NullUndefined(this.cedentEntity.CedentName).trim() == ''){
			this.error = 'enterCedentName';
			return;
		}else if(NullUndefined(this.cedentEntity.CedentName).trim().length < 5){
			this.error = 'validCedentName';
			return;
		}else if(NullUndefined(this.cedentEntity.PricingTemplate) == ''){
			this.error = 'selectPricingTemplate';
			return;
		}else if(NullUndefined(this.cedentEntity.UserStatus) == ''){
			this.error = 'selectStatus';
			return;
		}else if(NullUndefined(this.cedentEntity.FinancialStartMonth) == ''){
			this.error = 'selectFinancialStartMonth';
			return;
		}else if(NullUndefined(this.cedentEntity.FinancialEndMonth) == ''){
			this.error = 'selectFinancialEndMonth';
			return;
		}else if(NullUndefined(this.cedentEntity.FinancialEndMonth).toUpperCase() == NullUndefined(this.cedentEntity.FinancialStartMonth).toUpperCase()){
			this.error = 'errorFinancialMonth';
			return;
		}else{
			this.error = '';
			this.loadingFlag="Saving details..";
			super.save();
		} 
	}


	/*
		For validating the fields with alpha numeric only on keypress.
		evt : Holds the keypress event.
		FieldValue : The field value on which key event has to be handled, passed if any validation has to be done.
		FieldName : Depending on field name type of validation to be done.
	*/
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "CedentName"){
			return keyPressvalidUtils.alphaNumericSpace(evt,NullUndefined(FieldValue));
		}
	}


	protected createNewObject(): ICedentCreation{
		return new CedentCreation("", this.cedentId);
	}


	/*
		To catch and display error if any in web service.
	*/
	protected onError(error: any): void {
		this.error='';
		this.existError='';
		this.loadingFlag="";
		if(error.Message.lastIndexOf("|") > -1)
		{
			var param = error.Message.split("|");
			this.existError=param[1];
		}else{
			this.error = error.Message;
		}
		return;
	}
}
