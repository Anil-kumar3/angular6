import { Component } from '@angular/core';


@Component({
  selector: 'cedentcreations',
  template: '<router-outlet></router-outlet>'
})
export class CedentCreationComponent {

  constructor(  ) {}
}