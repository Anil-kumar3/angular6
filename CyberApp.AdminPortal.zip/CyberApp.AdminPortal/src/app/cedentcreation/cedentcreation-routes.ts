import { Routes, RouterModule } from '@angular/router';

import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';

import { CedentCreationComponent } from './components/cedentcreation.component';
import { CedentCreationListComponent } from './components/cedentcreationlist/cedentcreation.list.component';
import { CedentCreationDetailComponent } from './components/cedentcreationdetail/cedentcreation.detail.component';


export var  cedentCreationRoutes: Routes = [
  {
    path: 'cedentcreation',
    component: CedentCreationComponent,
    canActivateChild: [ IsCedentRoleGuard ],
    children: [
      {
        path: '',
        component: CedentCreationListComponent,
      },
      {
        path: ':id',
        component: CedentCreationDetailComponent,
      },
      {
        path: 'create',
        component: CedentCreationDetailComponent,
      }
    ]
  }
];
