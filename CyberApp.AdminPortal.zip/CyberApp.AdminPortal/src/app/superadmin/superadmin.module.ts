import { NgModule } from '@angular/core';
import { Http } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MdButtonModule, MdCardModule, MdDialogModule, MdGridListModule, MdIconModule, MdInputModule, MdListModule, MdMenuModule, MdSelectModule, MdSidenavModule, MdTableModule, MdToolbarModule } from '@angular/material';

import { SuperAdminHomeComponent } from './components/superadminhome/superadmin.home.component';

import { SuperadminRoutingModule } from './superadmin-routing.module';
import { SuperadminService } from './services/superadmin.service';
import { CommonModule } from '../common/common.module';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
	FormsModule,
	BrowserModule,
	ReactiveFormsModule,
    SuperadminRoutingModule,
    MdButtonModule,
    MdIconModule,
    MdSidenavModule, 
	CommonModule,
	MdCardModule,
	MdDialogModule,
	MdGridListModule,
	MdInputModule,
	MdListModule,
	MdMenuModule,
	MdSelectModule,
	MdTableModule,
	MdToolbarModule,
	BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    SuperAdminHomeComponent
  ],
  providers: [
    SuperadminService
  ]
})
export class SuperAdminModule {}