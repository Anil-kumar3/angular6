import { Component,OnInit,Injector,OnDestroy} from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { Location } from '@angular/common';

import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';
import { ProfileService } from '../../../profile/services/profile.service';
import { TranslateService } from '@ngx-translate/core';
import {MdSlideToggleChange, MdDialog, MdDialogRef,MdSnackBar,ComponentType} from '@angular/material';

import { SuperadminService } from '../../services/superadmin.service';
import { ICedent, IPolicyHolder, IRole, RoleNames,IMenuItem} from '../../../common/models/contracts/models.contracts';
import { Superadmin } from '../../models/superadmin';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { Globals } from '../../../global';

export interface MenuItem {
    roles?: string[];
    routerLink: string;
    translateIdentifier: string;
    icon: string;
}

@Component({
  moduleId: module.id,
  templateUrl: './superadmin.home.component.html',
  styleUrls: ['./superadmin.home.component.scss']
})
export class SuperAdminHomeComponent extends CedentEntityDetailComponent<IMenuItem> implements OnInit,OnDestroy  {

	myObserver = null;
	public menuItems1: MenuItem;
	public isExistEntity: boolean = false;
	public role:string;
	protected snackBar: MdSnackBar;
	loadingFlag:string;
	public menuItems: MenuItem[];
  constructor(
	injector:Injector,
    private _route: ActivatedRoute,
    private _location: Location,
	private _SuperadminService:SuperadminService,
	private profileService: ProfileService,
	private _translate: TranslateService,
	public globals: Globals
  ){ 
	super(injector, _SuperadminService);	
		this.snackBar = injector.get(MdSnackBar);
  }

  async ngOnInit() {
		this.loadingFlag = "Loading data...";
		this.myObserver=this.profileService.getAuthenticatedProfile().subscribe(
			response => {
				var result = response;
				console.log("result:"+result);
				console.log("result:"+NullUndefined(result));
				if(NullUndefined(result)!=""){
					this.role=result.Roles[0].Name;
					console.log("this.role:"+this.role);
					this.globals.loginUserRole =result.Roles[0].Name;
					this.searchRecord("Menu","",this.role,"Insurance Management","")
					.subscribe(
						response => {
							var result = response;
							if(result.length>0 && result !="No Data Found"){
								this.menuItems=result;
							}else{
								this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchMenuData"), null, {duration: 3500})
							}	
							console.log(this.menuItems);
							this.loadingFlag="";
						}, error => {
							console.log("search record error");
							this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
							this.loadingFlag="";
							return;
						}
					);
				}/* else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchMenuData"), null, {duration: 3500});
					this.loadingFlag="";
				} */	
			}, error => {
				this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
				this.loadingFlag="";
				return;
			}
		);
  }
  
	ngOnDestroy() {
		this.myObserver.unsubscribe();
	}
  
  protected createNewObject(): IMenuItem{
	return new Superadmin("","");
	}
}
