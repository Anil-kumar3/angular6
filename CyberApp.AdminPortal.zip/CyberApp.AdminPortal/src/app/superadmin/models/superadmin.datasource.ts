import { SuperadminService } from '../services/superadmin.service';

import { IMenuItem } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';


export class SuperadminDataSource 
  extends CedentEntityDataSource<IMenuItem>{

  constructor(userService: SuperadminService){
    super(userService);
  }

  buildSearchString(item: IMenuItem): string {
    return (item.CedentId).toLowerCase();
  }
}