import { IMenuItem, IUser, IRole } from '../../common/models/contracts/models.contracts';
import { CedentEntity } from '../../common/models/cedent.entity';

export class Superadmin
  extends CedentEntity
  implements IMenuItem {
	
	public roles?: string[];
    public routerLink: string;
    public translateIdentifier: string;
    public icon: string;

  constructor(identifier: string, cedentId: string){
    super(cedentId);

    //this.ParameterCedentId = identifier;
  }
}