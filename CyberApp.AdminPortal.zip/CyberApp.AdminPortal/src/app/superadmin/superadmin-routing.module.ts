import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoggedInGuard } from '../common/services/loggedin.guard';

import { SuperAdminHomeComponent } from './components/superadminhome/superadmin.home.component';
import { CedentListComponent } from '../cedent/components/cedentlist/cedent.list.component';
import { CedentDetailAdminComponent } from '../cedent/components/cedentdetailadmin/cedent.detail.admin.component';
import { UsertypefunctionalityMappingDetailComponent } from '../usertypefunctionalitymapping/components/usertypefunctionalitymappingdetail/usertypefunctionalitymapping.detail.component';
import { UsertypeDetailComponent } from '../usertype/components/usertypedetail/usertype.detail.component';
import { QuotedashboardConversionComponent } from '../quotedashboard/components/quotedashboardconversion/quotedashboard.conversion.component';
import { CedentCreationListComponent } from '../cedentcreation/components/cedentcreationlist/cedentcreation.list.component';
import { CedentCreationDetailComponent } from '../cedentcreation/components/cedentcreationdetail/cedentcreation.detail.component';
import { CedentUserCreationListComponent } from '../cedentusercreation/components/cedentusercreationlist/cedentusercreation.list.component';
import { CedentUserCreationDetailComponent } from '../cedentusercreation/components/cedentusercreationdetail/cedentusercreation.detail.component';
import { ParametersettingListComponent } from '../parametersetting/components/parametersettinglist/parametersetting.list.component';
import { ParametersettingDetailComponent } from '../parametersetting/components/parametersettingdetail/parametersetting.detail.component';
import { ThresholdsettingListComponent } from '../thresholdsetting/components/thresholdsettinglist/thresholdsetting.list.component';
import { ThresholdsettingDetailComponent } from '../thresholdsetting/components/thresholdsettingdetail/thresholdsetting.detail.component';
import { TemplateUploadListComponent } from '../templateupload/components/templateuploadlist/templateupload.list.component';
import { TemplateUploadDetailComponent } from '../templateupload/components/templateuploaddetail/templateupload.detail.component';
import { TemplateApprovalListComponent } from '../templateapproval/components/templateapprovallist/templateapproval.list.component';
import { TemplateApprovalDetailComponent } from '../templateapproval/components/templateapprovaldetail/templateapproval.detail.component';
import { PolicyUpdateDetailComponent } from '../policyupdate/components/policyupdatedetail/policyupdate.detail.component';
import { UserListComponent } from '../users/components/userlist/user.list.component';
import { UserDetailComponent } from '../users/components/userdetail/user.detail.component';


const superAdminRoutes: Routes = [
  {
    path: 'administration', 
    component: SuperAdminHomeComponent, 
    canActivate: [LoggedInGuard],
    children: [
      {
        path: '', 
        redirectTo: 'cedents', 
        pathMatch: 'full'
      },
      {
        path: 'cedents',
        component: CedentListComponent,
        canActivateChild: [LoggedInGuard]
      },
      {
        path: 'cedents/:id',
        component: CedentDetailAdminComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'UTFMapping',
        component: UsertypefunctionalityMappingDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'UserType',
        component: UsertypeDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'cedentcreation',
        component: CedentCreationListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'cedentcreation/create',
        component: CedentCreationDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'cedentcreation/:id',
        component: CedentCreationDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'cedentusercreation',
        component: CedentUserCreationListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'cedentusercreation/create',
        component: CedentUserCreationDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'cedentusercreation/:id',
        component: CedentUserCreationDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'parametersetting',
        component: ParametersettingListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'parametersetting/create',
        component: ParametersettingDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'parametersetting/:id',
        component: ParametersettingDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'quotedashboard',
        component: QuotedashboardConversionComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'thresholdsetting',
        component: ThresholdsettingListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'thresholdsetting/create',
        component: ThresholdsettingDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'thresholdsetting/:id',
        component: ThresholdsettingDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'templateupload',
        component: TemplateUploadListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'templateupload/create',
        component: TemplateUploadDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'templateapproval',
        component: TemplateApprovalListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'templateapproval/create',
        component: TemplateApprovalDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'templateapproval/:id',
        component: TemplateApprovalDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'policyupdate',
        component: PolicyUpdateDetailComponent,
        canActivateChild: [LoggedInGuard]
      }
	  ,
	  {
        path: 'users',
        component: UserListComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'users/create',
        component: UserDetailComponent,
        canActivateChild: [LoggedInGuard]
      },
	  {
        path: 'users/:id',
        component: UserDetailComponent,
        canActivateChild: [LoggedInGuard]
      }
    ]
  }
];

@NgModule({
  imports: [
      RouterModule.forChild(superAdminRoutes)
  ],
  exports: [
      RouterModule
  ]
})
export class SuperadminRoutingModule{}