import { ICedent } from '../../common/models/contracts/models.contracts'
import { CedentEntity } from '../../common/models/cedent.entity';

export class Cedent
  extends CedentEntity 
  implements ICedent {
	public Prefix: string;	
	public Name: string;
	public Language: string;
	public SupportPhoneNumber: string;
	public SupportEMailAddress: string;
	public SalesPhoneNumber: string;
	public SalesEMailAddress: string;
	public HomePage: string;
	public Country: string;
	public CountryCode: string;
	public CedentLoginID: string;
	public CedentName: string;
	public PricingTemplate: string;
	public ProductType: string;
	public PricingTemplateCode: string;
	public UserStatus: string;
	public FinancialStartMonth: string;
	public FinancialEndMonth: string;
	public CountryRegion: string;
	
	public roles: string[];
	public routerLink: string;
	public translateIdentifier: string;
	public icon: string;

	constructor( Prefix: string,name: string, language: string,Country: string,PricingTemplate: string,ProductType: string,UserStatus: string,FinancialStartMonth: string,FinancialEndMonth: string,SupportPhoneNumber?: string, SupportEMailAddress?: string, SalesPhoneNumber?: string, SalesEMailAddress?: string, HomePage?: string,CountryCode?: string,CountryRegion?: string,CedentLoginID?: string,CedentName?: string,PricingTemplateCode?: string,roles?: string[],routerLink?: string,translateIdentifier?: string,icon?: string){
    super(null);
    
    this.Prefix = Prefix;
    this.Name = name;
    this.Language = language;
    this.SupportPhoneNumber = SupportPhoneNumber;
    this.SupportEMailAddress = SupportEMailAddress;
    this.SalesPhoneNumber = SalesPhoneNumber;
    this.SalesEMailAddress = SalesEMailAddress;
    this.HomePage = HomePage;
    this.Country = Country;
	this.CountryCode=CountryCode;
	this.CountryRegion=CountryRegion;
	this.CedentLoginID=CedentLoginID;
	this.CedentName=CedentName;
	this.PricingTemplate=PricingTemplate;
	this.ProductType=ProductType;
	this.PricingTemplateCode=PricingTemplateCode;
	this.UserStatus=UserStatus;
	this.FinancialStartMonth=FinancialStartMonth;
	this.FinancialEndMonth=FinancialEndMonth;
	
	this.roles=roles;
	this.routerLink=routerLink;
	this.translateIdentifier=translateIdentifier;
	this.icon=icon;
  }

}