import { CedentService } from '../services/cedent.service';

import { ICedent } from '../../common/models/contracts/models.contracts';
import { CedentEntityDataSource } from '../../common/models/cedent.entity.datasource';

 
export class CedentDataSource 
  extends CedentEntityDataSource<ICedent> {

  constructor(private _cedentService: CedentService) {
    super(_cedentService);
  }

  buildSearchString(item: ICedent): string {
    return (item.Name + item.SupportPhoneNumber + item.SupportEMailAddress + item.SalesPhoneNumber + item.SalesEMailAddress + item.HomePage ).toLowerCase();
  }
}