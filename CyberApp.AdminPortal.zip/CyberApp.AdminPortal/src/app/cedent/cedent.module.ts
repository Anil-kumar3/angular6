﻿import { NgModule } from '@angular/core';
import { CdkTableModule } from '@angular/cdk/table';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, Http } from '@angular/http';

import { CedentRoutingModule } from './cedent-routing.module';

import { TranslateModule, TranslateLoader } from "@ngx-translate/core";
import { TranslateHttpLoader } from "@ngx-translate/http-loader";

import { CedentListComponent } from './components/cedentlist/cedent.list.component';
import { CedentDetailComponent } from './components/cedentdetail/cedent.detail.component';
import { CedentDetailAdminComponent } from './components/cedentdetailadmin/cedent.detail.admin.component';
import { CedentAddComponent } from './components/cedentadd/cedent.add.component';
import { CedentDeleteComponent } from './components/cedentdelete/cedent.delete.component';
import { CedentHomeComponent } from './components/cedenthome/cedent.home.component';
import { CedentRedirectComponent } from './components/cedent-redirect/cedent-redirect.component';

import { CedentService, CedentHttpService, RoleService, CountryService ,CountrySeqNoService, ParameterService,CedentMenuService} from './services';

import { HttpService, HttpServiceFactory } from '../common/services/http.service';
import { AuthenticatedHttpService } from '../common/services/authenticated.http.service';
import { CommonModule } from '../common/common.module';


import { MdButtonModule, MdCardModule, MdDialogModule, MdGridListModule, MdIconModule, MdInputModule, MdListModule, MdMenuModule, MdSelectModule, MdSidenavModule, MdTableModule, MdToolbarModule } from '@angular/material';

export function HttpLoaderFactory(http: Http) {
  return new TranslateHttpLoader(http, "i18n/", ".json");
}

@NgModule({
  imports: [
    CedentRoutingModule,
    BrowserModule,
    CdkTableModule,
    FormsModule,
    HttpModule,
    MdButtonModule,
    MdCardModule,
    MdDialogModule,
    MdGridListModule, 
    MdIconModule,
    MdInputModule,    
    MdListModule,
    MdMenuModule,
    MdSelectModule,
    MdSidenavModule, 
    MdTableModule,
    MdToolbarModule, 
    CommonModule,
    ReactiveFormsModule,
    
    BrowserAnimationsModule,
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [Http]
      }
    })
  ],
  declarations: [
    CedentListComponent,
    CedentDetailComponent,
    CedentDetailAdminComponent,
    CedentAddComponent,
    CedentDeleteComponent,
    CedentHomeComponent,
    CedentRedirectComponent
  ],
  providers: [
    CedentService,
    RoleService,
    ParameterService,
	CountryService,
    HttpServiceFactory,
	CountrySeqNoService,
    AuthenticatedHttpService,
    CedentHttpService,
	CedentMenuService
  ],
  exports: [
    CedentListComponent
  ],
  entryComponents: [
    CedentAddComponent,
    CedentDeleteComponent
  ]
})
export class CedentModule { }