﻿import { Injectable } from '@angular/core';
import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';

import { CedentHttpService } from './cedent.http.service';

import { ICedent, ICedentWithStats } from '../../common/models/contracts/models.contracts';

import { HttpServiceFactory, HttpService } from '../../common/services/http.service';

import { Observable } from 'rxjs/Observable';

@Injectable()
export class CedentService
  extends BaseCedentEntityService<ICedent> {

  protected _entityHttpService: HttpService<ICedent>;
    
  constructor(
    httpServiceFactory: HttpServiceFactory, 
    private _cedentHttpService: CedentHttpService
  ) {
    super(httpServiceFactory, 'cedent');
    this._entityHttpService = _cedentHttpService;
  }

  public getCedentsWithStats(): Observable<Array<ICedentWithStats>>{
    return this._cedentHttpService.getCedentsWithStats();
  }

  public getOwnInformation(cedentId: string, force?: boolean): Observable<ICedent>{
    return this._cedentHttpService.getCedentData(cedentId, force);
  }

  public updateOwnInformation(updCedent: ICedent): Promise<ICedent> {
    return this._cedentHttpService.updateCedentData(updCedent);
  }

  public getOfflineData(id: string) {
    return this._cedentHttpService.getOfflineData(id);
  }
}