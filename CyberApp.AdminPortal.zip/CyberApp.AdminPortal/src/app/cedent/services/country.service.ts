import { Injectable } from '@angular/core';

import { ICountry } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class CountryService extends BaseCedentEntityService<ICountry> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'country');
  }
}