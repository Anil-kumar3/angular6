import { Injectable } from '@angular/core';

import { ICedent } from '../../common/models/contracts/models.contracts';
import { HttpService } from '../../common/services/http.service';
import { AuthenticatedHttpService } from '../../common/services/authenticated.http.service';
import { environment } from '../../../environments/environment';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class CedentHttpService
  extends HttpService<ICedent> {

  private _cedentData = new BehaviorSubject<ICedent>(null);

  constructor(http: AuthenticatedHttpService){
    super(http, 'cedent');
  }

  public getCedentData(cedentId: string, forceRefresh?: boolean){
    if (forceRefresh === true){
      this.http.get(environment.apiRoot + `api/${cedentId}/cedenthome`)
        .map(response => response.json())
        .subscribe(
          data => {
            this._cedentData.next(data);
          },
          error => {
            console.log(error);
          }
        );
    }
    return this._cedentData;
  }

  public updateCedentData(updCedent: ICedent): Promise<ICedent> {
    return new Promise<ICedent>((resolve, reject) => {
      this.http.put(environment.apiRoot + `api/${updCedent.id}/cedenthome`, updCedent)
        .subscribe(
          response => {
            var newValue = response.json();
            this._cedentData.next(newValue);
            resolve(newValue);
          },
          error => {
            reject(error);
          }
        );
    });
  }

  public getOfflineData(cedentId: string){
    return this.http.get(environment.apiRoot + `api/${cedentId}/cedenthome/offline`)
    .map(response => response.json());
  }

  public getCedentsWithStats(){
    return this.http.get(environment.apiRoot + 'api/Cedent/CedentsWithStats')
      .map(response => response.json());
  }
}