import { Injectable } from '@angular/core';

import { IsearchData } from '../../common/models/contracts/models.contracts';

import { BaseCedentEntityService } from '../../common/services/cedent.entity.service';
import { HttpServiceFactory } from '../../common/services/http.service';

@Injectable()
export class CountrySeqNoService extends BaseCedentEntityService<IsearchData> {

  constructor(httpServiceFactory: HttpServiceFactory) {
    super(httpServiceFactory, 'CountrySeqno');
  }
}
