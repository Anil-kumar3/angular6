﻿import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CedentHomeComponent } from './components/cedenthome/cedent.home.component';
import { CedentDetailComponent } from './components/cedentdetail/cedent.detail.component';
import { CedentRedirectComponent } from './components/cedent-redirect/cedent-redirect.component';

import { policyHolderRoutes } from '../policyholder/policyholder-routes';
import { usersRoutes } from '../users/users-routes';
import { messagesRoutes } from '../messages/messages-routes';

import { ParametersettingRoutes } from '../parametersetting/parametersetting-routes';

import { tipsRoutes } from '../tips/tips-routes';
import { questionnaireRoutes } from '../questionnaire/questionnaire-routes';
import { firstAidRoutes } from '../firstaid/firstaid-routes';
import { cedentCreationRoutes } from '../cedentcreation/cedentcreation-routes';
import { cedentUserCreationRoutes } from '../cedentusercreation/cedentusercreation-routes';

import { QuotedashboardRoutes } from '../quotedashboard/quotedashboard-routes';
import { ThresholdsettingRoutes } from '../thresholdsetting/thresholdsetting-routes';
import { PolicyUpdateRoutes } from '../policyupdate/policyupdate-routes';
import { TemplateUploadRoutes } from '../templateupload/templateupload-routes';
import { TemplateApprovalRoutes } from '../templateapproval/templateapproval-routes';
import { UsertypefunctionalityMappingRoutes } from '../usertypefunctionalitymapping/usertypefunctionalitymapping-routes';
import { UsertypeRoutes } from '../usertype/usertype-routes';

import { LoggedInGuard } from '../common/services/loggedin.guard';
import { IsCedentRoleGuard } from '../common/services/is-cedent-role.guard';
import { RoleNames } from '../common/models/contracts/models.contracts';


const cedentRoutes: Routes = [
  {
    path: 'cedent/:id', 
    component: CedentHomeComponent, 
    canActivate: [ LoggedInGuard ],
    children: [
      {
        path: '',
        component: CedentRedirectComponent,
        pathMatch: 'full'
      },
      { 
        path: 'details',
        component: CedentDetailComponent,
        canActivateChild: [LoggedInGuard, IsCedentRoleGuard] 
      },
      ...policyHolderRoutes,
      ...messagesRoutes,
      ...usersRoutes,
      ...tipsRoutes,
      ...questionnaireRoutes,
      ...firstAidRoutes,
	  ...cedentCreationRoutes,
      ...ParametersettingRoutes,
      ...cedentUserCreationRoutes,
      ...QuotedashboardRoutes,
	  ...ThresholdsettingRoutes,
	  ...PolicyUpdateRoutes,
	  ...UsertypefunctionalityMappingRoutes,
	  ...UsertypeRoutes,
	  ...TemplateUploadRoutes,
	  ...TemplateApprovalRoutes
    ]
  }
];

@NgModule({
    imports: [
        RouterModule.forChild(cedentRoutes)
    ],
    exports: [
        RouterModule
    ]
})
export class CedentRoutingModule{}