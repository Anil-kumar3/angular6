﻿import { Component, Injector } from '@angular/core';

import { CedentService } from '../../services/cedent.service';

import { Cedent } from '../../models/cedent';
import { CedentDataSource } from '../../models/cedent.datasource';

import { CedentAddComponent } from '../cedentadd/cedent.add.component';

import { ICedent } from '../../../common/models/contracts/models.contracts';
import { CedentEntityListComponent } from '../../../common/components/cedent.entity.list.component';

@Component({
  moduleId: module.id,
  templateUrl: './cedent.list.component.html',
  styleUrls: ['./cedent.list.component.scss']
})
export class CedentListComponent
  extends CedentEntityListComponent<ICedent> {

  displayedColumns = ['id', 'name', 'supportPhoneNumber', 'supportEMailAddress', 'salesPhoneNumber', 'salesEMailAddress','Country','CedentLoginID', 'delete'];

  get messageDeleteSuccess(): string {
    return this.getTranslation("cedent.deletesuccess");
  }

  get messageDeleteError(): string {
    return this.getTranslation("cedent.deleteerror");
  }

  constructor(
    injector: Injector,
    private _cedentService: CedentService
  ) { 
    super(injector, _cedentService);
  }

  protected createDataSource(){
    return new CedentDataSource(this._cedentService);
  }

  getMessageDelete(cedent: ICedent){
    var options = { cedent: cedent.Name};
    return this.getTranslation('cedent.reallydelete', options);
  }

  protected add(cedent: ICedent): void {
    this._cedentService.create(cedent).then(() => {
      this.snackBar.open(this._translateService.instant("cedent.createsuccess"), null, {duration: 3000});
    }, (error: any) => {
      this.snackBar.open(this._translateService.instant("cedent.createerror"), null, {duration: 3000});
    });
  }

  openAddCedentModal() {
    let dialogRef = this.dialog.open(CedentAddComponent);
    dialogRef.afterClosed().subscribe((result: Cedent) => {
      if (result instanceof Cedent && result !== null && result !== undefined) {
        this.add(result);
      }
    });
  }

  goToCreatePage(): void {
    //Do nothing. It's a dialog
  }

  goToDetail(item: ICedent): void {
    this.router.navigate([item.id], { relativeTo: this.route });    
  }
}