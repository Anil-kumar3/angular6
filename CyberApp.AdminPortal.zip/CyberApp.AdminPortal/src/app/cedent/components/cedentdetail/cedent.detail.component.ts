﻿import { Component, OnInit, Injector } from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MdSnackBar } from '@angular/material';
import { saveAs } from 'file-saver';

import { ICedentCreation,ICedent,ICountry, IPricingTemplate, IsearchData, activestatus, financialMonth } from '../../../common/models/contracts/models.contracts';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import 'rxjs/add/operator/switchMap';

import { TranslateService } from '@ngx-translate/core';

//import { ICedent } from '../../../common/models/contracts/models.contracts';

import { CedentService } from '../../services/cedent.service';
import { Cedent } from '../../models/cedent';


@Component({
    moduleId: module.id,
    selector: 'cedent-detail',
    templateUrl: './cedent.detail.component.html',
    styleUrls: ['./cedent.detail.component.scss']
})
export class CedentDetailComponent extends CedentEntityDetailComponent<ICedent> implements OnInit {
    
  private cedent: ICedent;
  error: string;	  
  public pricingTemplate: IPricingTemplate[];
  public userstatus ;
  public financialStartMonth ;
  public financialEndMonth ;	
  loadingFlag : string;
  public productType =['SME','Cyber Security V1.2'];

  constructor(
	injector: Injector,
    public router: Router,
    private _cedentService: CedentService,
    private _route: ActivatedRoute, 
    private _translateService: TranslateService,
    protected snackBar: MdSnackBar
  ){
	  super(injector, _cedentService);
  }

  ngOnInit(): void {
	super.ngOnInit();
	
    this._route.parent.params
      .switchMap((params: Params) => this._cedentService.getOwnInformation(params['id'], true))
      .subscribe((cedent: ICedent) => {
        this.cedent = cedent
      }, (error: any) => {
        this.snackBar.open(this._translateService.instant("cedent.errorgettingdetail"), null, { duration: 3000 });
      });
	 
	this.fetchTemplate(); 
	this.userstatus = activestatus;
	this.financialStartMonth = financialMonth;
	this.financialEndMonth = financialMonth;
  }

  private Isave(): void {
    this._cedentService.updateOwnInformation(this.cedent)
      .then(() => this.goBack())
	  .catch(error=> {
		  console.log(error);
		  this.error = JSON.parse(error._body).Message;
		});
	  
  }

  /* protected goBack(): void {
    this.router.navigate(['..'], {relativeTo: this._route });
  } */

  public exportOfflineClick(){
    this._cedentService.getOfflineData(this.cedent.id).subscribe(data => {this.downloadFile(data)});
  }

  public downloadFile(data): any{

    var str = JSON.stringify(data, null, 2);
    var blob = new Blob([str], {type: "text/plain;charset=utf-8"});

    saveAs(blob, 'offline.json', );
  }
  
  protected createNewObject(): ICedent {
    return new Cedent("", "","","","","","","","");
  }
  
   private async fetchTemplate() {
		
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.pricingTemplate = result;
				}else{
					this.snackBar.open(this._translateService.instant("commonMessage.unabletoFetchTemplate"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translateService.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }
	
	/** API Server Validation **/
	protected onError(error: any): void {
		console.log("error:"+error);
		this.error = error.Message;
		this.loadingFlag="";
		console.log(this.error);
		return;
	}
}