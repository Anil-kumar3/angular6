import {Component, OnInit, Injector, ViewChild, ElementRef,OnDestroy} from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';

import { ICedent, IPolicyHolder, IRole, RoleNames } from '../../../common/models/contracts/models.contracts';

import { Cedent } from '../../models/cedent';
import { CedentService } from '../../services/cedent.service';
import { cedentHomeMenu, MenuItem  } from './cedent.home.menu';

import { BehaviorSubject } from 'rxjs/Rx';

import {CedentEntityDetailComponent} from '../../../common/components/cedent.entity.detail.component';
import { ProfileService } from '../../../profile/services/profile.service';
import { TranslateService } from '@ngx-translate/core';
import {MdSlideToggleChange, MdDialog, MdDialogRef,MdSnackBar,ComponentType} from '@angular/material';
//added by prakashk 11.07.2018
import { CedentMenuService } from '../../services/cedent.menu.service';
import { Observable, ReplaySubject, Subject } from 'rxjs/Rx';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import { Globals } from '../../../global';

@Component({
  moduleId: module.id,
  templateUrl: './cedent.home.component.html',
  styleUrls: ['./cedent.home.component.scss']
})
export class CedentHomeComponent extends CedentEntityDetailComponent<ICedent> implements OnInit,OnDestroy {

	myObserver = null;
	public menuItems: MenuItem[];
	//added by prakashk 11.07.2018
	public menuItems1: MenuItem;
	public isExistEntity: boolean = false;
	public role:string;
	protected snackBar: MdSnackBar;
	loadingFlag:string;


	constructor(
		injector:Injector,
		private _cedentService: CedentService,
		private _route: ActivatedRoute,
		private _cedentMenuService: CedentMenuService,
		private profileService: ProfileService,
		private _translate: TranslateService,
		public globals: Globals
	){
		super(injector, _cedentService);	
		this.snackBar = injector.get(MdSnackBar);
	}  

	async ngOnInit() {
		this.loadingFlag = "Loading data...";
		if(NullUndefined(this.menuItems) == ""){
			this.myObserver=this.profileService.getAuthenticatedProfile().subscribe(
				response => {
					var result = response;
					console.log("result:"+result);
					console.log("result:"+NullUndefined(result));
					if(NullUndefined(result)!=""){
						console.log(result.Roles[0].Name);
						this.globals.loginUserRole=result.Roles[0].Name;
						this.globals.loginUserID=result.Id;
						this.role=result.Roles[0].Name;
						this.searchRecord("Menu","",this.role,"Insurance Management","")
						.subscribe(
							response => {
								var result = response;
								if(result.length>0 && result !="No Data Found"){
									this.menuItems=result;
								}else{
									this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchMenuData"), null, {duration: 3500})
								}	
								console.log(result);
								this.loadingFlag="";
							}, error => {
								console.log("search record error");
								this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
								this.loadingFlag="";
								return;
							}
						);
					}/* else{
						this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchMenuData"), null, {duration: 3500});
						this.loadingFlag="";
					} */
				}, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
				}
			);
		}
	}
	
	ngOnDestroy() {
		this.myObserver.unsubscribe();
	}

	protected createNewObject(): ICedent{
	return new Cedent("","","","","","","","","","","","","","","","","");
	}
}