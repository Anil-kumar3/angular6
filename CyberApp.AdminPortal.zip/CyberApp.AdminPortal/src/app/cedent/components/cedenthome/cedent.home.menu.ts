import { RoleNames } from '../../../common/models/contracts/models.contracts';

export var cedentHomeMenu: MenuItem[] = [   
    /*{
        icon: 'arrow_back',
        translateIdentifier: 'cedent.cedents',
        routerLink: '/administration/cedents',
        roles: [RoleNames.CEDENT_MANAGER,RoleNames.MR_PLATFORMMANAGER]
    },

    {
        icon: 'people',
        translateIdentifier: 'policyholder.policyholders',
        routerLink: './policyholders',
        roles: [RoleNames.CEDENT_SALES_SUPPORT,RoleNames.CE_PLATFORMSUPPORT,RoleNames.CE_T1_INCIDENTMANAGER,RoleNames.CE_T2_INCIDENTMANAGER,RoleNames.CE_T3_INCIDENTMANAGER ]
    },
    {
        icon: 'mail',
        translateIdentifier: 'messagesAndTasks',
        routerLink: './messages',
        roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
    {
        icon: 'lightbulb_outline',
        translateIdentifier: 'tip.tips',
        routerLink: './tips',
        roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
    {
        icon: 'question_answer',
        translateIdentifier: 'questionnaire.questionnaireItems',
        routerLink: './questions',
        roles: [RoleNames.CEDENT_READER, RoleNames.CEDENT_CONTENT_MANAGER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
    {
        icon: 'local_hospital',
        translateIdentifier: 'firstaid.firstAidCategories',
        routerLink: './firstaids',
        roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
    {
        icon: 'settings',
        translateIdentifier: 'cedent.details',
        routerLink: './details'
    },
    {
        icon: 'grade',
        translateIdentifier: 'cedent.users',
        routerLink: './users'
    },
    {
        icon: 'perm_data_setting',
        translateIdentifier: 'parametersetting.Parametersetting',
        routerLink: './parametersetting',
		roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
    {
        icon: 'dashboard',
       // translateIdentifier: 'cedentusercreation.cedentusercreation',
         translateIdentifier: 'Dashboard',
        routerLink: './quotedashboard',
		roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
	{
        icon: 'build',
        translateIdentifier: 'threshold.threshold',
        routerLink: './thresholdsetting',
        roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER, RoleNames.CE_PLATFORMMANAGER,RoleNames.CE_AUDITOR]
    },
	{
        icon: 'file_upload',
        translateIdentifier: 'template.template',
        routerLink: './templateupload',
		roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    },
	{
        icon: 'cloud_download',
        translateIdentifier: 'templateApproval.templateApproval',
        routerLink: './templateapproval',
		roles: [RoleNames.CEDENT_CONTENT_MANAGER, RoleNames.CEDENT_READER,RoleNames.CE_AUDITOR,RoleNames.CE_PLATFORMMANAGER]
    }*//*,
	{
        icon: 'grade',
        translateIdentifier: 'UTF.utf',
        routerLink: './UTFMapping',
		roles: [RoleNames.CEDENT_MANAGER,RoleNames.MR_PLATFORMMANAGER]
    },
	{
        icon: 'grade',
        translateIdentifier: 'UserType.usertype',
        routerLink: './UserType',
		roles: [RoleNames.CEDENT_MANAGER,RoleNames.MR_PLATFORMMANAGER]
    }*/
];

export interface MenuItem {
    roles?: string[];
    routerLink: string;
    translateIdentifier: string;
    icon: string;
}
