import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { Subscription } from 'rxjs/Rx';

import { ProfileService } from '../../../profile/services/profile.service';
import { RoleNames } from '../../../common/models/contracts/models.contracts';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";

@Component({
    selector: 'cedent-redirect',
    template: ''
})
export class CedentRedirectComponent implements OnInit, OnDestroy {

    private userSubscription: Subscription;

    constructor(
        private router: Router,
        private route: ActivatedRoute,
        private profileService: ProfileService,
    ){}

	/** 
		Function Calling on page load
	**/
    async ngOnInit() {

        this.userSubscription = this.profileService.getAuthenticatedProfile().subscribe(user => {
			if(NullUndefined(user)!=""){
				var role = user.Roles[0];

				switch(role.Name){
					case RoleNames.CEDENT_ADMIN:
					case RoleNames.CEDENT_SALES_SUPPORT:
						this.router.navigate(['users'], { relativeTo: this.route });
						break;
					case RoleNames.CEDENT_USER:
					case RoleNames.CEDENT_READER:
					case RoleNames.CEDENT_CONTENT_MANAGER:
						this.router.navigate(['users'], { relativeTo: this.route });
						break;
					case RoleNames.CE_PLATFORMMANAGER:
						this.router.navigate(['users'], { relativeTo: this.route });
						break;
					case RoleNames.CE_UW_MANAGER:
						this.router.navigate(['thresholdsetting'], { relativeTo: this.route });
						break;
					case RoleNames.CE_UNDERWRITER:
						this.router.navigate(['quotedashboard'], { relativeTo: this.route });
						break;
				}
			}

        });
    }

	/**
		Page level functionality will destroy once other page will load
	**/
    ngOnDestroy() {
        this.userSubscription.unsubscribe();
        this.userSubscription = undefined;
    }
}
