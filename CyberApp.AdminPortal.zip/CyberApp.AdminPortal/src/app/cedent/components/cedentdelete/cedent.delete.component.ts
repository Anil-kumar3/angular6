import { Component, OnInit, Inject } from '@angular/core';

import { MdDialogRef, MdDialogConfig, MD_DIALOG_DATA } from '@angular/material';

import { ICedent } from '../../../common/models/contracts/models.contracts';

@Component({
  moduleId: module.id,
  selector: 'cedent-delete',
  templateUrl: './cedent.delete.component.html',
  styleUrls: ['./cedent.delete.component.scss']
})
export class CedentDeleteComponent    
  implements OnInit {

  public cedent: ICedent;

  constructor(public dialogRef: MdDialogRef<CedentDeleteComponent>, @Inject(MD_DIALOG_DATA) public data: any){

  }

  ngOnInit() {
    if (this.data && this.data.cedent !== null && this.data.cedent !== undefined){
      this.cedent = this.data.cedent;
    }
  }

  public confirm(): void {
    this.dialogRef.close({delete: true})
  }

  public cancel(): void {
    this.dialogRef.close({delete: false});
  }
}