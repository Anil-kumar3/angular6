import 'rxjs/add/operator/switchMap';
import { Component, OnInit,Injector } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MdDialogRef ,MdSnackBar} from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { Cedent } from '../../models/cedent';
import { CedentService } from '../../services/cedent.service';
import { StringUtils } from '../../../common/utils/string.utils';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { ICedentCreation,ICedent,ICountry, IPricingTemplate, IsearchData, activestatus, financialMonth } from '../../../common/models/contracts/models.contracts';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import {keyPressvalidUtils} from "../../../common/utils/keyPress-valid.Utils";
@Component({
  moduleId: module.id,
  selector: 'cedent-add',
  templateUrl: './cedent.add.component.html',
  styleUrls: ['./cedent.add.component.scss']
})
export class CedentAddComponent extends CedentEntityDetailComponent<ICedent> implements OnInit {
	private validationErrors: Array<string>;	
	public cedentForm: FormGroup;
	public cedent: ICedent;
	public languages: Array<{value: string, displayValue: string}>;
	public country: ICountry[];
	public pricingTemplate: IPricingTemplate[];
	error: string;
	loadingFlag: string;
	existError: string;
	protected snackBar: MdSnackBar;
	public userstatus ;
	public Selectoption;
	public financialStartMonth ;
	public financialEndMonth ;
	public productType =['SME','Cyber Security V1.2'];

	constructor(
	injector: Injector,
	private CedentService: CedentService,	
	private _fb: FormBuilder,
	private _dialogRef: MdDialogRef<CedentAddComponent>,
	private _translate: TranslateService,
	){
		super(injector, CedentService);	
		this.languages = [
		{value: 'de-DE', displayValue: this._translate.instant("languages.germanDE")},
		{value: 'en-GB', displayValue: this._translate.instant("languages.englishGB")}
		];
		this.snackBar = injector.get(MdSnackBar);
		this.validationErrors = new Array<string>();   
	}

	/** 
		Function Calling on page load
	**/
	ngOnInit(): void {  
		this.cedent = new Cedent("", "","","","","","","","","","","","","","","","");
		this.createForm();
		this.loadingFlag="Loading...";
		super.ngOnInit();
		var countryPromise = this.searchRecord('Country','Country',"","","")
		.subscribe(
			response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.country = result;
					console.log(this.country);
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchCountry"), null, {duration: 3500})
				}
				this.loadingFlag="";
			}, error => {
				this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
				this.loadingFlag="";
				return;
			}
		);
		this.fetchTemplate();
		this.userstatus = activestatus;
		 this.Selectoption =activestatus[0].label;
		this.financialStartMonth = financialMonth;
		this.financialEndMonth = financialMonth;
	}

	/**
		creating Form control names
	**/
	public get name() {
		return this.cedentForm.get("name");
	} 

	public get Prefix() {
		return this.cedentForm.get("Prefix");
	} 

	public get language() {
		return this.cedentForm.get("language");
	}

	public get supportPhoneNumber() {
		return this.cedentForm.get("supportPhoneNumber");
	}

	public get supportEMailAddress() {
		return this.cedentForm.get("supportEMailAddress");
	}

	public get salesPhoneNumber() {
		return this.cedentForm.get("salesPhoneNumber");
	}

	public get salesEMailAddress() {
		return this.cedentForm.get("salesEMailAddress");
	}

	public get homepage(){
		return this.cedentForm.get("homepage");
	}

	public get Country() {
		return this.cedentForm.get("Country");
	}

	public get CountryCode() {
		return this.cedentForm.get("CountryCode");
	}

	public get PricingTemplate() {
		return this.cedentForm.get("PricingTemplate");
	}

	public get UserStatus() {
		return this.cedentForm.get("UserStatus");
	}

	public get CedentLoginID() {
		return this.cedentForm.get("CedentLoginID");
	}

	public get CedentName() {
		return this.cedentForm.get("CedentName");
	}

	public get CountryRegion() {
		return this.cedentForm.get("CedentName");
	}

	public get PricingTemplateCode() {
		return this.cedentForm.get("PricingTemplateCode");
	}

	public get FinancialStartMonth() {
		return this.cedentForm.get("FinancialStartMonth");
	}

	public get FinancialEndMonth() {
		return this.cedentForm.get("FinancialEndMonth");
	}

	public goBack(): void {
		this._dialogRef.close(null);
	}
	
	public get ProductType() {
		return this.cedentForm.get("ProductType");
	}

	/**
		Uploading data into server
	**/
	public submit(): void {
		this.cedent = this.prepareSaveCedent();
		console.log(this.cedent);
		// this._CedentListComponent.add(this.cedent);
		// this._dialogRef.close(this.cedent);
		/*if(NullUndefined(this.cedent.CedentName).trim() == ''){
			this.error = 'enterUserName';
			return;
		}else if(NullUndefined(this.cedent.CedentName) == ''){
			this.error = 'enterUserName';
			return;
		}*/
		this.loadingFlag="Loading...";
		this.CedentService.create(this.cedent).then(() => {
			this.snackBar.open(this._translate.instant("cedent.createsuccess"), null, {duration: 3000});
			this.loadingFlag="";
			this._dialogRef.close(null);
		}, (error: any) => {
			console.log(error);
			this.error='';
			this.existError='';
			this.loadingFlag="";
			if(error.Message.lastIndexOf("|") > -1)
			{
				var param = error.Message.split("|");
				this.existError=param[1];
				this.snackBar.open(this._translate.instant(this.existError), null, {duration: 3000});
			}else{
				this.error = error.Message;
				this.snackBar.open(this._translate.instant("cedent."+this.error), null, {duration: 3000});
			}
		});
	}

	/**
		Calling for Creating Forms
	**/
	private createForm(){
		this.cedentForm = new FormGroup({
			'Prefix': new FormControl('', [Validators.required]),
			'name': new FormControl('', [Validators.required]),
			'language': new FormControl('', [Validators.required]),
			'supportPhoneNumber': new FormControl('', [Validators.required]),
			'supportEMailAddress': new FormControl('', [Validators.required, Validators.email]),
			'salesPhoneNumber': new FormControl('', [Validators.required]),
			'salesEMailAddress': new FormControl('', [Validators.required, Validators.email]),
			'homepage': new FormControl('', [Validators.pattern("^(https?://)?([a-zA-Z0-9]([a-zA-ZÃƒÂ¤ÃƒÂ¶ÃƒÂ¼Ãƒâ€žÃƒâ€“ÃƒÅ“0-9\-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,6}$")]),
			'Country': new FormControl('', [Validators.required]),
			// 'CountryCode': new FormControl({value: '', disabled: true}, [Validators.required]),
			//'CedentLoginID': new FormControl({value: '', disabled: true}, [Validators.required]),
			'CountryCode': new FormControl('', [Validators.required]),
			'CedentLoginID': new FormControl('', [Validators.required]),
			//'CedentName': new FormControl('', [Validators.required]),
			'PricingTemplate': new FormControl('', [Validators.required]),
			'ProductType':new FormControl('', [Validators.required]),
			'UserStatus': new FormControl('', [Validators.required]),
			'FinancialStartMonth': new FormControl('', [Validators.required]),
			'FinancialEndMonth': new FormControl('', [Validators.required]),
			'CountryRegion':new FormControl('', [Validators.required]),
			'PricingTemplateCode':new FormControl('', [Validators.required])
		});
	}

	/**
		Preapring Form names for saving in server
	**/
	private prepareSaveCedent(): ICedent{
		const formModel = this.cedentForm.value;
		console.log(formModel);
		const saveCedent: ICedent = new Cedent(
			formModel.Prefix as string, 
			formModel.name as string, 
			formModel.language as string, 
			formModel.Country as string,
			formModel.PricingTemplate as string,
			formModel.ProductType as string,
			formModel.UserStatus as string,
			formModel.FinancialStartMonth as string,
			formModel.FinancialEndMonth as string,
			formModel.supportPhoneNumber as string, 
			formModel.supportEMailAddress as string, 
			formModel.salesPhoneNumber as string, 
			formModel.salesEMailAddress as string,
			formModel.homepage as string,
			formModel.CountryCode as string,
			formModel.CountryRegion as string,
			formModel.CedentLoginID as string,
			formModel.CedentName as string,
			formModel.PricingTemplateCode as string
		);
		console.log(saveCedent);
		return saveCedent;
	}

	protected createNewObject(): ICedent{
		return new Cedent("","","","","","","","","","","","","","","","","","");
	}

	public changeCountry(){
		this.loadingFlag="Loading...";
		for(let cnt=0;cnt<this.country.length;cnt++){
			if(this.cedentForm.value.Country == this.country[cnt].CountryName){
				this.cedentForm.patchValue({
					'CountryCode':this.country[cnt].CountryCode,
					'CountryRegion':this.country[cnt].CountryRegion
				}); 
				break;
			}
		}
		console.log(this.cedentForm.value.CountryRegion);
		this.fetchRecord()
		return false; 
	}

	public changePricingTemplate(){
		for(let cnt=0;cnt<this.pricingTemplate.length;cnt++){
			if(this.cedentForm.value.PricingTemplate == this.pricingTemplate[cnt].TemplateName){
				this.cedentForm.patchValue({
					'PricingTemplateCode':this.pricingTemplate[cnt].TemplateCode
				}); 
				break;
			}
		}
	}

	private async fetchRecord(){	
		this.loadingFlag="Loading...";
		var seqnoPromise = this.searchRecord('CountrySeqno','CountrySeqno',NullUndefined(this.cedentForm.value.Country),NullUndefined(this.cedentForm.value.CountryCode),NullUndefined(this.cedentForm.value.CountryRegion))
		.subscribe(
			response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					if(NullUndefined(result[0].CountryCode)==""){
						this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
					}else{
						var sequenceNo = this.paddy((parseInt(result[0].CountrySeqNo)+1), parseInt(result[0].CountrySeqLength), '0');
						//this.cedentForm.value.CedentLoginID="C"+result[0].CountryCode+sequenceNo;
						this.cedentForm.patchValue({
							'CedentLoginID':"C"+result[0].CountryCode+sequenceNo
						}); 
					}
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetch"), null, {duration: 3500})
				}
				this.loadingFlag="";
			}, error => {
				this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
				this.loadingFlag="";
				return;
			}
		);
	} 

	private paddy(runningseq, paddinglen, paddingchar) {
		var pad_char = typeof paddingchar !== 'undefined' ? paddingchar : '0';
		var pad = new Array(1 + paddinglen).join(pad_char);
		return (pad + runningseq).slice(-pad.length);
	}
	/*
	Fetch the pricing template list.
	*/
	private async fetchTemplate() {
		this.loadingFlag="Loading...";
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","")
		.subscribe(
		response => {
			var result = response;
			if(result.length>0 && result !="No Data Found"){
				this.pricingTemplate = result;
			}else{
				this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchTemplate"), null, {duration: 3500})
			}
			this.loadingFlag="";
		}, error => {
			this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
			this.loadingFlag="";
			return;
		}
		);
	}

	protected onError(error: any): void {
		this.error='';
		this.existError='';
		this.loadingFlag="";
		if(error.Message.lastIndexOf("|") > -1)
		{
			var param = error.Message.split("|");
			this.existError=param[1];
		}else{
			this.error = error.Message;
		}
		return;
    }

    keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "Value"){
            return keyPressvalidUtils.alphaNumeric(evt,NullUndefined(this.cedentForm.get(FieldValue)));
		}else if(FieldName == "supportPhoneNumber" || FieldName == "salesPhoneNumber"){
			return keyPressvalidUtils.mobileValidation(evt,NullUndefined(FieldValue));
		}else if(FieldName == "supportEMailAddress" || FieldName == "salesEMailAddress"){
			return keyPressvalidUtils.emailFormat(evt,NullUndefined(FieldValue));
		}else if(FieldName == "cedentName" || FieldName == "name"){
			return keyPressvalidUtils.alphaNumericSpace(evt,NullUndefined(FieldValue));
		}
	}

}