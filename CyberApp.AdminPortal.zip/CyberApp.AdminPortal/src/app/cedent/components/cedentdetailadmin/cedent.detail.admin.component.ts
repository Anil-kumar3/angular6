﻿import { Component, OnInit, Injector } from '@angular/core';

//import { ICedent } from '../../../common/models/contracts/models.contracts';
import { CedentEntityDetailComponent } from '../../../common/components/cedent.entity.detail.component';
import { ICedentCreation,ICedent,ICountry, IPricingTemplate, IsearchData, activestatus, financialMonth } from '../../../common/models/contracts/models.contracts';
import { CedentService } from '../../services/cedent.service';
import { MdDialogRef ,MdSnackBar} from '@angular/material';
import { TranslateService } from '@ngx-translate/core';
import { NullUndefined } from "../../../common/utils/NullUndefined.utils";
import {keyPressvalidUtils} from "../../../common/utils/keyPress-valid.Utils";

import { Cedent } from '../../models/cedent';

import { Subscription } from 'rxjs/Rx';

@Component({
    moduleId: module.id,
    selector: 'cedent-detail-admin',
    templateUrl: './cedent.detail.admin.component.html',
    styleUrls: ['./cedent.detail.admin.component.scss']
})
export class CedentDetailAdminComponent
  extends CedentEntityDetailComponent<ICedent> implements OnInit {
  error: string;	  
  public pricingTemplate: IPricingTemplate[];
  public userstatus ;
  public financialStartMonth ;
  public financialEndMonth ;	
  protected snackBar: MdSnackBar;
  loadingFlag : string;
  public productType =['SME','Cyber Security V1.2'];
  private _message: ICedent;
	  
  
  public stats: {
    activatedNoAnswerUsers: number;
    activatedUsers: number;
    newUsers: number;
    registeredUsers: number;
    registragtionExpiredUsers: number;
  };

  private _cedentsWithStatsSubscription: Subscription;
  
  public set cedentEntity(entity: ICedent) {
		this.fetchTemplate();
		console.log("sdffsdf");
		this._message = entity;
	}


	public get cedentEntity() {
		return this._message;
	}
  
  constructor(
    injector: Injector,
    private cedentService: CedentService,
	 private _translate: TranslateService
  ){
    super(injector, cedentService);
	this.snackBar = injector.get(MdSnackBar);
  }

  ngOnInit(): void {
    super.ngOnInit();
	
	//this.fetchTemplate();
	this.userstatus = activestatus;
	this.financialStartMonth = financialMonth;
	this.financialEndMonth = financialMonth;
  }

  onEntityLoaded() {
    super.onEntityLoaded();
    this._cedentsWithStatsSubscription = this.cedentService.getCedentsWithStats().subscribe((stats) => {
      let statsOfInterest = stats.find((stat) => {
        return stat.id === this.cedentEntity.id
      });
      console.log(statsOfInterest);
      if (statsOfInterest !== null && statsOfInterest !== undefined){
        this.stats = {
          activatedNoAnswerUsers: statsOfInterest.ActivatedNoAnswerUsers,
          activatedUsers: statsOfInterest.ActivatedUsers,
          newUsers: statsOfInterest.NewUsers,
          registeredUsers: statsOfInterest.RegisteredUsers,
          registragtionExpiredUsers: statsOfInterest.RegistragtionExpiredUsers
        }
      }
    });
  }

  
	public save(): void {
		this.error = '';
		this.loadingFlag = "Saving data...";
		super.save();
	}
	
	
  protected createNewObject(): ICedent {
    return new Cedent("", "","","","","","","","","");
  }
  
  
  private async fetchTemplate() {
		
		var pricingTemplatePromise = this.searchRecord('PricingTemplate','PricingTemplate',"","","")
		.subscribe(
			  response => {
				var result = response;
				if(result.length>0 && result !="No Data Found"){
					this.pricingTemplate = result;
				}else{
					this.snackBar.open(this._translate.instant("commonMessage.unabletoFetchTemplate"), null, {duration: 3500})
				}
				this.loadingFlag="";
			  }, error => {
					this.snackBar.open(this._translate.instant("commonMessage.unabletoConnectWeb"), null, {duration: 3500})
					this.loadingFlag="";
					return;
			}
		);
    }
	
	public changePricingTemplate(){
		for(let cnt=0;cnt<this.pricingTemplate.length;cnt++){
			if(this.cedentEntity.PricingTemplate == this.pricingTemplate[cnt].TemplateName){
				this.cedentEntity.PricingTemplateCode=this.pricingTemplate[cnt].TemplateCode;
				break;
			}
		}
	}
	
	/** API Server Validation **/
	protected onError(error: any): void {
		this.error = error.Message;
		this.loadingFlag="";
		return;
	}

	
	keyValidation(evt,FieldValue,FieldName){
		if(FieldName == "Value"){
            return keyPressvalidUtils.alphaNumeric(evt,NullUndefined(FieldValue));
		}else if(FieldName == "supportPhoneNumber" || FieldName == "salesPhoneNumber"){
			return keyPressvalidUtils.mobileValidation(evt,NullUndefined(FieldValue));
		}else if(FieldName == "supportEMailAddress" || FieldName == "salesEMailAddress"){
			return keyPressvalidUtils.emailFormat(evt,NullUndefined(FieldValue));
		}else if(FieldName == "cedentName" || FieldName == "name"){
			return keyPressvalidUtils.alphaNumericSpace(evt,NullUndefined(FieldValue));
		}
	}
}